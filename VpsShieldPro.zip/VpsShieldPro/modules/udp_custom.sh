#!/bin/bash
# UDP Custom Module
# Created by MasterMind (@bitcockiii)

# Default UDP port
UDP_CUSTOM_PORT="36712"
DEFAULT_CONFIG_FILE="/etc/udp-custom/config.json"
UDP_CUSTOM_LOG_FILE="$SCRIPT_DIR/logs/udp-custom.log"
UDP_SERVICE_NAME="udp-custom"

# Install UDP Custom
install_udp_custom() {
    echo_info "Installing UDP Custom..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating UDP Custom installation"
        sleep 2
        echo_success "UDP Custom service has been installed and started (simulated)"
        return
    fi
    
    # Check if already installed
    if systemctl is-active --quiet $UDP_SERVICE_NAME; then
        echo_warning "UDP Custom is already installed and running!"
        read -p "Do you want to reinstall it? (y/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            return
        fi
        
        # Stop and disable existing service
        systemctl stop $UDP_SERVICE_NAME
        systemctl disable $UDP_SERVICE_NAME
    fi
    
    # Install required dependencies
    apt update
    apt install -y git make gcc libudns-dev libevent-dev
    
    # Clone UDP Custom repository
    cd /tmp
    git clone https://github.com/ambrop72/badvpn.git
    cd badvpn
    
    # Build and install
    mkdir -p build
    cd build
    cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1
    make install
    
    # Create service directory
    mkdir -p /etc/udp-custom
    
    # Configure service
    cat > /etc/systemd/system/${UDP_SERVICE_NAME}.service << EOF
[Unit]
Description=UDP Custom by MasterMind (@bitcockiii)
After=network.target

[Service]
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr 0.0.0.0:${UDP_CUSTOM_PORT} --max-clients 1000 --max-connections-for-client 10 --client-socket-sndbuf 10000
Restart=always
RestartSec=3
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=udp-custom

[Install]
WantedBy=multi-user.target
EOF
    
    # Create configuration file
    cat > $DEFAULT_CONFIG_FILE << EOF
{
    "listen_addr": "0.0.0.0:${UDP_CUSTOM_PORT}",
    "max_clients": 1000,
    "max_connections_per_client": 10,
    "buffer_size": 10000,
    "creator": "MasterMind (@bitcockiii)"
}
EOF
    
    # Enable and start service
    systemctl daemon-reload
    systemctl enable $UDP_SERVICE_NAME
    systemctl start $UDP_SERVICE_NAME
    
    # Open port in firewall
    if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
        ufw allow $UDP_CUSTOM_PORT/udp
    fi
    
    echo_success "UDP Custom has been installed and started"
    echo_info "UDP Custom is now running on port $UDP_CUSTOM_PORT"
}

# Show UDP Custom configuration
show_udp_custom_config() {
    echo_info "UDP Custom Configuration"
    echo "─────────────────────────────────────"
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Showing simulated UDP Custom configuration"
        echo
        echo "Service: UDP Custom"
        echo "Status: Running (simulated)"
        echo "Port: $UDP_CUSTOM_PORT/UDP"
        echo "Config File: $DEFAULT_CONFIG_FILE"
        echo
        echo "Connection Command: badvpn-udpgw --client-mode --remote-host TARGET_IP:$UDP_CUSTOM_PORT"
        echo
        echo_warning "This is simulated data in test mode"
        echo
        echo_info "Service Control Options:"
        echo "1) Start/Stop Service"
        echo "2) Change Port"
        echo "3) Return to Main Menu"
        read -p "Enter option [1-3]: " option
        echo
        
        case $option in
            1) 
                echo_info "Test mode: Simulating service control"
                echo_success "Service control simulated"
                ;;
            2)
                echo_info "Test mode: Simulating port change"
                echo_success "Port change simulated"
                ;;
            3|*)
                return
                ;;
        esac
        
        return
    fi
    
    # Check if UDP Custom is installed
    if ! systemctl is-enabled --quiet $UDP_SERVICE_NAME 2>/dev/null; then
        echo_error "UDP Custom is not installed!"
        check_badvpn_installed
        return
    fi
    
    # Get service status
    local status=$(systemctl is-active $UDP_SERVICE_NAME)
    local port=$(grep -oP 'listen-addr\s+0.0.0.0:\K\d+' /etc/systemd/system/${UDP_SERVICE_NAME}.service)
    
    # Display information
    echo "Service: UDP Custom"
    if [[ "$status" == "active" ]]; then
        echo_success "Status: Running"
    else
        echo_error "Status: Stopped"
    fi
    
    echo "Port: ${port:-$UDP_CUSTOM_PORT}/UDP"
    echo "Config File: $DEFAULT_CONFIG_FILE"
    echo
    echo "Usage with SSH client: badvpn-udpgw --client-mode --remote-host YOUR_SERVER_IP:$UDP_CUSTOM_PORT"
    echo
    
    # Option menu
    echo_info "Service Control Options:"
    echo "1) $([[ "$status" == "active" ]] && echo "Stop" || echo "Start") Service"
    echo "2) Change Port"
    echo "3) Return to Main Menu"
    read -p "Enter option [1-3]: " option
    echo
    
    case $option in
        1) 
            if [[ "$status" == "active" ]]; then
                disable_udp_custom
            else
                enable_udp_custom
            fi
            ;;
        2)
            echo_info "Enter new port for UDP Custom (current: ${port:-$UDP_CUSTOM_PORT}, default: 36712, range: 1-65535)"
            read -p "Enter new port, press Enter to keep current, or type 'default' for port 36712: " new_port
            if [[ -n "$new_port" ]]; then
                if [[ "$new_port" == "default" ]]; then
                    change_udp_custom_port "36712"
                else
                    change_udp_custom_port "$new_port"
                fi
            fi
            ;;
        3|*)
            return
            ;;
    esac
}

# Change UDP Custom port
change_udp_custom_port() {
    local new_port="$1"
    
    # Validate port
    if ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1 ] || [ "$new_port" -gt 65535 ]; then
        echo_error "Invalid port number! Please enter a number between 1-65535."
        return 1
    fi
    
    # Get current port
    local current_port=$(grep -oP 'listen-addr\s+0.0.0.0:\K\d+' /etc/systemd/system/${UDP_SERVICE_NAME}.service || echo $UDP_CUSTOM_PORT)
    
    # Check if port is already in use
    if [[ "$new_port" != "$current_port" ]]; then
        if [[ "$IS_TEST_MODE" != true ]] && lsof -i:"$new_port" > /dev/null 2>&1; then
            echo_error "Port $new_port is already in use. Please choose a different port."
            return 1
        fi
    fi
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating changing UDP Custom port to $new_port"
        UDP_CUSTOM_PORT="$new_port"
        sleep 1
        echo_success "UDP Custom port changed to $new_port (simulated)"
        return
    fi
    
    echo_info "Changing UDP Custom port from $current_port to $new_port..."
    
    # Update service file
    sed -i "s|--listen-addr 0.0.0.0:[0-9]*|--listen-addr 0.0.0.0:$new_port|g" /etc/systemd/system/${UDP_SERVICE_NAME}.service
    
    # Update config file
    if [ -f "$DEFAULT_CONFIG_FILE" ]; then
        sed -i "s|\"listen_addr\": \"0.0.0.0:[0-9]*\"|\"listen_addr\": \"0.0.0.0:$new_port\"|g" $DEFAULT_CONFIG_FILE
    fi
    
    # Update firewall rules
    if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
        echo_info "Updating firewall rules..."
        
        # Remove old port rule if different
        if [[ "$current_port" != "$new_port" ]]; then
            ufw delete allow $current_port/udp
        fi
        
        # Add new port rule
        ufw allow $new_port/udp
        echo_success "Firewall updated to allow UDP traffic on port $new_port"
    fi
    
    # Restart service
    echo_info "Restarting UDP Custom service..."
    systemctl daemon-reload
    systemctl restart $UDP_SERVICE_NAME
    
    # Verify service is running
    if systemctl is-active --quiet $UDP_SERVICE_NAME; then
        echo_success "UDP Custom service is running on the new port"
    else
        echo_error "Failed to start UDP Custom service on the new port"
        echo_info "Attempting to revert to previous port..."
        sed -i "s|--listen-addr 0.0.0.0:[0-9]*|--listen-addr 0.0.0.0:$current_port|g" /etc/systemd/system/${UDP_SERVICE_NAME}.service
        
        # Revert config file as well
        if [ -f "$DEFAULT_CONFIG_FILE" ]; then
            sed -i "s|\"listen_addr\": \"0.0.0.0:[0-9]*\"|\"listen_addr\": \"0.0.0.0:$current_port\"|g" $DEFAULT_CONFIG_FILE
        fi
        
        systemctl daemon-reload
        systemctl restart $UDP_SERVICE_NAME
        return 1
    fi
    
    echo_success "UDP Custom port changed to $new_port"
    UDP_CUSTOM_PORT="$new_port"
    
    # Show updated connection details
    echo_info "Updated connection details:"
    echo "Usage with SSH client: badvpn-udpgw --client-mode --remote-host YOUR_SERVER_IP:$new_port"
}

# Enable UDP Custom service
enable_udp_custom() {
    echo_info "Starting UDP Custom service..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating UDP Custom service start"
        sleep 1
        echo_success "UDP Custom service started (simulated)"
        return
    fi
    
    # Check if service file exists
    if [ ! -f "/etc/systemd/system/${UDP_SERVICE_NAME}.service" ]; then
        echo_error "UDP Custom service file not found. Please reinstall UDP Custom."
        return 1
    fi
    
    # Start the service
    systemctl daemon-reload
    systemctl start $UDP_SERVICE_NAME
    
    # Verify service is running
    if systemctl is-active --quiet $UDP_SERVICE_NAME; then
        echo_success "UDP Custom service has been started"
        
        # Get current port
        local port=$(grep -oP 'listen-addr\s+0.0.0.0:\K\d+' /etc/systemd/system/${UDP_SERVICE_NAME}.service || echo $UDP_CUSTOM_PORT)
        
        # Show connection details
        echo_info "Connection details:"
        echo "Usage with SSH client: badvpn-udpgw --client-mode --remote-host YOUR_SERVER_IP:$port"
    else
        echo_error "Failed to start UDP Custom service"
        return 1
    fi
}

# Disable UDP Custom service
disable_udp_custom() {
    echo_info "Stopping UDP Custom service..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating UDP Custom service stop"
        sleep 1
        echo_success "UDP Custom service stopped (simulated)"
        return
    fi
    
    # Check if service is active
    if ! systemctl is-active --quiet $UDP_SERVICE_NAME; then
        echo_warning "UDP Custom service is already stopped"
        return
    fi
    
    # Stop the service
    systemctl stop $UDP_SERVICE_NAME
    
    # Verify service is stopped
    if ! systemctl is-active --quiet $UDP_SERVICE_NAME; then
        echo_success "UDP Custom service has been stopped"
    else
        echo_error "Failed to stop UDP Custom service"
        return 1
    fi
}

# Check if BadVPN is installed but service not configured
check_badvpn_installed() {
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: BadVPN check skipped"
        return
    fi
    
    # Check if BadVPN binary exists but service not configured
    if [ -f "/usr/local/bin/badvpn-udpgw" ] && [ ! -f "/etc/systemd/system/${UDP_SERVICE_NAME}.service" ]; then
        echo_info "BadVPN binary is installed but service is not configured"
        read -p "Would you like to configure and start the UDP Custom service? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            # Create service directory
            mkdir -p /etc/udp-custom
            
            # Configure service
            cat > /etc/systemd/system/${UDP_SERVICE_NAME}.service << EOF
[Unit]
Description=UDP Custom by MasterMind (@bitcockiii)
After=network.target

[Service]
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr 0.0.0.0:${UDP_CUSTOM_PORT} --max-clients 1000 --max-connections-for-client 10 --client-socket-sndbuf 10000
Restart=always
RestartSec=3
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=udp-custom

[Install]
WantedBy=multi-user.target
EOF
            
            # Create configuration file
            cat > $DEFAULT_CONFIG_FILE << EOF
{
    "listen_addr": "0.0.0.0:${UDP_CUSTOM_PORT}",
    "max_clients": 1000,
    "max_connections_per_client": 10,
    "buffer_size": 10000,
    "creator": "MasterMind (@bitcockiii)"
}
EOF
            
            # Enable and start service
            systemctl daemon-reload
            systemctl enable $UDP_SERVICE_NAME
            systemctl start $UDP_SERVICE_NAME
            
            # Open port in firewall
            if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
                ufw allow $UDP_CUSTOM_PORT/udp
            fi
            
            echo_success "UDP Custom service has been configured and started"
            echo_info "UDP Custom is now running on port $UDP_CUSTOM_PORT"
        fi
    elif [ ! -f "/usr/local/bin/badvpn-udpgw" ]; then
        echo_info "BadVPN binary is not installed. Would you like to install it?"
        read -p "Install BadVPN? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            install_badvpn
        fi
    fi
}

# Install just the BadVPN binary
install_badvpn() {
    echo_info "Installing BadVPN binary..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating BadVPN binary installation"
        sleep 2
        echo_success "BadVPN binary has been installed (simulated)"
        return
    fi
    
    # Install required dependencies
    apt update
    apt install -y git make gcc libudns-dev libevent-dev
    
    # Clone UDP Custom repository
    cd /tmp
    git clone https://github.com/ambrop72/badvpn.git
    cd badvpn
    
    # Build and install
    mkdir -p build
    cd build
    cmake .. -DBUILD_NOTHING_BY_DEFAULT=1 -DBUILD_UDPGW=1
    make install
    
    # Check if installation was successful
    if [ -f "/usr/local/bin/badvpn-udpgw" ]; then
        echo_success "BadVPN binary has been installed successfully"
        
        # Ask if user wants to configure the service
        read -p "Would you like to configure and start the UDP Custom service? (y/n): " -n 1 -r
        echo
        if [[ $REPLY =~ ^[Yy]$ ]]; then
            # Create service directory
            mkdir -p /etc/udp-custom
            
            # Configure service
            cat > /etc/systemd/system/${UDP_SERVICE_NAME}.service << EOF
[Unit]
Description=UDP Custom by MasterMind (@bitcockiii)
After=network.target

[Service]
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr 0.0.0.0:${UDP_CUSTOM_PORT} --max-clients 1000 --max-connections-for-client 10 --client-socket-sndbuf 10000
Restart=always
RestartSec=3
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=udp-custom

[Install]
WantedBy=multi-user.target
EOF
            
            # Create configuration file
            cat > $DEFAULT_CONFIG_FILE << EOF
{
    "listen_addr": "0.0.0.0:${UDP_CUSTOM_PORT}",
    "max_clients": 1000,
    "max_connections_per_client": 10,
    "buffer_size": 10000,
    "creator": "MasterMind (@bitcockiii)"
}
EOF
            
            # Enable and start service
            systemctl daemon-reload
            systemctl enable $UDP_SERVICE_NAME
            systemctl start $UDP_SERVICE_NAME
            
            # Open port in firewall
            if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
                ufw allow $UDP_CUSTOM_PORT/udp
            fi
            
            echo_success "UDP Custom service has been configured and started"
            echo_info "UDP Custom is now running on port $UDP_CUSTOM_PORT"
        fi
    else
        echo_error "Failed to install BadVPN binary"
        return 1
    fi
}

# Uninstall UDP Custom
uninstall_udp_custom() {
    echo_info "Uninstalling UDP Custom..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating UDP Custom uninstallation"
        sleep 2
        echo_success "UDP Custom has been uninstalled (simulated)"
        return
    fi
    
    # Check if installed
    if ! systemctl is-enabled --quiet $UDP_SERVICE_NAME 2>/dev/null; then
        echo_error "UDP Custom is not installed!"
        return
    fi
    
    # Get current port for firewall rule removal
    local port=$(grep -oP 'listen-addr\s+0.0.0.0:\K\d+' /etc/systemd/system/${UDP_SERVICE_NAME}.service || echo $UDP_CUSTOM_PORT)
    
    # Stop and disable service
    systemctl stop $UDP_SERVICE_NAME
    systemctl disable $UDP_SERVICE_NAME
    
    # Remove service file
    rm -f /etc/systemd/system/${UDP_SERVICE_NAME}.service
    
    # Remove configuration
    rm -rf /etc/udp-custom
    
    # Remove binary if it exists
    rm -f /usr/local/bin/badvpn-udpgw
    
    # Remove firewall rule
    if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
        ufw delete allow $port/udp
    fi
    
    systemctl daemon-reload
    
    echo_success "UDP Custom has been uninstalled"
}