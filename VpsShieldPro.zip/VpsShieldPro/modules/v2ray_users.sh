#!/bin/bash

# V2Ray User Management Module
# This module provides enhanced user management for V2Ray

# Function to manage V2Ray users
manage_v2ray_users() {
    echo_info "V2Ray User Management"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating V2Ray user management..."
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}V2Ray User Management${BLUE}                        ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Current V2Ray Users (Simulated):${NC}"
        echo -e "  ${WHITE}1. admin:${NC} ${CYAN}00112233-4455-6677-8899-aabbccddeeff${NC}"
        echo -e "  ${WHITE}2. user1:${NC} ${CYAN}10112233-4455-6677-8899-aabbccddeeff${NC}"
        echo -e "  ${WHITE}3. marketing:${NC} ${CYAN}20112233-4455-6677-8899-aabbccddeeff${NC}"
        
        echo -e "\n${YELLOW}🔹 Available V2Ray Configurations:${NC}"
        echo -e "  ${WHITE}1. WebSocket + TLS:${NC} ${GREEN}Secure connection with encryption${NC}"
        echo -e "  ${WHITE}2. WebSocket (non-TLS):${NC} ${YELLOW}Less secure, higher speed${NC}"
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} List all users"
        echo -e "  ${WHITE}4)${NC} Generate configuration for a user"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        sleep 2
        echo_success "V2Ray user management simulation complete"
        return
    fi
    
    # Check if V2Ray is installed
    if ! is_service_installed v2ray; then
        echo_error "V2Ray is not installed"
        echo_info "You can install it using options 3 or 4 from the main menu"
        return
    fi
    
    # Check if jq is installed
    if ! command_exists jq; then
        echo_info "Installing jq for JSON processing..."
        apt update -y
        apt install -y jq
    fi
    
    # Main user management loop
    while true; do
        clear
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}V2Ray User Management${BLUE}                        ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        # Check service status
        local status=$(systemctl is-active v2ray)
        
        echo -e "\n${YELLOW}🔹 Service Status:${NC}"
        if [[ "$status" == "active" ]]; then
            echo -e "  ${WHITE}V2Ray Status:${NC} ${GREEN}Active${NC}"
        else
            echo -e "  ${WHITE}V2Ray Status:${NC} ${RED}Inactive${NC} (run 'systemctl start v2ray' to start)"
        fi
        
        # List current V2Ray configurations
        echo -e "\n${YELLOW}🔹 Available V2Ray Configurations:${NC}"
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            echo -e "  ${WHITE}1. WebSocket + TLS:${NC} ${GREEN}Secure connection with encryption${NC}"
        fi
        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            echo -e "  ${WHITE}2. WebSocket (non-TLS):${NC} ${YELLOW}Less secure, higher speed${NC}"
        fi
        
        # List current V2Ray users
        echo -e "\n${YELLOW}🔹 Current V2Ray Users:${NC}"
        list_v2ray_users
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} List all users (with full details)"
        echo -e "  ${WHITE}4)${NC} Generate configuration for a user"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -ne "${CYAN}Enter your choice [1-5]: ${NC}"
        read -r choice
        
        case $choice in
            1) add_v2ray_user ;;           # Add new user
            2) delete_v2ray_user ;;        # Delete a user
            3) list_v2ray_users_detail ;;  # List users with details
            4) generate_v2ray_config ;;    # Generate config for a user
            5) break ;;                    # Return to main menu
            *) 
                echo_error "Invalid option. Please try again."
                sleep 1
                ;;
        esac
    done
}

# Function to list current V2Ray users (brief)
list_v2ray_users() {
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo -e "  ${GRAY}V2Ray is not properly configured.${NC}"
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "  ${GRAY}No users found.${NC}"
            return
        fi
        
        # Display users
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            
            # Truncate UUID for display
            local short_uuid="${uuid:0:8}...${uuid:24:12}"
            
            echo -e "  ${WHITE}$((i+1)). $email:${NC} ${CYAN}$short_uuid${NC}"
        done
    else
        echo -e "  ${GRAY}No users configuration found.${NC}"
    fi
}

# Function to list current V2Ray users (detailed)
list_v2ray_users_detail() {
    echo -e "\n${YELLOW}🔹 Detailed V2Ray User List:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo_error "No users found."
            sleep 1
            return
        fi
        
        # Get configuration details
        local protocol="VMess"
        local network="ws"
        local tls="none"
        local server_ip=$(get_public_ip)
        local port=0
        local path="/"
        
        # Determine if using TLS based on config
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            tls="tls"
            server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        elif [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            server_ip=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        else
            port=$(jq '.inbounds[0].port' /usr/local/etc/v2ray/config.json)
            if jq -e '.inbounds[0].streamSettings.wsSettings.path' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
                path=$(jq -r '.inbounds[0].streamSettings.wsSettings.path' /usr/local/etc/v2ray/config.json)
            fi
        fi
        
        # Display each user with full details
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            local alterid=$(jq -r ".inbounds[0].settings.clients[$i].alterId // 0" /usr/local/etc/v2ray/config.json)
            
            echo -e "\n${GREEN}User $((i+1)): $email${NC}"
            echo -e "${GREEN}---------------------------------------------------${NC}"
            echo -e "  ${WHITE}UUID:${NC}         ${CYAN}$uuid${NC}"
            echo -e "  ${WHITE}AlterID:${NC}      ${CYAN}$alterid${NC}"
            echo -e "  ${WHITE}Protocol:${NC}     ${CYAN}$protocol${NC}"
            
            # Connection details based on available configs
            if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                echo -e "\n  ${WHITE}WebSocket + TLS Configuration:${NC}"
                echo -e "  ${WHITE}Server:${NC}       ${CYAN}$server${NC}"
                echo -e "  ${WHITE}Port:${NC}         ${CYAN}$port${NC}"
                echo -e "  ${WHITE}Network:${NC}      ${CYAN}$network${NC}"
                echo -e "  ${WHITE}Path:${NC}         ${CYAN}$path${NC}"
                echo -e "  ${WHITE}TLS:${NC}          ${CYAN}tls${NC}"
            fi
            
            if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                local nontls_port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                local nontls_path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                
                echo -e "\n  ${WHITE}WebSocket (non-TLS) Configuration:${NC}"
                echo -e "  ${WHITE}Server:${NC}       ${CYAN}$server_ip${NC}"
                echo -e "  ${WHITE}Port:${NC}         ${CYAN}$nontls_port${NC}"
                echo -e "  ${WHITE}Network:${NC}      ${CYAN}$network${NC}"
                echo -e "  ${WHITE}Path:${NC}         ${CYAN}$nontls_path${NC}"
                echo -e "  ${WHITE}TLS:${NC}          ${CYAN}none${NC}"
            fi
        done
        
        # Wait for user to continue
        echo -e "\nPress Enter to continue..."
        read
    else
        echo_error "No users configuration found."
        sleep 1
    fi
}

# Function to add a new V2Ray user
add_v2ray_user() {
    echo -e "\n${YELLOW}🔹 Add a new V2Ray user:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Generate new UUID
    local new_uuid=$(generate_uuid)
    echo_info "Generated new UUID: $new_uuid"
    
    # Get user alias
    echo -ne "Enter a name/alias for this user (for reference): "
    read -r user_alias
    if [[ -z "$user_alias" ]]; then
        user_alias="user_$(date +%s)"
        echo_info "Using auto-generated alias: $user_alias"
    fi
    
    # Check if clients section exists in config
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Add new client to the array
        echo_info "Adding user '$user_alias' to V2Ray configuration..."
        jq --arg uuid "$new_uuid" --arg alias "$user_alias" '.inbounds[0].settings.clients += [{"id": $uuid, "alterId": 0, "email": $alias}]' /usr/local/etc/v2ray/config.json > /tmp/v2ray_config.json
        mv /tmp/v2ray_config.json /usr/local/etc/v2ray/config.json
        
        # Restart V2Ray to apply changes
        restart_service v2ray
        echo_success "New user '$user_alias' added successfully with UUID: $new_uuid"
        
        # Display configuration for the new user
        echo -e "\n${YELLOW}🔹 Configuration for new user '$user_alias':${NC}"
        
        # TLS config
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            
            echo -e "\n${GREEN}WebSocket + TLS Configuration:${NC}"
            echo -e "${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
            echo -e "${WHITE}Server:${NC}      ${CYAN}$server${NC}"
            echo -e "${WHITE}Port:${NC}        ${CYAN}$port${NC}"
            echo -e "${WHITE}UUID:${NC}        ${CYAN}$new_uuid${NC}"
            echo -e "${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
            echo -e "${WHITE}Network:${NC}     ${CYAN}ws${NC}"
            echo -e "${WHITE}Path:${NC}        ${CYAN}$path${NC}"
            echo -e "${WHITE}TLS:${NC}         ${CYAN}tls${NC}"
        fi
        
        # Non-TLS config
        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            local server_ip=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            
            echo -e "\n${GREEN}WebSocket (non-TLS) Configuration:${NC}"
            echo -e "${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
            echo -e "${WHITE}Server:${NC}      ${CYAN}$server_ip${NC}"
            echo -e "${WHITE}Port:${NC}        ${CYAN}$port${NC}"
            echo -e "${WHITE}UUID:${NC}        ${CYAN}$new_uuid${NC}"
            echo -e "${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
            echo -e "${WHITE}Network:${NC}     ${CYAN}ws${NC}"
            echo -e "${WHITE}Path:${NC}        ${CYAN}$path${NC}"
            echo -e "${WHITE}TLS:${NC}         ${CYAN}none${NC}"
        fi
        
        echo -e "\n${WHITE}Press Enter to continue...${NC}"
        read
    else
        echo_error "Could not find clients section in V2Ray config. User not added."
        sleep 2
    fi
}

# Function to delete a V2Ray user
delete_v2ray_user() {
    echo -e "\n${YELLOW}🔹 Delete a V2Ray user:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo_error "No users found."
            sleep 1
            return
        fi
        
        # Display users
        echo_info "Available users:"
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            
            # Truncate UUID for display
            local short_uuid="${uuid:0:8}...${uuid:24:12}"
            
            echo -e "  ${WHITE}$((i+1))${NC}) $email (UUID: $short_uuid)"
        done
        
        # Ask which user to remove
        echo -ne "\nEnter the number of the user to remove [1-$user_count]: "
        read -r user_num
        
        if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le "$user_count" ]; then
            # Adjust to zero-based index
            local idx=$((user_num-1))
            
            # Get user info for confirmation
            local user_email=$(jq -r ".inbounds[0].settings.clients[$idx].email // \"User$((idx+1))\"" /usr/local/etc/v2ray/config.json)
            local user_id=$(jq -r ".inbounds[0].settings.clients[$idx].id" /usr/local/etc/v2ray/config.json)
            
            echo_warning "Are you sure you want to remove user '$user_email' with UUID $user_id? (y/n)"
            read -r confirm
            
            if [[ $confirm =~ ^[Yy]$ ]]; then
                # Remove the selected user
                jq --argjson idx "$idx" 'del(.inbounds[0].settings.clients[$idx])' /usr/local/etc/v2ray/config.json > /tmp/v2ray_config.json
                mv /tmp/v2ray_config.json /usr/local/etc/v2ray/config.json
                
                # Restart V2Ray to apply changes
                restart_service v2ray
                echo_success "User '$user_email' removed successfully"
                sleep 2
            else
                echo_info "User removal cancelled"
                sleep 1
            fi
        else
            echo_error "Invalid user number"
            sleep 1
        fi
    else
        echo_error "Could not find clients section in V2Ray config."
        sleep 1
    fi
}

# Function to generate a configuration for a V2Ray user
generate_v2ray_config() {
    echo -e "\n${YELLOW}🔹 Generate V2Ray user configuration:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo_error "No users found."
            sleep 1
            return
        fi
        
        # Display users
        echo_info "Select a user to generate configuration:"
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            
            # Truncate UUID for display
            local short_uuid="${uuid:0:8}...${uuid:24:12}"
            
            echo -e "  ${WHITE}$((i+1))${NC}) $email (UUID: $short_uuid)"
        done
        
        # Ask which user to generate config for
        echo -ne "\nEnter the number of the user [1-$user_count]: "
        read -r user_num
        
        if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le "$user_count" ]; then
            # Adjust to zero-based index
            local idx=$((user_num-1))
            
            # Get user info
            local user_email=$(jq -r ".inbounds[0].settings.clients[$idx].email // \"User$((idx+1))\"" /usr/local/etc/v2ray/config.json)
            local user_id=$(jq -r ".inbounds[0].settings.clients[$idx].id" /usr/local/etc/v2ray/config.json)
            local alterid=$(jq -r ".inbounds[0].settings.clients[$idx].alterId // 0" /usr/local/etc/v2ray/config.json)
            
            # Ask which configuration format to generate
            echo -e "\n${YELLOW}🔹 Select configuration type:${NC}"
            echo -e "  ${WHITE}1)${NC} Text format (for manual input)"
            echo -e "  ${WHITE}2)${NC} VMess URL format (for easy import)"
            echo -e "  ${WHITE}3)${NC} Export to file"
            echo -ne "Enter choice [1-3]: "
            read -r format_choice
            
            # Choose which configuration to use (TLS or non-TLS)
            echo -e "\n${YELLOW}🔹 Choose connection type:${NC}"
            local connection_types=0
            if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                connection_types=$((connection_types+1))
                echo -e "  ${WHITE}1)${NC} WebSocket + TLS (secure)"
            fi
            if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                connection_types=$((connection_types+1))
                if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                    echo -e "  ${WHITE}2)${NC} WebSocket (non-TLS, faster)"
                else
                    echo -e "  ${WHITE}1)${NC} WebSocket (non-TLS, faster)"
                fi
            fi
            
            if [ "$connection_types" -eq 0 ]; then
                echo_error "No configurations available."
                sleep 1
                return
            fi
            
            echo -ne "Enter choice: "
            read -r conn_choice
            
            # Process the selection
            local server=""
            local port=0
            local network="ws"
            local path="/"
            local tls="none"
            
            # Determine which configuration to use
            if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ] && { [ "$conn_choice" -eq 1 ] || [ "$connection_types" -eq 1 -a "$conn_choice" -eq 1 ]; }; then
                # TLS configuration
                server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                tls="tls"
            elif [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ] && { [ "$conn_choice" -eq 2 ] || [ "$connection_types" -eq 1 -a "$conn_choice" -eq 1 ]; }; then
                # Non-TLS configuration
                server=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            else
                echo_error "Invalid selection."
                sleep 1
                return
            fi
            
            # Generate the chosen format
            case $format_choice in
                1)  # Text format
                    echo -e "\n${GREEN}Configuration for $user_email:${NC}"
                    echo -e "${GREEN}------------------------------------------------${NC}"
                    echo -e "${CYAN}Protocol:${NC} VMess"
                    echo -e "${CYAN}Server:${NC} $server"
                    echo -e "${CYAN}Port:${NC} $port"
                    echo -e "${CYAN}UUID:${NC} $user_id"
                    echo -e "${CYAN}AlterID:${NC} $alterid"
                    echo -e "${CYAN}Network:${NC} ws"
                    echo -e "${CYAN}Path:${NC} $path"
                    echo -e "${CYAN}TLS:${NC} $tls"
                    echo -e "${GREEN}------------------------------------------------${NC}"
                    ;;
                2)  # VMess URL format
                    # Create VMess URL
                    local vmess_obj=$(jo -p \
                        add="$server" \
                        port="$port" \
                        id="$user_id" \
                        aid="$alterid" \
                        net="ws" \
                        path="$path" \
                        host="$server" \
                        tls="$tls" \
                        ps="$user_email")
                    
                    local vmess_b64=$(echo -n "$vmess_obj" | base64 -w 0)
                    local vmess_url="vmess://$vmess_b64"
                    
                    echo -e "\n${GREEN}VMess URL for $user_email:${NC}"
                    echo -e "${GREEN}------------------------------------------------${NC}"
                    echo -e "$vmess_url"
                    echo -e "${GREEN}------------------------------------------------${NC}"
                    ;;
                3)  # Export to file
                    local config_file="$SCRIPT_DIR/v2ray_${user_email}_config.txt"
                    
                    echo -e "Protocol: VMess\nServer: $server\nPort: $port\nUUID: $user_id\nAlterID: $alterid\nNetwork: ws\nPath: $path\nTLS: $tls" > "$config_file"
                    
                    echo -e "\n${GREEN}Configuration for $user_email saved to:${NC}"
                    echo -e "$config_file"
                    ;;
                *)  
                    echo_error "Invalid selection."
                    ;;
            esac
            
            echo -e "\n${WHITE}Press Enter to continue...${NC}"
            read
        else
            echo_error "Invalid user number"
            sleep 1
        fi
    else
        echo_error "Could not find clients section in V2Ray config."
        sleep 1
    fi
}
