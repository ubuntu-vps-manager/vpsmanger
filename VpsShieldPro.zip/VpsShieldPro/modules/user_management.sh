#!/bin/bash

# Universal User Management Module
# This module provides user management functions that work across all services.

# Function to add a new user across all SSH services
add_universal_user() {
    local username=$1
    local password=$2
    
    if [[ -z "$username" || -z "$password" ]]; then
        echo_error "Username and password are required"
        return 1
    fi
    
    # Check if user already exists
    if id "$username" &>/dev/null; then
        echo_error "User '$username' already exists"
        return 1
    fi
    
    # Create the user
    echo_info "Creating new user '$username'..."
    useradd -m -s /bin/bash "$username"
    
    # Set password
    echo "$username:$password" | chpasswd
    
    # Set SSH access
    echo_info "Configuring SSH access for '$username'..."
    mkdir -p "/home/$username/.ssh"
    touch "/home/$username/.ssh/authorized_keys"
    chown -R "$username:$username" "/home/$username/.ssh"
    chmod 700 "/home/$username/.ssh"
    chmod 600 "/home/$username/.ssh/authorized_keys"
    
    # Create SSH UDP config if service exists
    if is_service_installed ssh-udp; then
        echo_info "Adding user to SSH UDP service..."
        # Add any SSH UDP specific configuration here
    fi
    
    # Create SSH WebSocket config if service exists
    if is_service_installed ssh_websocket; then
        echo_info "Adding user to SSH WebSocket service..."
        # SSH WebSocket already works with system users automatically
    fi
    
    # Create UDP Custom (BadVPN) config if service exists
    if is_service_installed udp-custom; then
        echo_info "Adding user to UDP Custom service..."
        # UDP Custom (BadVPN) works with any valid system user
    fi
    
    echo_success "User '$username' added successfully to all applicable SSH services"
    return 0
}

# Function to delete a user across all SSH services
delete_universal_user() {
    local username=$1
    
    if [[ -z "$username" ]]; then
        echo_error "Username is required"
        return 1
    fi
    
    # Check if user exists
    if ! id "$username" &>/dev/null; then
        echo_error "User '$username' does not exist"
        return 1
    fi
    
    # Delete the user and their home directory
    echo_info "Deleting user '$username' from all services..."
    userdel -r "$username"
    
    echo_success "User '$username' deleted successfully from all services"
    return 0
}

# Function to enable/disable a user across all SSH services
toggle_universal_user() {
    local username=$1
    local action=$2  # "enable" or "disable"
    
    if [[ -z "$username" || -z "$action" ]]; then
        echo_error "Username and action are required"
        return 1
    fi
    
    # Check if user exists
    if ! id "$username" &>/dev/null; then
        echo_error "User '$username' does not exist"
        return 1
    fi
    
    if [[ "$action" == "enable" ]]; then
        # Enable user
        echo_info "Enabling user '$username' across all services..."
        usermod -U "$username"
        echo_success "User '$username' has been enabled across all services"
    elif [[ "$action" == "disable" ]]; then
        # Disable user
        echo_info "Disabling user '$username' across all services..."
        usermod -L "$username"
        echo_success "User '$username' has been disabled across all services"
    else
        echo_error "Invalid action. Use 'enable' or 'disable'"
        return 1
    fi
    
    return 0
}

# Function to change a user's password across all SSH services
change_universal_password() {
    local username=$1
    local password=$2
    
    if [[ -z "$username" || -z "$password" ]]; then
        echo_error "Username and password are required"
        return 1
    fi
    
    # Check if user exists
    if ! id "$username" &>/dev/null; then
        echo_error "User '$username' does not exist"
        return 1
    fi
    
    # Change password
    echo_info "Changing password for user '$username'..."
    echo "$username:$password" | chpasswd
    
    echo_success "Password for user '$username' changed successfully across all services"
    return 0
}

# Universal user management interface
manage_universal_users() {
    echo_info "Universal User Management"
    
    # Main user management loop
    while true; do
        clear
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}Universal User Management${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        # Show applicable services
        echo -e "\n${YELLOW}🔹 Applicable Services:${NC}"
        echo -ne "  ${WHITE}•${NC} SSH: "
        if is_service_installed ssh; then echo -e "${GREEN}Installed${NC}"; else echo -e "${RED}Not Installed${NC}"; fi
        
        echo -ne "  ${WHITE}•${NC} SSH WebSocket: "
        if is_service_installed ssh_websocket; then echo -e "${GREEN}Installed${NC}"; else echo -e "${RED}Not Installed${NC}"; fi
        
        echo -ne "  ${WHITE}•${NC} SSH UDP: "
        if is_service_installed ssh-udp; then echo -e "${GREEN}Installed${NC}"; else echo -e "${RED}Not Installed${NC}"; fi
        
        echo -ne "  ${WHITE}•${NC} UDP Custom (BadVPN): "
        if is_service_installed udp-custom; then echo -e "${GREEN}Installed${NC}"; else echo -e "${RED}Not Installed${NC}"; fi
        
        # List current SSH users
        echo -e "\n${YELLOW}🔹 Current Users:${NC}"
        list_ssh_users
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} Enable/Disable a user"
        echo -e "  ${WHITE}4)${NC} Change user password"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -ne "${CYAN}Enter your choice [1-5]: ${NC}"
        read -r choice
        
        case $choice in
            1)  # Add new user
                echo -e "\n${YELLOW}🔹 Add a new user:${NC}"
                
                # Ask for username
                echo -ne "Enter username for the new user: "
                read -r username
                
                # Validate username
                if [[ -z "$username" ]]; then
                    echo_error "Username cannot be empty"
                    sleep 1
                    continue
                fi
                
                # Ask for password
                echo -ne "Enter password for the new user: "
                read -rs password
                echo
                
                # Validate password strength
                if [[ ${#password} -lt 8 ]]; then
                    echo_error "Password must be at least 8 characters long"
                    sleep 1
                    continue
                fi
                
                add_universal_user "$username" "$password"
                sleep 2
                ;;
                
            2)  # Delete a user
                echo -e "\n${YELLOW}🔹 Delete a user:${NC}"
                
                # Get the list of SSH users
                local users=$(awk -F':' '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd | grep -v "nobody")
                
                if [[ -z "$users" ]]; then
                    echo_error "No users found"
                    sleep 1
                    continue
                fi
                
                # Display users with numbers
                echo_info "Available users:"
                local i=1
                for user in $users; do
                    echo -e "  ${WHITE}$i)${NC} $user"
                    i=$((i+1))
                done
                
                # Ask which user to delete
                echo -ne "Enter the number of the user to delete: "
                read -r user_num
                
                # Validate input
                if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "$((i-1))" ]; then
                    echo_error "Invalid selection"
                    sleep 1
                    continue
                fi
                
                # Get the selected username
                local username=$(echo "$users" | sed -n "${user_num}p")
                
                # Confirm deletion
                echo_warning "Are you sure you want to delete user '$username'? (y/n)"
                read -r confirm
                
                if [[ ! $confirm =~ ^[Yy]$ ]]; then
                    echo_info "User deletion cancelled"
                    sleep 1
                    continue
                fi
                
                delete_universal_user "$username"
                sleep 2
                ;;
                
            3)  # Enable/Disable a user
                echo -e "\n${YELLOW}🔹 Enable/Disable a user:${NC}"
                
                # Get the list of SSH users
                local users=$(awk -F':' '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd | grep -v "nobody")
                
                if [[ -z "$users" ]]; then
                    echo_error "No users found"
                    sleep 1
                    continue
                fi
                
                # Display users with numbers and status
                echo_info "Available users:"
                local i=1
                for user in $users; do
                    local status="Enabled"
                    local status_color="${GREEN}"
                    
                    # Check if user is locked
                    if passwd -S "$user" | grep -q "L"; then
                        status="Disabled"
                        status_color="${RED}"
                    fi
                    
                    echo -e "  ${WHITE}$i)${NC} $user - ${status_color}$status${NC}"
                    i=$((i+1))
                done
                
                # Ask which user to toggle
                echo -ne "Enter the number of the user to enable/disable: "
                read -r user_num
                
                # Validate input
                if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "$((i-1))" ]; then
                    echo_error "Invalid selection"
                    sleep 1
                    continue
                fi
                
                # Get the selected username
                local username=$(echo "$users" | sed -n "${user_num}p")
                
                # Check current status
                local is_locked=false
                if passwd -S "$username" | grep -q "L"; then
                    is_locked=true
                fi
                
                # Toggle user status
                if [[ "$is_locked" == true ]]; then
                    toggle_universal_user "$username" "enable"
                else
                    toggle_universal_user "$username" "disable"
                fi
                
                sleep 2
                ;;
                
            4)  # Change user password
                echo -e "\n${YELLOW}🔹 Change user password:${NC}"
                
                # Get the list of SSH users
                local users=$(awk -F':' '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd | grep -v "nobody")
                
                if [[ -z "$users" ]]; then
                    echo_error "No users found"
                    sleep 1
                    continue
                fi
                
                # Display users with numbers
                echo_info "Available users:"
                local i=1
                for user in $users; do
                    echo -e "  ${WHITE}$i)${NC} $user"
                    i=$((i+1))
                done
                
                # Ask which user to change password for
                echo -ne "Enter the number of the user to change password: "
                read -r user_num
                
                # Validate input
                if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "$((i-1))" ]; then
                    echo_error "Invalid selection"
                    sleep 1
                    continue
                fi
                
                # Get the selected username
                local username=$(echo "$users" | sed -n "${user_num}p")
                
                # Ask for new password
                echo -ne "Enter new password for '$username': "
                read -rs password
                echo
                
                # Validate password strength
                if [[ ${#password} -lt 8 ]]; then
                    echo_error "Password must be at least 8 characters long"
                    sleep 1
                    continue
                fi
                
                change_universal_password "$username" "$password"
                sleep 2
                ;;
                
            5)  # Return to main menu
                break 
                ;;
                
            *)  # Invalid option
                echo_error "Invalid option. Please try again."
                sleep 1
                ;;
        esac
    done
}