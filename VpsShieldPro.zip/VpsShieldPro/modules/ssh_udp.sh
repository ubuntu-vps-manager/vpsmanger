#!/bin/bash
# SSH UDP Module
# Created by MasterMind (@bitcockiii)

# Default SSH UDP port
SSH_UDP_PORT="1194"
SSH_UDP_SERVICE_NAME="ssh-udp"
SSH_UDP_CONFIG_DIR="/etc/ssh-udp"
SSH_UDP_LOG_FILE="$SCRIPT_DIR/logs/ssh-udp.log"

# Install SSH UDP
install_ssh_udp() {
    echo_info "Installing SSH over UDP..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH UDP installation"
        sleep 2
        echo_success "SSH UDP service has been installed and started (simulated)"
        return
    fi
    
    # Check if already installed
    if systemctl is-active --quiet $SSH_UDP_SERVICE_NAME; then
        echo_warning "SSH UDP is already installed and running!"
        read -p "Do you want to reinstall it? (y/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            return
        fi
        
        # Stop and disable existing service
        systemctl stop $SSH_UDP_SERVICE_NAME
        systemctl disable $SSH_UDP_SERVICE_NAME
    fi
    
    # Install required dependencies
    apt update
    apt install -y openssh-server ufw iptables-persistent socat

    # Create config directory
    mkdir -p $SSH_UDP_CONFIG_DIR

    # Generate SSH UDP service configuration
    cat > /etc/systemd/system/${SSH_UDP_SERVICE_NAME}.service << EOF
[Unit]
Description=SSH over UDP Service by MasterMind (@bitcockiii)
After=network.target

[Service]
ExecStart=/usr/bin/socat UDP-LISTEN:${SSH_UDP_PORT},reuseaddr,fork TCP:127.0.0.1:22
Restart=always
RestartSec=3
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=ssh-udp

[Install]
WantedBy=multi-user.target
EOF
    
    # Create SSH UDP configuration file
    cat > $SSH_UDP_CONFIG_DIR/config.json << EOF
{
    "listen_port": ${SSH_UDP_PORT},
    "target_port": 22,
    "created_by": "MasterMind (@bitcockiii)"
}
EOF
    
    # Enable and start service
    systemctl daemon-reload
    systemctl enable $SSH_UDP_SERVICE_NAME
    systemctl start $SSH_UDP_SERVICE_NAME
    
    # Open port in firewall
    if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
        ufw allow $SSH_UDP_PORT/udp
    fi
    
    echo_success "SSH UDP has been installed and started"
    echo_info "SSH UDP is now running on port $SSH_UDP_PORT/UDP"
    echo_info "You can connect using: socat TCP-LISTEN:LOCAL_PORT,fork UDP:YOUR_SERVER_IP:$SSH_UDP_PORT"
    echo_info "Then in another terminal: ssh -p LOCAL_PORT localhost"
}

# Show SSH UDP configuration
show_ssh_udp_config() {
    echo_info "SSH UDP Configuration"
    echo "─────────────────────────────────────"
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Showing simulated SSH UDP configuration"
        echo
        echo "Service: SSH over UDP"
        echo "Status: Running (simulated)"
        echo "UDP Port: $SSH_UDP_PORT"
        echo "Config Directory: $SSH_UDP_CONFIG_DIR"
        echo
        echo "Client Connection:"
        echo "1. Run: socat TCP-LISTEN:2222,fork UDP:YOUR_SERVER_IP:$SSH_UDP_PORT"
        echo "2. Connect: ssh -p 2222 username@localhost"
        echo
        echo_warning "This is simulated data in test mode"
        return
    fi
    
    # Check if SSH UDP is installed
    if ! systemctl is-enabled --quiet $SSH_UDP_SERVICE_NAME 2>/dev/null; then
        echo_error "SSH UDP is not installed!"
        return
    fi
    
    # Get service status and port
    local status=$(systemctl is-active $SSH_UDP_SERVICE_NAME)
    local port=$(grep -oP 'UDP-LISTEN:\K\d+(?=,reuseaddr)' /etc/systemd/system/${SSH_UDP_SERVICE_NAME}.service || echo $SSH_UDP_PORT)
    
    # Display information
    echo "Service: SSH over UDP"
    if [[ "$status" == "active" ]]; then
        echo_success "Status: Running"
    else
        echo_error "Status: Stopped"
    fi
    
    echo "UDP Port: $port"
    echo "Config Directory: $SSH_UDP_CONFIG_DIR"
    echo
    echo "Client Connection:"
    echo "1. Run: socat TCP-LISTEN:2222,fork UDP:YOUR_SERVER_IP:$port"
    echo "2. Connect: ssh -p 2222 username@localhost"
    echo
    
    # Option to adjust port
    echo_info "Would you like to adjust the SSH UDP port? (current: $port)"
    read -p "Enter new port or press Enter to keep current: " new_port
    
    if [[ -n "$new_port" ]]; then
        change_ssh_udp_port "$new_port"
    fi
}

# Change SSH UDP port
change_ssh_udp_port() {
    local new_port="$1"
    
    # Validate port
    if ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1 ] || [ "$new_port" -gt 65535 ]; then
        echo_error "Invalid port number! Please enter a number between 1-65535."
        return 1
    fi
    
    # Get current port for firewall rule removal
    local current_port=$(grep -oP 'UDP-LISTEN:\K\d+(?=,reuseaddr)' /etc/systemd/system/${SSH_UDP_SERVICE_NAME}.service || echo $SSH_UDP_PORT)
    
    # Check if port is already in use
    if [[ "$new_port" != "$current_port" ]]; then
        if [[ "$IS_TEST_MODE" != true ]] && lsof -i:"$new_port" > /dev/null 2>&1; then
            echo_error "Port $new_port is already in use. Please choose a different port."
            return 1
        fi
    fi
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating changing SSH UDP port to $new_port"
        SSH_UDP_PORT="$new_port"
        sleep 1
        echo_success "SSH UDP port changed to $new_port (simulated)"
        return
    fi
    
    echo_info "Changing SSH UDP port from $current_port to $new_port..."
    
    # Update service file
    sed -i "s|UDP-LISTEN:${current_port},reuseaddr|UDP-LISTEN:${new_port},reuseaddr|g" /etc/systemd/system/${SSH_UDP_SERVICE_NAME}.service
    
    # Update config file
    if [ -f "$SSH_UDP_CONFIG_DIR/config.json" ]; then
        sed -i "s|\"listen_port\": ${current_port}|\"listen_port\": ${new_port}|g" $SSH_UDP_CONFIG_DIR/config.json
    fi
    
    # Update firewall rules
    if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
        echo_info "Updating firewall rules..."
        
        # Remove old port rule if different
        if [[ "$current_port" != "$new_port" ]]; then
            ufw delete allow $current_port/udp
        fi
        
        # Add new port rule
        ufw allow $new_port/udp
        echo_success "Firewall updated to allow UDP traffic on port $new_port"
    fi
    
    # Restart service
    echo_info "Restarting SSH UDP service..."
    systemctl daemon-reload
    systemctl restart $SSH_UDP_SERVICE_NAME
    
    # Verify service is running
    if systemctl is-active --quiet $SSH_UDP_SERVICE_NAME; then
        echo_success "SSH UDP service is running on the new port"
    else
        echo_error "Failed to start SSH UDP service on the new port"
        echo_info "Attempting to revert to previous port..."
        sed -i "s|UDP-LISTEN:${new_port},reuseaddr|UDP-LISTEN:${current_port},reuseaddr|g" /etc/systemd/system/${SSH_UDP_SERVICE_NAME}.service
        
        # Revert config file
        if [ -f "$SSH_UDP_CONFIG_DIR/config.json" ]; then
            sed -i "s|\"listen_port\": ${new_port}|\"listen_port\": ${current_port}|g" $SSH_UDP_CONFIG_DIR/config.json
        fi
        
        systemctl daemon-reload
        systemctl restart $SSH_UDP_SERVICE_NAME
        return 1
    fi
    
    echo_success "SSH UDP port changed to $new_port"
    SSH_UDP_PORT="$new_port"
    
    # Show updated connection details
    echo_info "Updated connection details:"
    echo "1. Run: socat TCP-LISTEN:2222,fork UDP:YOUR_SERVER_IP:$new_port"
    echo "2. Connect: ssh -p 2222 username@localhost"
}

# Uninstall SSH UDP
uninstall_ssh_udp() {
    echo_info "Uninstalling SSH UDP..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH UDP uninstallation"
        sleep 2
        echo_success "SSH UDP has been uninstalled (simulated)"
        return
    fi
    
    # Check if installed
    if ! systemctl is-enabled --quiet $SSH_UDP_SERVICE_NAME 2>/dev/null; then
        echo_error "SSH UDP is not installed!"
        return
    fi
    
    # Get current port for firewall rule removal
    local port=$(grep -oP 'UDP-LISTEN:\K\d+(?=,reuseaddr)' /etc/systemd/system/${SSH_UDP_SERVICE_NAME}.service || echo $SSH_UDP_PORT)
    
    # Stop and disable service
    systemctl stop $SSH_UDP_SERVICE_NAME
    systemctl disable $SSH_UDP_SERVICE_NAME
    
    # Remove service file
    rm -f /etc/systemd/system/${SSH_UDP_SERVICE_NAME}.service
    
    # Remove configuration directory
    rm -rf $SSH_UDP_CONFIG_DIR
    
    # Remove firewall rule
    if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
        ufw delete allow $port/udp
    fi
    
    systemctl daemon-reload
    
    echo_success "SSH UDP has been uninstalled"
}