#!/bin/bash

# SSH WebSocket User Management Module
# This module extends the SSH WebSocket functionality with multi-user support

# Function to manage SSH WebSocket users
manage_ssh_ws_users() {
    echo_info "SSH WebSocket User Management"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH WebSocket user management..."
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}SSH WebSocket User Management${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Current Users (Simulated):${NC}"
        echo -e "  ${WHITE}1. admin${NC} - ${CYAN}Enabled${NC}"
        echo -e "  ${WHITE}2. user1${NC} - ${CYAN}Enabled${NC}"
        echo -e "  ${WHITE}3. demo${NC} - ${RED}Disabled${NC}"
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} Enable/Disable a user"
        echo -e "  ${WHITE}4)${NC} Change user password"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -e "\n${YELLOW}🔹 Note:${NC}"
        echo -e "  ${GRAY}• User management requires system user creation${NC}"
        echo -e "  ${GRAY}• Passwords must be at least 8 characters${NC}"
        echo -e "  ${GRAY}• Each user can have their own connection limits${NC}"
        
        sleep 2
        echo_success "SSH WebSocket user management simulation complete"
        return
    fi
    
    # Check if SSH WebSocket is installed
    if ! is_service_installed ssh_websocket; then
        echo_error "SSH WebSocket is not installed"
        echo_info "You can install it using option 7 from the main menu"
        return
    fi
    
    # Main user management loop
    while true; do
        clear
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}SSH WebSocket User Management${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        # List current SSH users
        echo -e "\n${YELLOW}🔹 Current SSH Users:${NC}"
        list_ssh_users
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} Enable/Disable a user"
        echo -e "  ${WHITE}4)${NC} Change user password"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -ne "${CYAN}Enter your choice [1-5]: ${NC}"
        read -r choice
        
        case $choice in
            1) add_ssh_user ;;            # Add new user
            2) delete_ssh_user ;;         # Delete a user
            3) toggle_ssh_user ;;         # Enable/Disable a user
            4) change_ssh_password ;;     # Change user password
            5) break ;;                   # Return to main menu
            *) 
                echo_error "Invalid option. Please try again."
                sleep 1
                ;;
        esac
    done
}

# Function to list current SSH users
list_ssh_users() {
    # Get list of SSH users (filter system users)
    local users=$(awk -F':' '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd | grep -v "nobody")
    local count=0
    
    if [[ -z "$users" ]]; then
        echo -e "  ${GRAY}No SSH users found.${NC}"
        return
    fi
    
    # Check each user status
    for user in $users; do
        local status="Enabled"
        local status_color="${GREEN}"
        
        # Check if user is locked
        if passwd -S "$user" | grep -q "L"; then
            status="Disabled"
            status_color="${RED}"
        fi
        
        count=$((count+1))
        echo -e "  ${WHITE}$count. $user${NC} - ${status_color}$status${NC}"
    done
}

# Function to add a new SSH user
add_ssh_user() {
    echo -e "\n${YELLOW}🔹 Add a new SSH user:${NC}"
    
    # Ask for username
    echo -ne "Enter username for the new user: "
    read -r username
    
    # Validate username
    if [[ -z "$username" ]]; then
        echo_error "Username cannot be empty"
        sleep 1
        return
    fi
    
    if id "$username" &>/dev/null; then
        echo_error "User '$username' already exists"
        sleep 1
        return
    fi
    
    # Ask for password
    echo -ne "Enter password for the new user: "
    read -rs password
    echo
    
    # Validate password strength
    if [[ ${#password} -lt 8 ]]; then
        echo_error "Password must be at least 8 characters long"
        sleep 1
        return
    fi
    
    # Create the user
    echo_info "Creating new user '$username'..."
    useradd -m -s /bin/bash "$username"
    
    # Set password
    echo "$username:$password" | chpasswd
    
    # Set SSH access
    echo_info "Configuring SSH access for '$username'..."
    mkdir -p "/home/$username/.ssh"
    touch "/home/$username/.ssh/authorized_keys"
    chown -R "$username:$username" "/home/$username/.ssh"
    chmod 700 "/home/$username/.ssh"
    chmod 600 "/home/$username/.ssh/authorized_keys"
    
    echo_success "User '$username' created successfully"
    echo_info "This user can now connect via SSH WebSocket"
    sleep 2
}

# Function to delete an SSH user
delete_ssh_user() {
    echo -e "\n${YELLOW}🔹 Delete an SSH user:${NC}"
    
    # Get the list of SSH users
    local users=$(awk -F':' '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd | grep -v "nobody")
    
    if [[ -z "$users" ]]; then
        echo_error "No SSH users found"
        sleep 1
        return
    fi
    
    # Display users with numbers
    echo_info "Available users:"
    local i=1
    for user in $users; do
        echo -e "  ${WHITE}$i)${NC} $user"
        i=$((i+1))
    done
    
    # Ask which user to delete
    echo -ne "Enter the number of the user to delete: "
    read -r user_num
    
    # Validate input
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "$i" ]; then
        echo_error "Invalid selection"
        sleep 1
        return
    fi
    
    # Get the selected username
    local username=$(echo "$users" | sed -n "${user_num}p")
    
    # Confirm deletion
    echo_warning "Are you sure you want to delete user '$username'? (y/n)"
    read -r confirm
    
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        echo_info "User deletion cancelled"
        sleep 1
        return
    fi
    
    # Delete the user
    echo_info "Deleting user '$username'..."
    userdel -r "$username"
    
    echo_success "User '$username' deleted successfully"
    sleep 2
}

# Function to enable/disable an SSH user
toggle_ssh_user() {
    echo -e "\n${YELLOW}🔹 Enable/Disable an SSH user:${NC}"
    
    # Get the list of SSH users
    local users=$(awk -F':' '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd | grep -v "nobody")
    
    if [[ -z "$users" ]]; then
        echo_error "No SSH users found"
        sleep 1
        return
    fi
    
    # Display users with numbers and status
    echo_info "Available users:"
    local i=1
    for user in $users; do
        local status="Enabled"
        local status_color="${GREEN}"
        
        # Check if user is locked
        if passwd -S "$user" | grep -q "L"; then
            status="Disabled"
            status_color="${RED}"
        fi
        
        echo -e "  ${WHITE}$i)${NC} $user - ${status_color}$status${NC}"
        i=$((i+1))
    done
    
    # Ask which user to toggle
    echo -ne "Enter the number of the user to enable/disable: "
    read -r user_num
    
    # Validate input
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "$((i-1))" ]; then
        echo_error "Invalid selection"
        sleep 1
        return
    fi
    
    # Get the selected username
    local username=$(echo "$users" | sed -n "${user_num}p")
    
    # Check current status
    local is_locked=false
    if passwd -S "$username" | grep -q "L"; then
        is_locked=true
    fi
    
    # Toggle user status
    if [[ "$is_locked" == true ]]; then
        # Unlock the user
        echo_info "Enabling user '$username'..."
        usermod -U "$username"
        echo_success "User '$username' has been enabled"
    else
        # Lock the user
        echo_info "Disabling user '$username'..."
        usermod -L "$username"
        echo_success "User '$username' has been disabled"
    fi
    
    sleep 2
}

# Function to change an SSH user's password
change_ssh_password() {
    echo -e "\n${YELLOW}🔹 Change SSH user password:${NC}"
    
    # Get the list of SSH users
    local users=$(awk -F':' '$3 >= 1000 && $3 != 65534 {print $1}' /etc/passwd | grep -v "nobody")
    
    if [[ -z "$users" ]]; then
        echo_error "No SSH users found"
        sleep 1
        return
    fi
    
    # Display users with numbers
    echo_info "Available users:"
    local i=1
    for user in $users; do
        echo -e "  ${WHITE}$i)${NC} $user"
        i=$((i+1))
    done
    
    # Ask which user to change password for
    echo -ne "Enter the number of the user to change password: "
    read -r user_num
    
    # Validate input
    if ! [[ "$user_num" =~ ^[0-9]+$ ]] || [ "$user_num" -lt 1 ] || [ "$user_num" -gt "$((i-1))" ]; then
        echo_error "Invalid selection"
        sleep 1
        return
    fi
    
    # Get the selected username
    local username=$(echo "$users" | sed -n "${user_num}p")
    
    # Ask for new password
    echo -ne "Enter new password for '$username': "
    read -rs password
    echo
    
    # Validate password strength
    if [[ ${#password} -lt 8 ]]; then
        echo_error "Password must be at least 8 characters long"
        sleep 1
        return
    fi
    
    # Change password
    echo_info "Changing password for user '$username'..."
    echo "$username:$password" | chpasswd
    
    echo_success "Password for user '$username' changed successfully"
    sleep 2
}
