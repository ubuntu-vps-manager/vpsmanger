#!/bin/bash

# Install SSH WebSocket Tunneling
install_ssh_websocket() {
    echo_info "Installing SSH WebSocket Tunneling..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH WebSocket Tunneling installation..."
        local port=443
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}SSH WebSocket Tunneling Setup${BLUE}                   ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 What is SSH WebSocket Tunneling?${NC}"
        echo -e "${GRAY}SSH WebSocket Tunneling allows SSH connections to be tunneled through"
        echo -e "WebSockets, which can bypass network restrictions that block standard"
        echo -e "SSH connections on port 22. This enables secure shell access in restricted"
        echo -e "network environments.${NC}"
        
        echo -e "\n${YELLOW}🔹 Generated Configuration:${NC}"
        echo -e "  ${WHITE}WebSocket Port:${NC} ${CYAN}$port${NC}"
        echo -e "  ${WHITE}SSH Port:${NC}       ${CYAN}22${NC} (default SSH port)"
        
        echo -e "\n${YELLOW}🔹 Client Connection Options:${NC}"
        echo -e "  ${WHITE}•${NC} Command-line clients with WebSocket proxy support"
        echo -e "  ${WHITE}•${NC} Web-based SSH clients that support WebSocket tunneling"
        echo -e "  ${WHITE}•${NC} SSH clients with WebSocket plugins or extensions"
        
        sleep 2
        echo_success "SSH WebSocket Tunneling simulated installation complete"
        return
    fi
    
    # Check if SSH WebSocket is already installed
    if is_service_installed ssh_websocket; then
        echo_warning "SSH WebSocket is already installed"
        echo_info "Do you want to reinstall it? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
        
        # Stop and disable SSH WebSocket service
        stop_service ssh_websocket
        systemctl disable ssh_websocket
    fi
    
    # Ensure SSH is installed and running
    if ! command_exists sshd; then
        echo_info "Installing OpenSSH server..."
        apt update -y
        apt install -y openssh-server
        
        # Enable and start SSH service
        systemctl enable ssh
        systemctl start ssh
    fi
    
    # Install required packages
    echo_info "Installing required packages..."
    apt update -y
    apt install -y python3 python3-pip openssl net-tools
    
    # Install Python WebSocket library
    echo_info "Installing Python WebSocket library..."
    pip3 install websockets asyncio
    
    # Set default port for SSH WebSocket to 443
    local ws_port=443
    
    # Check if port 443 is available, if not, find an available port
    if ! is_port_available "$ws_port"; then
        echo_warning "Default port 443 is not available. Finding an alternative port..."
        ws_port=$(find_available_port)
    fi
    
    # Create the SSH WebSocket tunneling script
    echo_info "Creating SSH WebSocket tunneling script..."
    mkdir -p /usr/local/bin
    
    cat > /usr/local/bin/ssh_websocket.py << 'EOF'
#!/usr/bin/env python3

import asyncio
import websockets
import ssl
import argparse
import logging
import socket
import os
import sys
from concurrent.futures import ThreadPoolExecutor

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('ssh-websocket')

# Global variables
executor = ThreadPoolExecutor(max_workers=100)
clients = set()

async def handle_ssh_connection(websocket, ssh_host, ssh_port):
    """Handle SSH connection via WebSocket"""
    try:
        # Create TCP socket to SSH server
        ssh_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        ssh_socket.connect((ssh_host, ssh_port))
        ssh_socket.setblocking(False)

        # Add client to active clients set
        clients.add(websocket)
        logger.info(f"New connection from {websocket.remote_address}. {len(clients)} clients connected.")

        # Create tasks for bidirectional communication
        loop = asyncio.get_event_loop()
        
        # WebSocket to SSH
        async def ws_to_ssh():
            try:
                async for message in websocket:
                    await loop.run_in_executor(executor, lambda: ssh_socket.sendall(message))
            except Exception as e:
                logger.error(f"Error in WebSocket to SSH: {e}")
            finally:
                # Close SSH socket when WebSocket is closed
                ssh_socket.close()
        
        # SSH to WebSocket
        async def ssh_to_ws():
            try:
                while True:
                    # Read data from SSH socket
                    data = await loop.run_in_executor(executor, lambda: ssh_socket.recv(4096))
                    if not data:
                        break
                    await websocket.send(data)
            except Exception as e:
                logger.error(f"Error in SSH to WebSocket: {e}")
            finally:
                # Close WebSocket when SSH connection is closed
                await websocket.close()
        
        # Run the tasks concurrently
        await asyncio.gather(ws_to_ssh(), ssh_to_ws())

    except Exception as e:
        logger.error(f"Connection error: {e}")
    finally:
        clients.remove(websocket)
        logger.info(f"Connection closed. {len(clients)} clients connected.")

async def server_handler(websocket, path, ssh_host, ssh_port):
    """Entry point for new WebSocket connections"""
    try:
        await handle_ssh_connection(websocket, ssh_host, ssh_port)
    except Exception as e:
        logger.error(f"Error handling connection: {e}")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='SSH over WebSocket server')
    parser.add_argument('--ws-host', default='0.0.0.0', help='WebSocket host to bind (default: 0.0.0.0)')
    parser.add_argument('--ws-port', type=int, required=True, help='WebSocket port to bind')
    parser.add_argument('--ssh-host', default='127.0.0.1', help='SSH server host (default: 127.0.0.1)')
    parser.add_argument('--ssh-port', type=int, default=22, help='SSH server port (default: 22)')
    
    args = parser.parse_args()
    
    logger.info(f"Starting SSH WebSocket server on {args.ws_host}:{args.ws_port}")
    logger.info(f"Tunneling to SSH server at {args.ssh_host}:{args.ssh_port}")

    start_server = websockets.serve(
        lambda ws, path: server_handler(ws, path, args.ssh_host, args.ssh_port),
        args.ws_host, 
        args.ws_port
    )

    asyncio.get_event_loop().run_until_complete(start_server)
    logger.info(f"Server started. Listening on {args.ws_host}:{args.ws_port}")
    
    try:
        asyncio.get_event_loop().run_forever()
    except KeyboardInterrupt:
        logger.info("Server shutting down...")
    finally:
        logger.info("Server shut down")

if __name__ == "__main__":
    main()
EOF

    # Make script executable
    chmod +x /usr/local/bin/ssh_websocket.py
    
    # Create systemd service for SSH WebSocket
    echo_info "Creating systemd service for SSH WebSocket..."
    
    cat > /etc/systemd/system/ssh_websocket.service << EOF
[Unit]
Description=SSH WebSocket Tunneling Service
After=network.target

[Service]
Type=simple
User=root
Environment=WS_PORT=$ws_port
Environment=SSH_PORT=22
ExecStart=/usr/bin/python3 /usr/local/bin/ssh_websocket.py --ws-port \${WS_PORT} --ssh-port \${SSH_PORT}
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd daemon
    systemctl daemon-reload
    
    # Start and enable SSH WebSocket service
    systemctl start ssh_websocket
    systemctl enable ssh_websocket
    
    # Verify that SSH WebSocket is running
    if ! is_service_active ssh_websocket; then
        echo_error "SSH WebSocket failed to start. Please check the logs with 'journalctl -u ssh_websocket'"
        return
    fi
    
    # Configure firewall
    configure_firewall
    
    # Generate client configuration information
    local server_ip=$(get_public_ip)
    echo_success "SSH WebSocket Tunneling has been installed successfully!"
    echo_info "You can connect to your SSH server through the WebSocket tunnel using:"
    echo -e "${GREEN}------------------------------------------------${NC}"
    echo -e "${CYAN}WebSocket URL:${NC} ws://$server_ip:$ws_port"
    echo -e "${CYAN}SSH Server:${NC} 127.0.0.1"
    echo -e "${CYAN}SSH Port:${NC} 22"
    echo -e "${GREEN}------------------------------------------------${NC}"
    
    # Save configuration to file
    local config_info="WebSocket URL: ws://$server_ip:$ws_port\nSSH Server: 127.0.0.1\nSSH Port: 22"
    echo -e "$config_info" > "$SCRIPT_DIR/ssh_ws_config.txt"
    echo_info "Configuration saved to $SCRIPT_DIR/ssh_ws_config.txt"
    
    # Provide client usage information
    echo_info "To connect using WebSocket SSH clients:"
    echo_info "1. Configure your SSH client to use a SOCKS proxy on localhost (typically port 1080)"
    echo_info "2. Use a WebSocket to SOCKS proxy tool to connect to the WebSocket server"
    echo_info "3. Connect to your SSH server through the SOCKS proxy"
}

# Show SSH WebSocket configuration
show_ssh_ws_config() {
    echo_info "SSH WebSocket Configuration"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH WebSocket configuration display..."
        local port=$(generate_random_port)
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║            ${GREEN}SSH WebSocket Configuration${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Service Status:${NC}"
        echo -e "  ${WHITE}Status:${NC}      ${YELLOW}[SIMULATED] Active${NC}"
        
        echo -e "\n${YELLOW}🔹 Connection Details:${NC}"
        echo -e "  ${WHITE}WebSocket URL:${NC} ${CYAN}ws://198.51.100.1:$port${NC}"
        echo -e "  ${WHITE}SSH Server:${NC}   ${CYAN}127.0.0.1${NC}"
        echo -e "  ${WHITE}SSH Port:${NC}     ${CYAN}22${NC}"
        
        echo -e "\n${YELLOW}🔹 Port Adjustment (Simulated):${NC}"
        echo -e "  ${WHITE}1)${NC} Change WebSocket port (current: $port)"
        echo -e "  ${WHITE}2)${NC} Change SSH port (current: 22)"
        echo -e "  ${WHITE}3)${NC} Continue without changes"
        
        echo -e "\n${YELLOW}🔹 Management Commands:${NC}"
        echo -e "  ${GRAY}• Start:${NC}   ${WHITE}systemctl start ssh_websocket${NC}"
        echo -e "  ${GRAY}• Stop:${NC}    ${WHITE}systemctl stop ssh_websocket${NC}"
        echo -e "  ${GRAY}• Restart:${NC} ${WHITE}systemctl restart ssh_websocket${NC}"
        echo -e "  ${GRAY}• Status:${NC}  ${WHITE}systemctl status ssh_websocket${NC}"
        
        return
    fi
    
    # Check if SSH WebSocket is installed
    if ! is_service_installed ssh_websocket; then
        echo_error "SSH WebSocket is not installed"
        echo_info "You can install it using option 7 from the main menu"
        return
    fi
    
    # Get service status and configuration
    local status=$(systemctl is-active ssh_websocket)
    local ws_port=$(grep -o 'WS_PORT=[0-9]*' /etc/systemd/system/ssh_websocket.service | cut -d= -f2)
    local ssh_port=$(grep -o 'SSH_PORT=[0-9]*' /etc/systemd/system/ssh_websocket.service | cut -d= -f2)
    local server_ip=$(get_public_ip)
    
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║            ${GREEN}SSH WebSocket Configuration${BLUE}                    ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    echo -e "\n${YELLOW}🔹 Service Status:${NC}"
    if [[ "$status" == "active" ]]; then
        echo -e "  ${WHITE}Status:${NC}      ${GREEN}Active${NC}"
    else
        echo -e "  ${WHITE}Status:${NC}      ${RED}Inactive${NC} (run 'systemctl start ssh_websocket' to start)"
    fi
    
    echo -e "\n${YELLOW}🔹 Connection Details:${NC}"
    echo -e "  ${WHITE}WebSocket URL:${NC} ${CYAN}ws://$server_ip:$ws_port${NC}"
    echo -e "  ${WHITE}SSH Server:${NC}   ${CYAN}127.0.0.1${NC}"
    echo -e "  ${WHITE}SSH Port:${NC}     ${CYAN}$ssh_port${NC}"
    
    echo -e "\n${YELLOW}🔹 Port Adjustment:${NC}"
    echo -e "  ${WHITE}1)${NC} Change WebSocket port (current: $ws_port)"
    echo -e "  ${WHITE}2)${NC} Change SSH port (current: $ssh_port)"
    echo -e "  ${WHITE}3)${NC} Continue without changes"
    echo -ne "${CYAN}Enter your choice [1-3]: ${NC}"
    read -r choice
    
    case $choice in
        1)  echo -ne "Enter new WebSocket port (leave empty for random): "
            read -r new_port
            
            if [[ -z "$new_port" ]]; then
                new_port=$(find_available_port)
            elif ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1024 ] || [ "$new_port" -gt 65535 ]; then
                echo_error "Invalid port number. Using random port instead."
                new_port=$(find_available_port)
            elif ! is_port_available "$new_port"; then
                echo_error "Port $new_port is already in use. Using random port instead."
                new_port=$(find_available_port)
            fi
            
            echo_info "Updating WebSocket port to $new_port..."
            sed -i "s/WS_PORT=[0-9]*/WS_PORT=$new_port/" /etc/systemd/system/ssh_websocket.service
            systemctl daemon-reload
            restart_service ssh_websocket
            echo_success "WebSocket port updated to $new_port"
            ws_port=$new_port
            ;;
        2)  echo -ne "Enter new SSH port (default: 22): "
            read -r new_port
            
            if [[ -z "$new_port" ]]; then
                new_port=22
            elif ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1 ] || [ "$new_port" -gt 65535 ]; then
                echo_error "Invalid port number. Using default port 22 instead."
                new_port=22
            fi
            
            echo_info "Updating SSH port to $new_port..."
            sed -i "s/SSH_PORT=[0-9]*/SSH_PORT=$new_port/" /etc/systemd/system/ssh_websocket.service
            systemctl daemon-reload
            restart_service ssh_websocket
            echo_success "SSH port updated to $new_port"
            ssh_port=$new_port
            ;;
        3)  echo_info "No changes made to port configuration"
            ;;
        *)  echo_error "Invalid option. No changes made."
            ;;
    esac
    
    # Update saved configuration
    local config_info="WebSocket URL: ws://$server_ip:$ws_port\nSSH Server: 127.0.0.1\nSSH Port: $ssh_port"
    echo -e "$config_info" > "$SCRIPT_DIR/ssh_ws_config.txt"
    
    echo -e "\n${YELLOW}🔹 Management Commands:${NC}"
    echo -e "  ${GRAY}• Start:${NC}   ${WHITE}systemctl start ssh_websocket${NC}"
    echo -e "  ${GRAY}• Stop:${NC}    ${WHITE}systemctl stop ssh_websocket${NC}"
    echo -e "  ${GRAY}• Restart:${NC} ${WHITE}systemctl restart ssh_websocket${NC}"
    echo -e "  ${GRAY}• Status:${NC}  ${WHITE}systemctl status ssh_websocket${NC}"
    
    # Port checker
    if [[ "$status" == "active" ]]; then
        echo -e "\n${YELLOW}🔹 Connectivity Check:${NC}"
        if lsof -i:"$ws_port" -sTCP:LISTEN >/dev/null 2>&1; then
            echo -e "  ${WHITE}WebSocket port status:${NC} ${GREEN}LISTENING${NC} on port $ws_port"
        else
            echo -e "  ${WHITE}WebSocket port status:${NC} ${RED}NOT LISTENING${NC} (Service is active but port $ws_port is not open)"
        fi
    fi
    
    echo -e "\n${YELLOW}🔹 Connection Example:${NC}"
    echo -e "  ${GRAY}Using SSH client with WebSocket proxy support:${NC}"
    echo -e "  ${WHITE}WebSocket URL:${NC} ${CYAN}ws://$server_ip:$ws_port/${NC}"
}

# Uninstall SSH WebSocket
uninstall_ssh_websocket() {
    echo_info "Uninstalling SSH WebSocket Tunneling..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH WebSocket uninstallation..."
        
        # Confirm uninstallation (simulate user interaction)
        echo_warning "This will completely remove SSH WebSocket from your system"
        echo_info "Do you want to continue? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
        
        sleep 2
        echo_success "SSH WebSocket has been uninstalled successfully (simulated)"
        return
    fi
    
    # Check if SSH WebSocket is installed
    if ! is_service_installed ssh_websocket; then
        echo_error "SSH WebSocket is not installed"
        return
    fi
    
    # Confirm uninstallation
    echo_warning "This will completely remove SSH WebSocket from your system"
    echo_info "Do you want to continue? (y/n)"
    read -r choice
    if [[ ! $choice =~ ^[Yy]$ ]]; then
        return
    fi
    
    # Stop and disable SSH WebSocket service
    stop_service ssh_websocket
    systemctl disable ssh_websocket
    
    # Remove service file
    rm -f /etc/systemd/system/ssh_websocket.service
    
    # Remove SSH WebSocket script
    rm -f /usr/local/bin/ssh_websocket.py
    
    # Remove configuration file
    rm -f "$SCRIPT_DIR/ssh_ws_config.txt"
    
    # Reload systemd daemon
    systemctl daemon-reload
    
    echo_success "SSH WebSocket has been uninstalled successfully"
}
