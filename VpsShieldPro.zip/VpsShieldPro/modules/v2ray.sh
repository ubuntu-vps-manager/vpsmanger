#!/bin/bash

# Install V2Ray with WebSocket + TLS
install_v2ray_tls() {
    echo_info "Installing V2Ray with WebSocket + TLS..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating V2Ray installation with WebSocket + TLS..."
        local uuid=$(generate_uuid)
        local websocket_path="/$(head /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)"
        local port=443
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║            ${GREEN}V2Ray WebSocket + TLS Setup${BLUE}                   ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 What is V2Ray WebSocket + TLS?${NC}"
        echo -e "${GRAY}V2Ray with WebSocket + TLS provides a secure and encrypted connection"
        echo -e "that appears as normal HTTPS traffic, helping bypass network restrictions"
        echo -e "while maintaining privacy and security through TLS encryption.${NC}"
        
        echo -e "\n${YELLOW}🔹 Generated Configuration:${NC}"
        echo -e "  ${WHITE}Port:${NC}          ${CYAN}$port${NC} (HTTPS standard port)"
        echo -e "  ${WHITE}UUID:${NC}          ${CYAN}$uuid${NC}"
        echo -e "  ${WHITE}WebSocket Path:${NC} ${CYAN}$websocket_path${NC}"
        
        echo -e "\n${YELLOW}🔹 Requirements:${NC}"
        echo -e "  ${WHITE}•${NC} A domain name pointing to your server"
        echo -e "  ${WHITE}•${NC} SSL certificate for your domain"
        echo -e "  ${WHITE}•${NC} Open port 443 in your firewall"
        
        echo -e "\n${YELLOW}🔹 Next Steps:${NC}"
        echo -e "  ${GRAY}• Your configuration will be saved for client setup"
        echo -e "  • V2Ray client software is required on your devices"
        echo -e "  • For mobile, you can use V2RayNG (Android) or Shadowrocket (iOS)${NC}"
        
        sleep 2
        echo_success "V2Ray with WebSocket + TLS simulated installation complete"
        return
    fi
    
    # Check if V2Ray is already installed
    if is_service_installed v2ray; then
        echo_warning "V2Ray is already installed"
        echo_info "Do you want to reinstall it? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
        
        # Stop and disable V2Ray service
        stop_service v2ray
        systemctl disable v2ray
    fi
    
    # Check if domain is configured
    if [ -z "$DOMAIN" ]; then
        echo_error "No domain configured. Please configure a domain first."
        echo_info "Going to domain configuration..."
        sleep 2
        manage_domain
        
        # Check again if domain is configured
        if [ -z "$DOMAIN" ]; then
            echo_error "Domain configuration failed. V2Ray installation aborted."
            return
        fi
    fi
    
    # Check if domain is pointing to this server
    if ! check_domain_dns "$DOMAIN"; then
        echo_error "Domain $DOMAIN is not pointing to this server"
        echo_info "Please update your DNS records to point to $(get_public_ip)"
        echo_info "Would you like to continue anyway? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
    fi
    
    # Check if SSL certificate exists
    if [ ! -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ] || [ ! -f "/etc/letsencrypt/live/$DOMAIN/privkey.pem" ]; then
        echo_info "SSL certificate not found. Attempting to obtain certificate..."
        obtain_ssl_cert "$DOMAIN"
        
        # Check again if certificate exists
        if [ ! -f "/etc/letsencrypt/live/$DOMAIN/fullchain.pem" ] || [ ! -f "/etc/letsencrypt/live/$DOMAIN/privkey.pem" ]; then
            echo_error "Failed to obtain SSL certificate. V2Ray installation aborted."
            return
        fi
    fi
    
    # Install and configure NGINX
    echo_info "Installing and configuring NGINX..."
    apt update -y
    apt install -y nginx
    
    # Create NGINX configuration for V2Ray
    local v2ray_ws_path="/$(head /dev/urandom | tr -dc 'a-z0-9' | fold -w 8 | head -n 1)"
    local config_file="/etc/nginx/sites-available/$DOMAIN.conf"
    
    # Backup existing config if it exists
    backup_file "$config_file"
    
    cat > "$config_file" << EOF
server {
    listen 80;
    server_name $DOMAIN;
    return 301 https://\$host\$request_uri;
}

server {
    listen 443 ssl http2;
    server_name $DOMAIN;
    
    ssl_certificate /etc/letsencrypt/live/$DOMAIN/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/$DOMAIN/privkey.pem;
    
    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_ciphers ECDHE-ECDSA-AES128-GCM-SHA256:ECDHE-RSA-AES128-GCM-SHA256:ECDHE-ECDSA-AES256-GCM-SHA384:ECDHE-RSA-AES256-GCM-SHA384:ECDHE-ECDSA-CHACHA20-POLY1305:ECDHE-RSA-CHACHA20-POLY1305:DHE-RSA-AES128-GCM-SHA256:DHE-RSA-AES256-GCM-SHA384;
    ssl_prefer_server_ciphers off;
    
    # HSTS (optional)
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    
    location $v2ray_ws_path {
        proxy_redirect off;
        proxy_pass http://127.0.0.1:10000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host \$http_host;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }
    
    # Serve a fake website to hide the real purpose of the server
    location / {
        root /var/www/html;
        index index.html;
    }
}
EOF

    # Enable the site
    ln -sf "$config_file" /etc/nginx/sites-enabled/
    
    # Create a fake website
    if [ ! -d "/var/www/html" ]; then
        mkdir -p /var/www/html
    fi
    
    cat > /var/www/html/index.html << 'EOF'
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            color: #333;
            max-width: 800px;
            margin: 0 auto;
        }
        h1 {
            color: #2c3e50;
        }
        p {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <h1>Welcome to my website</h1>
    <p>This website is currently under construction. Please check back later for updates.</p>
</body>
</html>
EOF

    # Test NGINX configuration
    if ! nginx -t; then
        echo_error "NGINX configuration test failed. Please check the error message above."
        return
    fi
    
    # Restart NGINX
    systemctl restart nginx
    systemctl enable nginx
    
    # Install V2Ray
    echo_info "Installing V2Ray..."
    if ! command_exists v2ray; then
        bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh)
        if [ $? -ne 0 ]; then
            echo_error "Failed to install V2Ray"
            return
        fi
    else
        echo_info "V2Ray is already installed, continuing with configuration..."
    fi
    
    # Generate UUID for V2Ray
    local uuid=$(generate_uuid)
    
    # Create V2Ray configuration
    echo_info "Configuring V2Ray..."
    cat > /usr/local/etc/v2ray/config.json << EOF
{
  "inbounds": [{
    "port": 10000,
    "listen": "127.0.0.1",
    "protocol": "vmess",
    "settings": {
      "clients": [
        {
          "id": "$uuid",
          "alterId": 0
        }
      ]
    },
    "streamSettings": {
      "network": "ws",
      "wsSettings": {
        "path": "$v2ray_ws_path"
      }
    }
  }],
  "outbounds": [{
    "protocol": "freedom",
    "settings": {}
  }]
}
EOF

    # Start and enable V2Ray service
    systemctl restart v2ray
    systemctl enable v2ray
    
    # Verify that V2Ray is running
    if ! is_service_active v2ray; then
        echo_error "V2Ray failed to start. Please check the logs with 'journalctl -u v2ray'"
        return
    fi
    
    # Configure firewall
    configure_firewall
    
    # Generate client configuration
    echo_success "V2Ray with WebSocket + TLS has been installed successfully!"
    echo_info "You can use the following configuration for your V2Ray client:"
    echo -e "${GREEN}------------------------------------------------${NC}"
    echo -e "${CYAN}Protocol:${NC} VMess"
    echo -e "${CYAN}Server:${NC} $DOMAIN"
    echo -e "${CYAN}Port:${NC} 443"
    echo -e "${CYAN}UUID:${NC} $uuid"
    echo -e "${CYAN}AlterID:${NC} 0"
    echo -e "${CYAN}Network:${NC} ws"
    echo -e "${CYAN}Path:${NC} $v2ray_ws_path"
    echo -e "${CYAN}TLS:${NC} tls"
    echo -e "${GREEN}------------------------------------------------${NC}"
    
    # Save configuration to file
    local config_info="Protocol: VMess\nServer: $DOMAIN\nPort: 443\nUUID: $uuid\nAlterID: 0\nNetwork: ws\nPath: $v2ray_ws_path\nTLS: tls"
    echo -e "$config_info" > "$SCRIPT_DIR/v2ray_tls_config.txt"
    echo_info "Configuration saved to $SCRIPT_DIR/v2ray_tls_config.txt"
}

# Install V2Ray with WebSocket (non-TLS)
install_v2ray_nontls() {
    echo_info "Installing V2Ray with WebSocket (non-TLS)..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating V2Ray installation with WebSocket (non-TLS)..."
        local uuid=$(generate_uuid)
        local websocket_path="/$(head /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)"
        local port=80
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}V2Ray WebSocket (non-TLS) Setup${BLUE}                 ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 What is V2Ray WebSocket (non-TLS)?${NC}"
        echo -e "${GRAY}V2Ray with WebSocket (non-TLS) provides a direct connection without"
        echo -e "TLS encryption. While faster and simpler to set up, it doesn't have the"
        echo -e "same level of security and may be more easily identified as non-HTTP traffic.${NC}"
        
        echo -e "\n${YELLOW}🔹 Generated Configuration:${NC}"
        echo -e "  ${WHITE}Port:${NC}          ${CYAN}$port${NC}"
        echo -e "  ${WHITE}UUID:${NC}          ${CYAN}$uuid${NC}"
        echo -e "  ${WHITE}WebSocket Path:${NC} ${CYAN}$websocket_path${NC}"
        
        echo -e "\n${YELLOW}🔹 Security Note:${NC}"
        echo -e "  ${WHITE}•${NC} This mode does not use TLS encryption"
        echo -e "  ${WHITE}•${NC} Communication is not encrypted at the transport layer"
        echo -e "  ${WHITE}•${NC} For better security, consider using the TLS version instead"
        
        echo -e "\n${YELLOW}🔹 Requirements:${NC}"
        echo -e "  ${WHITE}•${NC} Open port $port in your firewall"
        echo -e "  ${WHITE}•${NC} Direct access to server IP address"
        
        echo -e "\n${YELLOW}🔹 Next Steps:${NC}"
        echo -e "  ${GRAY}• Your configuration will be saved for client setup"
        echo -e "  • V2Ray client software is required on your devices"
        echo -e "  • For mobile, you can use V2RayNG (Android) or Shadowrocket (iOS)${NC}"
        
        sleep 2
        echo_success "V2Ray with WebSocket (non-TLS) simulated installation complete"
        return
    fi
    
    # Check if V2Ray is already installed
    if is_service_installed v2ray; then
        echo_warning "V2Ray is already installed"
        echo_info "Do you want to reinstall it? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
        
        # Stop and disable V2Ray service
        stop_service v2ray
        systemctl disable v2ray
    fi
    
    # Set default port for V2Ray non-TLS to 80
    local port=80
    
    # Check if port 80 is available, if not, find an available port
    if ! is_port_available "$port"; then
        echo_warning "Default port 80 is not available. Finding an alternative port..."
        port=$(find_available_port)
    fi
    
    # Install V2Ray
    echo_info "Installing V2Ray..."
    if ! command_exists v2ray; then
        bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh)
        if [ $? -ne 0 ]; then
            echo_error "Failed to install V2Ray"
            return
        fi
    else
        echo_info "V2Ray is already installed, continuing with configuration..."
    fi
    
    # Generate UUID for V2Ray
    local uuid=$(generate_uuid)
    
    # Generate random WebSocket path
    local ws_path="/$(head /dev/urandom | tr -dc 'a-z0-9' | fold -w 8 | head -n 1)"
    
    # Create V2Ray configuration
    echo_info "Configuring V2Ray..."
    cat > /usr/local/etc/v2ray/config.json << EOF
{
  "inbounds": [{
    "port": $port,
    "listen": "0.0.0.0",
    "protocol": "vmess",
    "settings": {
      "clients": [
        {
          "id": "$uuid",
          "alterId": 0
        }
      ]
    },
    "streamSettings": {
      "network": "ws",
      "wsSettings": {
        "path": "$ws_path"
      }
    }
  }],
  "outbounds": [{
    "protocol": "freedom",
    "settings": {}
  }]
}
EOF

    # Start and enable V2Ray service
    systemctl restart v2ray
    systemctl enable v2ray
    
    # Verify that V2Ray is running
    if ! is_service_active v2ray; then
        echo_error "V2Ray failed to start. Please check the logs with 'journalctl -u v2ray'"
        return
    fi
    
    # Configure firewall
    configure_firewall
    
    # Get server IP
    local server_ip=$(get_public_ip)
    
    # Generate client configuration
    echo_success "V2Ray with WebSocket (non-TLS) has been installed successfully!"
    echo_info "You can use the following configuration for your V2Ray client:"
    echo -e "${GREEN}------------------------------------------------${NC}"
    echo -e "${CYAN}Protocol:${NC} VMess"
    echo -e "${CYAN}Server:${NC} $server_ip"
    echo -e "${CYAN}Port:${NC} $port"
    echo -e "${CYAN}UUID:${NC} $uuid"
    echo -e "${CYAN}AlterID:${NC} 0"
    echo -e "${CYAN}Network:${NC} ws"
    echo -e "${CYAN}Path:${NC} $ws_path"
    echo -e "${CYAN}TLS:${NC} none"
    echo -e "${GREEN}------------------------------------------------${NC}"
    
    # Save configuration to file
    local config_info="Protocol: VMess\nServer: $server_ip\nPort: $port\nUUID: $uuid\nAlterID: 0\nNetwork: ws\nPath: $ws_path\nTLS: none"
    echo -e "$config_info" > "$SCRIPT_DIR/v2ray_nontls_config.txt"
    echo_info "Configuration saved to $SCRIPT_DIR/v2ray_nontls_config.txt"
}

# Show V2Ray configuration
show_v2ray_config() {
    echo_info "V2Ray Configuration"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Displaying sample V2Ray configurations..."
        
        # Generate example UUID and paths
        local uuid=$(generate_uuid)
        local path_tls="/$(head /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)"
        local path_nontls="/$(head /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 8 | head -n 1)"
        local port_nontls=80
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}V2Ray Configurations${BLUE}                         ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Service Status:${NC}"
        echo -e "  ${WHITE}Status:${NC}      ${YELLOW}[SIMULATED] Not installed${NC}"
        
        echo -e "\n${YELLOW}🔹 V2Ray WebSocket + TLS Configuration:${NC}"
        echo -e "  ${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
        echo -e "  ${WHITE}Server:${NC}      ${CYAN}example.com${NC}"
        echo -e "  ${WHITE}Port:${NC}        ${CYAN}443${NC} (HTTPS standard port)"
        echo -e "  ${WHITE}UUID:${NC}        ${CYAN}$uuid${NC}"
        echo -e "  ${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
        echo -e "  ${WHITE}Network:${NC}     ${CYAN}ws${NC} (WebSocket)"
        echo -e "  ${WHITE}Path:${NC}        ${CYAN}$path_tls${NC}"
        echo -e "  ${WHITE}TLS:${NC}         ${CYAN}tls${NC}"
        echo -e "  ${WHITE}Security:${NC}    ${GREEN}High${NC} (Transport encrypted with TLS)"
        
        echo -e "\n${YELLOW}🔹 V2Ray WebSocket (non-TLS) Configuration:${NC}"
        echo -e "  ${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
        echo -e "  ${WHITE}Server:${NC}      ${CYAN}198.51.100.1${NC} (Server IP)"
        echo -e "  ${WHITE}Port:${NC}        ${CYAN}$port_nontls${NC}"
        echo -e "  ${WHITE}UUID:${NC}        ${CYAN}$uuid${NC}"
        echo -e "  ${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
        echo -e "  ${WHITE}Network:${NC}     ${CYAN}ws${NC} (WebSocket)"
        echo -e "  ${WHITE}Path:${NC}        ${CYAN}$path_nontls${NC}"
        echo -e "  ${WHITE}TLS:${NC}         ${CYAN}none${NC}"
        echo -e "  ${WHITE}Security:${NC}    ${YELLOW}Medium${NC} (Transport not encrypted)"
        
        echo -e "\n${YELLOW}🔹 User Management (Simulated):${NC}"
        echo -e "  ${GRAY}Active Users:${NC}"
        echo -e "  ${WHITE}1. admin:${NC} ${CYAN}$uuid${NC}"
        echo -e "  ${WHITE}2. user1:${NC} ${CYAN}$(generate_uuid)${NC}"
        
        echo -e "\n${YELLOW}🔹 Service Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Port adjustment"
        echo -e "  ${WHITE}2)${NC} User management"
        echo -e "  ${WHITE}3)${NC} Continue without changes"
        
        echo -e "\n${YELLOW}🔹 Client Software:${NC}"
        echo -e "  ${WHITE}•${NC} Desktop: V2Ray, Qv2ray, V2RayN (Windows), V2RayX (macOS)"
        echo -e "  ${WHITE}•${NC} Mobile: V2RayNG (Android), Shadowrocket (iOS)"
        
        echo -e "\n${YELLOW}🔹 Import Format:${NC}"
        echo -e "  ${GRAY}Most V2Ray clients support importing configurations via:${NC}"
        echo -e "  ${WHITE}•${NC} Manual entry of the above details"
        echo -e "  ${WHITE}•${NC} VMess URL (vmess://...)"
        echo -e "  ${WHITE}•${NC} QR code scanning"
        
        return
    fi
    
    # Check if V2Ray is installed
    if ! is_service_installed v2ray; then
        echo_error "V2Ray is not installed"
        echo_info "You can install it using options 3 or 4 from the main menu"
        return
    fi
    
    # Get service status
    local status=$(systemctl is-active v2ray)
    
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║              ${GREEN}V2Ray Configurations${BLUE}                         ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    echo -e "\n${YELLOW}🔹 Service Status:${NC}"
    if [[ "$status" == "active" ]]; then
        echo -e "  ${WHITE}Status:${NC}      ${GREEN}Active${NC}"
    else
        echo -e "  ${WHITE}Status:${NC}      ${RED}Inactive${NC} (run 'systemctl start v2ray' to start)"
    fi
    
    # Process and display TLS config if it exists
    if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
        echo -e "\n${YELLOW}🔹 V2Ray WebSocket + TLS Configuration:${NC}"
        
        local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        local uuid=$(grep "UUID:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        local alterid=$(grep "AlterID:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        local network=$(grep "Network:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        local tls=$(grep "TLS:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        
        echo -e "  ${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
        echo -e "  ${WHITE}Server:${NC}      ${CYAN}$server${NC}"
        echo -e "  ${WHITE}Port:${NC}        ${CYAN}$port${NC} (HTTPS standard port)"
        echo -e "  ${WHITE}UUID:${NC}        ${CYAN}$uuid${NC}"
        echo -e "  ${WHITE}AlterID:${NC}     ${CYAN}$alterid${NC}"
        echo -e "  ${WHITE}Network:${NC}     ${CYAN}$network${NC} (WebSocket)"
        echo -e "  ${WHITE}Path:${NC}        ${CYAN}$path${NC}"
        echo -e "  ${WHITE}TLS:${NC}         ${CYAN}$tls${NC}"
        echo -e "  ${WHITE}Security:${NC}    ${GREEN}High${NC} (Transport encrypted with TLS)"
    fi
    
    # Process and display non-TLS config if it exists
    if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
        echo -e "\n${YELLOW}🔹 V2Ray WebSocket (non-TLS) Configuration:${NC}"
        
        local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        local uuid=$(grep "UUID:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        local alterid=$(grep "AlterID:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        local network=$(grep "Network:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        local tls=$(grep "TLS:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        
        echo -e "  ${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
        echo -e "  ${WHITE}Server:${NC}      ${CYAN}$server${NC} (Server IP)"
        echo -e "  ${WHITE}Port:${NC}        ${CYAN}$port${NC}"
        echo -e "  ${WHITE}UUID:${NC}        ${CYAN}$uuid${NC}"
        echo -e "  ${WHITE}AlterID:${NC}     ${CYAN}$alterid${NC}"
        echo -e "  ${WHITE}Network:${NC}     ${CYAN}$network${NC} (WebSocket)"
        echo -e "  ${WHITE}Path:${NC}        ${CYAN}$path${NC}"
        echo -e "  ${WHITE}TLS:${NC}         ${CYAN}$tls${NC}"
        echo -e "  ${WHITE}Security:${NC}    ${YELLOW}Medium${NC} (Transport not encrypted)"
    fi
    
    # Show client software information
    echo -e "\n${YELLOW}🔹 Client Software:${NC}"
    echo -e "  ${WHITE}•${NC} Desktop: V2Ray, Qv2ray, V2RayN (Windows), V2RayX (macOS)"
    echo -e "  ${WHITE}•${NC} Mobile: V2RayNG (Android), Shadowrocket (iOS)"
    
    # Show port checker
    if [[ "$status" == "active" ]]; then
        echo -e "\n${YELLOW}🔹 Connectivity Check:${NC}"
        
        # Get port from config file
        local config_port=$(grep -o '"port": [0-9]*' /usr/local/etc/v2ray/config.json | grep -o '[0-9]*')
        
        if [[ -n "$config_port" ]]; then
            if lsof -i:"$config_port" -sTCP:LISTEN >/dev/null 2>&1; then
                echo -e "  ${WHITE}Port status:${NC} ${GREEN}LISTENING${NC} on port $config_port"
            else
                echo -e "  ${WHITE}Port status:${NC} ${RED}NOT LISTENING${NC} (Service is active but port $config_port is not open)"
            fi
        fi
    fi
    
    echo -e "\n${YELLOW}🔹 Service Management:${NC}"
    echo -e "  ${WHITE}1)${NC} Port adjustment"
    echo -e "  ${WHITE}2)${NC} User management"
    echo -e "  ${WHITE}3)${NC} Continue without changes"
    echo -ne "${CYAN}Enter your choice [1-3]: ${NC}"
    read -r choice
    
    case $choice in
        1)  
            echo -e "\n${YELLOW}🔹 Port Adjustment:${NC}"
            # Determine which configuration is available
            if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ] && [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                echo -e "  ${WHITE}1)${NC} Change WebSocket + TLS port (current: 443)"
                echo -e "  ${WHITE}2)${NC} Change WebSocket (non-TLS) port"
                echo -e "  ${WHITE}3)${NC} Return to previous menu"
                echo -ne "${CYAN}Enter your choice [1-3]: ${NC}"
                read -r port_choice
                
                case $port_choice in
                    1)  echo_info "WebSocket + TLS uses port 443 (HTTPS standard port) managed by NGINX."
                        echo_info "To change this, you need to reconfigure your domain and SSL certificates."
                        echo_info "Do you want to run option 1 (Configure domain) from the main menu? (y/n)"
                        read -r domain_choice
                        if [[ $domain_choice =~ ^[Yy]$ ]]; then
                            echo_info "Please select option 1 from the main menu after this operation completes."
                        fi
                        ;;
                    2)  
                        echo -ne "Enter new WebSocket (non-TLS) port (leave empty for random): "
                        read -r new_port
                        
                        if [[ -z "$new_port" ]]; then
                            new_port=$(find_available_port)
                        elif ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1024 ] || [ "$new_port" -gt 65535 ]; then
                            echo_error "Invalid port number. Using random port instead."
                            new_port=$(find_available_port)
                        elif ! is_port_available "$new_port"; then
                            echo_error "Port $new_port is already in use. Using random port instead."
                            new_port=$(find_available_port)
                        fi
                        
                        echo_info "Updating WebSocket (non-TLS) port to $new_port..."
                        # Get current port
                        local current_port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                        # Update configuration file
                        sed -i "s/\"port\": $current_port/\"port\": $new_port/" /usr/local/etc/v2ray/config.json
                        # Update saved config
                        sed -i "s/Port: $current_port/Port: $new_port/" "$SCRIPT_DIR/v2ray_nontls_config.txt"
                        
                        # Restart service
                        systemctl daemon-reload
                        restart_service v2ray
                        echo_success "WebSocket (non-TLS) port updated to $new_port"
                        ;;
                    3)  ;;
                    *)  echo_error "Invalid option. No changes made."
                        ;;
                esac
            elif [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                echo_info "WebSocket + TLS uses port 443 (HTTPS standard port) managed by NGINX."
                echo_info "To change this, you need to reconfigure your domain and SSL certificates."
                echo_info "Do you want to run option 1 (Configure domain) from the main menu? (y/n)"
                read -r domain_choice
                if [[ $domain_choice =~ ^[Yy]$ ]]; then
                    echo_info "Please select option 1 from the main menu after this operation completes."
                fi
            elif [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                echo -ne "Enter new WebSocket (non-TLS) port (leave empty for random): "
                read -r new_port
                
                if [[ -z "$new_port" ]]; then
                    new_port=$(find_available_port)
                elif ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1024 ] || [ "$new_port" -gt 65535 ]; then
                    echo_error "Invalid port number. Using random port instead."
                    new_port=$(find_available_port)
                elif ! is_port_available "$new_port"; then
                    echo_error "Port $new_port is already in use. Using random port instead."
                    new_port=$(find_available_port)
                fi
                
                echo_info "Updating WebSocket (non-TLS) port to $new_port..."
                # Get current port
                local current_port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                # Update configuration file
                sed -i "s/\"port\": $current_port/\"port\": $new_port/" /usr/local/etc/v2ray/config.json
                # Update saved config
                sed -i "s/Port: $current_port/Port: $new_port/" "$SCRIPT_DIR/v2ray_nontls_config.txt"
                
                # Restart service
                systemctl daemon-reload
                restart_service v2ray
                echo_success "WebSocket (non-TLS) port updated to $new_port"
            fi
            ;;
        2)  
            echo -e "\n${YELLOW}🔹 User Management:${NC}"
            echo -e "  ${WHITE}1)${NC} Add a new user"
            echo -e "  ${WHITE}2)${NC} List all users"
            echo -e "  ${WHITE}3)${NC} Remove a user"
            echo -e "  ${WHITE}4)${NC} Return to previous menu"
            echo -ne "${CYAN}Enter your choice [1-4]: ${NC}"
            read -r user_choice
            
            case $user_choice in
                1)  # Add new user
                    # Generate UUID for new user
                    local new_uuid=$(generate_uuid)
                    echo_info "Generated new user UUID: $new_uuid"
                    
                    # Get user alias
                    echo -ne "Enter a name/alias for this user (for your reference only): "
                    read -r user_alias
                    if [[ -z "$user_alias" ]]; then
                        user_alias="user_$(date +%s)"
                    fi
                    
                    # Modify V2Ray config to add the new user
                    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
                        # Add new client to the array
                        jq --arg uuid "$new_uuid" --arg alias "$user_alias" '.inbounds[0].settings.clients += [{"id": $uuid, "alterId": 0, "email": $alias}]' /usr/local/etc/v2ray/config.json > /tmp/v2ray_config.json
                        mv /tmp/v2ray_config.json /usr/local/etc/v2ray/config.json
                        
                        # Restart V2Ray to apply changes
                        restart_service v2ray
                        echo_success "New user '$user_alias' added successfully with UUID: $new_uuid"
                        
                        # Display configuration for the new user
                        echo -e "\n${YELLOW}🔹 Configuration for new user '$user_alias':${NC}"
                        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                            local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            local network=$(grep "Network:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            local tls=$(grep "TLS:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            
                            echo -e "  ${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
                            echo -e "  ${WHITE}Server:${NC}      ${CYAN}$server${NC}"
                            echo -e "  ${WHITE}Port:${NC}        ${CYAN}$port${NC} (HTTPS standard port)"
                            echo -e "  ${WHITE}UUID:${NC}        ${CYAN}$new_uuid${NC}"
                            echo -e "  ${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
                            echo -e "  ${WHITE}Network:${NC}     ${CYAN}$network${NC} (WebSocket)"
                            echo -e "  ${WHITE}Path:${NC}        ${CYAN}$path${NC}"
                            echo -e "  ${WHITE}TLS:${NC}         ${CYAN}$tls${NC}"
                        fi
                        
                        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                            local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            local network=$(grep "Network:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            local tls=$(grep "TLS:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            
                            echo -e "  ${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
                            echo -e "  ${WHITE}Server:${NC}      ${CYAN}$server${NC} (Server IP)"
                            echo -e "  ${WHITE}Port:${NC}        ${CYAN}$port${NC}"
                            echo -e "  ${WHITE}UUID:${NC}        ${CYAN}$new_uuid${NC}"
                            echo -e "  ${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
                            echo -e "  ${WHITE}Network:${NC}     ${CYAN}$network${NC} (WebSocket)"
                            echo -e "  ${WHITE}Path:${NC}        ${CYAN}$path${NC}"
                            echo -e "  ${WHITE}TLS:${NC}         ${CYAN}$tls${NC}"
                        fi
                    else
                        echo_error "Could not find clients section in V2Ray config. User not added."
                    fi
                    ;;
                2)  # List all users
                    echo -e "\n${YELLOW}🔹 Current V2Ray Users:${NC}"
                    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
                        # Extract and display all users
                        local clients=$(jq -r '.inbounds[0].settings.clients | to_entries | .[] | "\(.key+1). \(.value.email // "unnamed"): \(.value.id)"' /usr/local/etc/v2ray/config.json)
                        if [[ -z "$clients" ]]; then
                            echo -e "  ${GRAY}No clients found.${NC}"
                        else
                            echo -e "$clients" | while read -r line; do
                                echo -e "  ${WHITE}$line${NC}"
                            done
                        fi
                    else
                        echo_error "Could not find clients section in V2Ray config."
                    fi
                    ;;
                3)  # Remove a user
                    echo -e "\n${YELLOW}🔹 Current V2Ray Users:${NC}"
                    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
                        # Extract and display all users
                        local clients=$(jq -r '.inbounds[0].settings.clients | to_entries | .[] | "\(.key+1). \(.value.email // "unnamed"): \(.value.id)"' /usr/local/etc/v2ray/config.json)
                        if [[ -z "$clients" ]]; then
                            echo -e "  ${GRAY}No clients found.${NC}"
                            return
                        else
                            echo -e "$clients" | while read -r line; do
                                echo -e "  ${WHITE}$line${NC}"
                            done
                        fi
                        
                        # Count clients
                        local client_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
                        
                        # Ask which user to remove
                        echo -ne "\nEnter the number of the user to remove [1-$client_count]: "
                        read -r user_num
                        
                        if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le "$client_count" ]; then
                            # Adjust to zero-based index
                            local idx=$((user_num-1))
                            
                            # Get user info for confirmation
                            local user_email=$(jq -r ".inbounds[0].settings.clients[$idx].email // \"unnamed\"" /usr/local/etc/v2ray/config.json)
                            local user_id=$(jq -r ".inbounds[0].settings.clients[$idx].id" /usr/local/etc/v2ray/config.json)
                            
                            echo_warning "Are you sure you want to remove user '$user_email' with UUID $user_id? (y/n)"
                            read -r confirm
                            
                            if [[ $confirm =~ ^[Yy]$ ]]; then
                                # Remove the selected user
                                jq --argjson idx "$idx" 'del(.inbounds[0].settings.clients[$idx])' /usr/local/etc/v2ray/config.json > /tmp/v2ray_config.json
                                mv /tmp/v2ray_config.json /usr/local/etc/v2ray/config.json
                                
                                # Restart V2Ray to apply changes
                                restart_service v2ray
                                echo_success "User '$user_email' removed successfully"
                            else
                                echo_info "User removal cancelled"
                            fi
                        else
                            echo_error "Invalid user number"
                        fi
                    else
                        echo_error "Could not find clients section in V2Ray config."
                    fi
                    ;;
                4)  ;;
                *)  echo_error "Invalid option. No changes made."
                    ;;
            esac
            ;;
        3)  ;;
        *)  echo_error "Invalid option. No changes made."
            ;;
    esac
    
    echo -e "\n${YELLOW}🔹 Management Commands:${NC}"
    echo -e "  ${GRAY}• Start:${NC}   ${WHITE}systemctl start v2ray${NC}"
    echo -e "  ${GRAY}• Stop:${NC}    ${WHITE}systemctl stop v2ray${NC}"
    echo -e "  ${GRAY}• Restart:${NC} ${WHITE}systemctl restart v2ray${NC}"
    echo -e "  ${GRAY}• Status:${NC}  ${WHITE}systemctl status v2ray${NC}"
    
    echo -e "\n${YELLOW}🔹 Logs:${NC}"
    echo -e "  ${GRAY}View logs with:${NC} ${WHITE}journalctl -u v2ray -f${NC}"
}

# Uninstall V2Ray
uninstall_v2ray() {
    echo_info "Uninstalling V2Ray..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating V2Ray uninstallation..."
        
        echo -e "${YELLOW}╔══════════════════════════════════════════════╗${NC}"
        echo -e "${YELLOW}║              UNINSTALL WARNING               ║${NC}"
        echo -e "${YELLOW}╚══════════════════════════════════════════════╝${NC}"
        echo -e "\n${RED}This will completely remove V2Ray from your system:${NC}"
        echo -e "  ${WHITE}•${NC} Stop and disable the V2Ray service"
        echo -e "  ${WHITE}•${NC} Remove all V2Ray binaries and configuration files"
        echo -e "  ${WHITE}•${NC} Remove NGINX configurations (if TLS was configured)"
        echo -e "  ${WHITE}•${NC} Close corresponding ports and remove firewall rules"
        
        echo -e "\n${CYAN}Do you want to continue?${NC}"
        echo -e "  ${WHITE}1)${NC} Yes, uninstall V2Ray completely"
        echo -e "  ${WHITE}2)${NC} No, keep V2Ray installed"
        echo -ne "${CYAN}Enter your choice [1-2]: ${NC}"
        read -r choice
        
        case $choice in
            1)  echo_info "Simulating uninstallation..."
                sleep 2
                echo_success "V2Ray has been uninstalled successfully (simulated)"
                ;;
            2)  echo_info "Uninstallation cancelled"
                return
                ;;
            *)  echo_error "Invalid option. Uninstallation cancelled."
                return
                ;;
        esac
        return
    fi
    
    # Check if V2Ray is installed
    if ! is_service_installed v2ray; then
        echo_error "V2Ray is not installed"
        echo_info "There's nothing to uninstall"
        return
    fi
    
    # Collect information about installed services for confirmation
    local has_tls=false
    local has_nontls=false
    local domain=""
    local tls_port=""
    local nontls_port=""
    
    if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
        has_tls=true
        domain=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        tls_port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
    fi
    
    if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
        has_nontls=true
        nontls_port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
    fi
    
    # Show warning and confirmation dialogue
    echo -e "${YELLOW}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║              UNINSTALL WARNING               ║${NC}"
    echo -e "${YELLOW}╚══════════════════════════════════════════════╝${NC}"
    echo -e "\n${RED}This will completely remove V2Ray from your system:${NC}"
    echo -e "  ${WHITE}•${NC} Stop and disable the V2Ray service"
    echo -e "  ${WHITE}•${NC} Remove all V2Ray binaries and configuration files"
    
    if [ "$has_tls" = true ]; then
        echo -e "  ${WHITE}•${NC} Remove NGINX configuration for domain $domain"
    fi
    
    if [ "$has_tls" = true ] && [ "$has_nontls" = true ]; then
        echo -e "  ${WHITE}•${NC} Close ports $tls_port and $nontls_port"
    elif [ "$has_tls" = true ]; then
        echo -e "  ${WHITE}•${NC} Close port $tls_port"
    elif [ "$has_nontls" = true ]; then
        echo -e "  ${WHITE}•${NC} Close port $nontls_port"
    fi
    
    echo -e "\n${GREEN}Current Configurations:${NC}"
    if [ "$has_tls" = true ]; then
        echo -e "  ${WHITE}•${NC} V2Ray WebSocket + TLS on $domain:$tls_port"
    fi
    if [ "$has_nontls" = true ]; then
        echo -e "  ${WHITE}•${NC} V2Ray WebSocket (non-TLS) on port $nontls_port"
    fi
    
    echo -e "\n${CYAN}Do you want to continue?${NC}"
    echo -e "  ${WHITE}1)${NC} Yes, uninstall V2Ray completely"
    echo -e "  ${WHITE}2)${NC} No, keep V2Ray installed"
    echo -e "  ${WHITE}3)${NC} Just stop the service (don't uninstall)"
    echo -ne "${CYAN}Enter your choice [1-3]: ${NC}"
    read -r choice
    
    case $choice in
        1)  echo_info "Uninstalling V2Ray..."
            
            # First, backup configuration
            local backup_dir="$SCRIPT_DIR/backup/v2ray_$(date +%Y%m%d%H%M%S)"
            mkdir -p "$backup_dir"
            
            # Backup config files
            if [ -f "/usr/local/etc/v2ray/config.json" ]; then
                cp "/usr/local/etc/v2ray/config.json" "$backup_dir/"
            fi
            if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                cp "$SCRIPT_DIR/v2ray_tls_config.txt" "$backup_dir/"
            fi
            if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                cp "$SCRIPT_DIR/v2ray_nontls_config.txt" "$backup_dir/"
            fi
            
            # Backup NGINX config if it exists
            if [ ! -z "$domain" ] && [ -f "/etc/nginx/sites-available/$domain.conf" ]; then
                cp "/etc/nginx/sites-available/$domain.conf" "$backup_dir/"
            fi
            
            echo_info "Configuration backed up to $backup_dir"
            
            # Stop and disable V2Ray service
            echo_info "Stopping and disabling V2Ray service..."
            stop_service v2ray
            systemctl disable v2ray
            
            # Use the official uninstall script
            echo_info "Removing V2Ray binaries..."
            if [ -f /usr/local/bin/v2ray ]; then
                bash <(curl -L https://raw.githubusercontent.com/v2fly/fhs-install-v2ray/master/install-release.sh) --remove
                if [ $? -ne 0 ]; then
                    echo_error "Failed to uninstall V2Ray. Continuing with manual cleanup..."
                fi
            fi
            
            # Remove configuration files
            echo_info "Removing configuration files..."
            rm -f /usr/local/etc/v2ray/config.json
            rm -f "$SCRIPT_DIR/v2ray_tls_config.txt"
            rm -f "$SCRIPT_DIR/v2ray_nontls_config.txt"
            
            # Remove NGINX configuration if it exists
            if [ ! -z "$domain" ] && [ -f "/etc/nginx/sites-available/$domain.conf" ]; then
                echo_info "Removing NGINX configuration for $domain..."
                rm -f "/etc/nginx/sites-available/$domain.conf"
                rm -f "/etc/nginx/sites-enabled/$domain.conf"
                systemctl restart nginx
            fi
            
            echo_success "V2Ray has been uninstalled successfully"
            echo_info "A backup of your configuration has been saved to: $backup_dir"
            ;;
        2)  echo_info "Uninstallation cancelled"
            return
            ;;
        3)  echo_info "Stopping V2Ray service..."
            stop_service v2ray
            echo_success "V2Ray service has been stopped"
            echo_info "The service is still installed and can be started with: systemctl start v2ray"
            return
            ;;
        *)  echo_error "Invalid option. Uninstallation cancelled."
            return
            ;;
    esac
}
