#!/bin/bash

# Install Python Proxy with 101 Protocol
install_python_proxy() {
    echo_info "Installing Python Proxy with 101 Protocol..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating Python Proxy installation..."
        local port=80
        echo_info "Generated configuration:"
        echo_info "Port: $port"
        echo_info "Features: HTTP/HTTPS proxy, WebSocket 101 protocol, CONNECT tunneling"
        
        echo -e "\n${YELLOW}🔹 What is Python Proxy?${NC}"
        echo -e "${GRAY}Python Proxy provides HTTP/HTTPS proxying with special support for WebSocket connections"
        echo -e "through the 101 Protocol. It can be used to tunnel web traffic and WebSocket connections"
        echo -e "through environments where standard protocols might be restricted.${NC}"
        
        echo -e "\n${YELLOW}🔹 Usage Examples:${NC}"
        echo -e "${GRAY}• Configure browser to use this proxy: http://your_server_ip:$port"
        echo -e "• For applications: Set HTTP_PROXY=http://your_server_ip:$port"
        echo -e "• WebSocket apps will automatically use 101 protocol tunneling${NC}"
        
        sleep 2
        echo_success "Python Proxy with 101 Protocol simulated installation complete"
        return
    fi
    
    # Check if Python Proxy is already installed
    if is_service_installed python_proxy; then
        echo_warning "Python Proxy is already installed"
        echo -e "${YELLOW}Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Reinstall Python Proxy"
        echo -e "  ${WHITE}2)${NC} Change port"
        echo -e "  ${WHITE}3)${NC} Return to main menu"
        echo -ne "${CYAN}Enter your choice [1-3]: ${NC}"
        read -r choice
        
        case $choice in
            1)  echo_info "Reinstalling Python Proxy..."
                stop_service python_proxy
                systemctl disable python_proxy
                ;;
            2)  local current_port=$(grep -o 'PORT=[0-9]*' /etc/systemd/system/python_proxy.service | grep -o '[0-9]*')
                echo_info "Current port: $current_port"
                echo -ne "Enter new port (leave empty for random): "
                read -r new_port
                
                if [[ -z "$new_port" ]]; then
                    new_port=$(find_available_port)
                elif ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1024 ] || [ "$new_port" -gt 65535 ]; then
                    echo_error "Invalid port number. Using random port instead."
                    new_port=$(find_available_port)
                elif ! is_port_available "$new_port"; then
                    echo_error "Port $new_port is already in use. Using random port instead."
                    new_port=$(find_available_port)
                fi
                
                echo_info "Updating port to $new_port..."
                sed -i "s/PORT=[0-9]*/PORT=$new_port/" /etc/systemd/system/python_proxy.service
                systemctl daemon-reload
                restart_service python_proxy
                echo_success "Port updated to $new_port"
                return
                ;;
            3)  return
                ;;
            *)  echo_error "Invalid option. Returning to main menu."
                return
                ;;
        esac
    fi
    
    # Install required packages
    echo_info "Installing required packages..."
    apt update -y
    apt install -y python3 python3-pip
    
    echo_info "Configuring Python Proxy..."
    
    # Set default port for Python Proxy to 80
    local proxy_port=80
    
    # Check if port 80 is available, if not, find an available port
    if ! is_port_available "$proxy_port"; then
        echo_warning "Default port 80 is not available. Finding an alternative port..."
        proxy_port=$(find_available_port)
    fi
    
    # Create the Python Proxy script directory
    mkdir -p /usr/local/bin
    
    # Create the Python Proxy script
    echo_info "Creating Python Proxy script..."
    cat > /usr/local/bin/python_proxy.py << 'EOF'
#!/usr/bin/env python3

import socket
import threading
import argparse
import logging
import ssl
import sys
import base64
import time
import os
import signal
from http.client import HTTPResponse
from io import BytesIO

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('python-proxy')

# Global variables
connections = set()
running = True

class FakeSocket():
    """A fake socket for HTTPResponse to use"""
    def __init__(self, response_bytes):
        self._file = BytesIO(response_bytes)
    
    def makefile(self, *args, **kwargs):
        return self._file

def parse_http_request(data):
    """Parse HTTP request data to extract method, path, headers"""
    try:
        # Split headers from body
        headers_end = data.find(b'\r\n\r\n')
        if headers_end == -1:
            return None
        
        headers_data = data[:headers_end]
        request_line, headers_lines = headers_data.split(b'\r\n', 1)
        
        # Parse request line
        method, path, version = request_line.decode('utf-8').split(' ')
        
        # Parse headers
        headers = {}
        for line in headers_lines.split(b'\r\n'):
            if not line:
                continue
            key, value = line.decode('utf-8').split(': ', 1)
            headers[key.lower()] = value
        
        return {
            'method': method,
            'path': path,
            'version': version,
            'headers': headers
        }
    except Exception as e:
        logger.error(f"Error parsing HTTP request: {e}")
        return None

def handle_connection(client_socket, client_address):
    """Handle client connection"""
    logger.info(f"New connection from {client_address}")
    connections.add(client_socket)
    
    try:
        # Receive initial data from client
        data = client_socket.recv(4096)
        if not data:
            logger.warning(f"No data received from {client_address}")
            return
        
        # Parse HTTP request
        request = parse_http_request(data)
        if not request:
            logger.warning(f"Invalid HTTP request from {client_address}")
            return
        
        # Check if this is a WebSocket upgrade request
        if (request['method'] == 'GET' and
            'upgrade' in request['headers'] and
            request['headers']['upgrade'].lower() == 'websocket'):
            handle_websocket_upgrade(client_socket, request)
        # Check if this is a CONNECT request (for HTTPS tunneling)
        elif request['method'] == 'CONNECT':
            handle_https_connect(client_socket, request)
        # Regular HTTP proxy
        elif request['method'] in ['GET', 'POST', 'PUT', 'DELETE', 'HEAD']:
            handle_http_proxy(client_socket, request, data)
        else:
            logger.warning(f"Unsupported method: {request['method']}")
            client_socket.sendall(b'HTTP/1.1 405 Method Not Allowed\r\n\r\n')
    
    except Exception as e:
        logger.error(f"Error handling connection: {e}")
    finally:
        client_socket.close()
        connections.remove(client_socket)
        logger.info(f"Connection closed from {client_address}")

def handle_websocket_upgrade(client_socket, request):
    """Handle WebSocket upgrade request with 101 protocol"""
    try:
        # Extract the target from the Host header
        host_header = request['headers'].get('host', '')
        if ':' in host_header:
            target_host, target_port = host_header.split(':', 1)
            target_port = int(target_port)
        else:
            target_host = host_header
            target_port = 80
        
        # Create a socket to the target server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.connect((target_host, target_port))
        
        # Forward the upgrade request to the target server
        server_socket.sendall(build_websocket_request(request))
        
        # Receive the response from the target server
        response = server_socket.recv(4096)
        
        # Parse the response to check if it's a 101 Switching Protocols
        if b'101 Switching Protocols' in response:
            # Forward the response back to the client
            client_socket.sendall(response)
            
            # Start bidirectional data exchange
            threading.Thread(target=forward_data, args=(client_socket, server_socket), daemon=True).start()
            threading.Thread(target=forward_data, args=(server_socket, client_socket), daemon=True).start()
            
            # Keep the connection open
            while True:
                time.sleep(1)
                if not running:
                    break
        else:
            # Forward the error response to the client
            client_socket.sendall(response)
            
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            client_socket.sendall(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
        except:
            pass

def build_websocket_request(request):
    """Build WebSocket upgrade request to send to the target server"""
    request_lines = [f"GET {request['path']} HTTP/1.1"]
    
    # Add headers
    for key, value in request['headers'].items():
        request_lines.append(f"{key}: {value}")
    
    # Build the full request
    return ('\r\n'.join(request_lines) + '\r\n\r\n').encode('utf-8')

def handle_https_connect(client_socket, request):
    """Handle HTTPS CONNECT tunneling"""
    try:
        # Parse the target address from the request path
        target = request['path']
        if ':' in target:
            target_host, target_port = target.split(':', 1)
            target_port = int(target_port)
        else:
            target_host = target
            target_port = 443
        
        # Create a socket to the target server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.connect((target_host, target_port))
        
        # Send 200 Connection established to the client
        client_socket.sendall(b'HTTP/1.1 200 Connection established\r\n\r\n')
        
        # Start bidirectional data exchange
        threading.Thread(target=forward_data, args=(client_socket, server_socket), daemon=True).start()
        threading.Thread(target=forward_data, args=(server_socket, client_socket), daemon=True).start()
        
        # Keep the connection open
        while True:
            time.sleep(1)
            if not running:
                break
            
    except Exception as e:
        logger.error(f"HTTPS tunneling error: {e}")
        try:
            client_socket.sendall(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
        except:
            pass

def handle_http_proxy(client_socket, request, original_data):
    """Handle regular HTTP proxy requests"""
    try:
        # Extract the target from the Host header or from the full URL
        if '://' in request['path']:
            # Full URL in path (e.g., http://example.com/path)
            import urllib.parse
            url = urllib.parse.urlparse(request['path'])
            target_host = url.netloc
            if ':' in target_host:
                target_host, target_port = target_host.split(':', 1)
                target_port = int(target_port)
            else:
                target_port = 80 if url.scheme == 'http' else 443
            path = url.path
            if url.query:
                path += '?' + url.query
        else:
            # Host header contains the target
            host_header = request['headers'].get('host', '')
            if ':' in host_header:
                target_host, target_port = host_header.split(':', 1)
                target_port = int(target_port)
            else:
                target_host = host_header
                target_port = 80
            path = request['path']
        
        # Create modified request with relative path and updated headers
        request_lines = [f"{request['method']} {path} HTTP/1.1"]
        for key, value in request['headers'].items():
            # Skip proxy-specific headers
            if key.lower() not in ['proxy-connection', 'connection']:
                request_lines.append(f"{key}: {value}")
        
        # Add Host header if not present
        if 'host' not in request['headers']:
            request_lines.append(f"Host: {target_host}")
        
        # Add Connection: close header
        request_lines.append("Connection: close")
        
        # Create a socket to the target server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # For HTTPS
        if target_port == 443:
            server_socket = ssl.wrap_socket(server_socket)
        
        server_socket.connect((target_host, target_port))
        
        # Send the modified request to the target server
        request_data = '\r\n'.join(request_lines) + '\r\n\r\n'
        server_socket.sendall(request_data.encode('utf-8'))
        
        # Receive and forward the response from the target server
        response = b''
        while True:
            data = server_socket.recv(4096)
            if not data:
                break
            response += data
            client_socket.sendall(data)
        
        server_socket.close()
        
    except Exception as e:
        logger.error(f"HTTP proxy error: {e}")
        try:
            client_socket.sendall(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
        except:
            pass

def forward_data(source, destination):
    """Forward data between two sockets"""
    try:
        while running:
            data = source.recv(4096)
            if not data:
                break
            destination.sendall(data)
    except:
        pass
    finally:
        try:
            source.close()
        except:
            pass
        try:
            destination.close()
        except:
            pass

def signal_handler(sig, frame):
    """Handle SIGINT and SIGTERM signals"""
    global running
    logger.info("Shutting down...")
    running = False
    
    # Close all connections
    for conn in list(connections):
        try:
            conn.close()
        except:
            pass
    
    sys.exit(0)

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Python Proxy with 101 Protocol support')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, required=True, help='Port to bind')
    
    args = parser.parse_args()
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create server socket
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        server.bind((args.host, args.port))
        server.listen(100)
        
        logger.info(f"Python Proxy server started on {args.host}:{args.port}")
        
        while running:
            try:
                client, address = server.accept()
                threading.Thread(target=handle_connection, args=(client, address), daemon=True).start()
            except Exception as e:
                if running:
                    logger.error(f"Error accepting connection: {e}")
    
    except Exception as e:
        logger.error(f"Server error: {e}")
    
    finally:
        server.close()
        logger.info("Server shut down")

if __name__ == "__main__":
    main()
EOF

    # Make script executable
    chmod +x /usr/local/bin/python_proxy.py
    
    # Create systemd service for Python Proxy
    echo_info "Creating systemd service for Python Proxy..."
    
    cat > /etc/systemd/system/python_proxy.service << EOF
[Unit]
Description=Python Proxy Service with 101 Protocol Support
After=network.target

[Service]
Type=simple
User=root
Environment=PORT=$proxy_port
ExecStart=/usr/bin/python3 /usr/local/bin/python_proxy.py --port \${PORT}
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd daemon
    systemctl daemon-reload
    
    # Start and enable Python Proxy service
    systemctl start python_proxy
    systemctl enable python_proxy
    
    # Verify that Python Proxy is running
    if ! is_service_active python_proxy; then
        echo_error "Python Proxy failed to start. Please check the logs with 'journalctl -u python_proxy'"
        return
    fi
    
    # Configure firewall
    configure_firewall
    
    # Generate client configuration information
    local server_ip=$(get_public_ip)
    echo_success "Python Proxy with 101 Protocol has been installed successfully!"
    echo_info "You can use the following proxy settings in your applications:"
    echo -e "${GREEN}------------------------------------------------${NC}"
    echo -e "${CYAN}Proxy Type:${NC} HTTP/SOCKS/WebSocket"
    echo -e "${CYAN}Proxy Host:${NC} $server_ip"
    echo -e "${CYAN}Proxy Port:${NC} $proxy_port"
    echo -e "${GREEN}------------------------------------------------${NC}"
    
    # Save configuration to file
    local config_info="Proxy Type: HTTP/SOCKS/WebSocket\nProxy Host: $server_ip\nProxy Port: $proxy_port"
    echo -e "$config_info" > "$SCRIPT_DIR/python_proxy_config.txt"
    echo_info "Configuration saved to $SCRIPT_DIR/python_proxy_config.txt"
}

# Show Python Proxy configuration
show_python_proxy_config() {
    echo_info "Python Proxy Configuration"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        local port=$(generate_random_port)
        local server_ip="your_server_ip"
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║                ${GREEN}Python Proxy Configuration${BLUE}                  ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Service Information:${NC}"
        echo -e "  ${WHITE}Status:${NC}      ${GREEN}[SIMULATED] Active${NC}"
        echo -e "  ${WHITE}Port:${NC}        ${CYAN}$port${NC}"
        echo -e "  ${WHITE}Server IP:${NC}   ${CYAN}$server_ip${NC}"
        
        echo -e "\n${YELLOW}🔹 Features:${NC}"
        echo -e "  ${WHITE}•${NC} HTTP/HTTPS proxy"
        echo -e "  ${WHITE}•${NC} WebSocket tunneling with 101 Protocol support"
        echo -e "  ${WHITE}•${NC} HTTPS CONNECT method support"
        
        echo -e "\n${YELLOW}🔹 Client Configuration:${NC}"
        echo -e "  ${WHITE}Browser proxy:${NC}"
        echo -e "    ${GRAY}Set HTTP proxy to:${NC} ${CYAN}http://$server_ip:$port${NC}"
        
        echo -e "\n  ${WHITE}Environment Variables:${NC}"
        echo -e "    ${GRAY}HTTP_PROXY=http://$server_ip:$port${NC}"
        echo -e "    ${GRAY}HTTPS_PROXY=http://$server_ip:$port${NC}"
        
        echo -e "\n  ${WHITE}Command Line:${NC}"
        echo -e "    ${GRAY}curl -x http://$server_ip:$port https://example.com${NC}"
        
        echo -e "\n${YELLOW}🔹 WebSocket Applications:${NC}"
        echo -e "  ${GRAY}WebSocket connections will be automatically tunneled through the proxy"
        echo -e "  using the 101 Protocol. No special configuration required for the application.${NC}"
        
        echo -e "\n${YELLOW}🔹 Port Management (Simulated):${NC}"
        echo -e "  ${WHITE}1)${NC} Change proxy port (current: $port)"
        echo -e "  ${WHITE}2)${NC} Continue without changes"
        
        echo -e "\n${YELLOW}🔹 Management Commands:${NC}"
        echo -e "  ${GRAY}• Start:${NC}   ${WHITE}systemctl start python_proxy${NC}"
        echo -e "  ${GRAY}• Stop:${NC}    ${WHITE}systemctl stop python_proxy${NC}"
        echo -e "  ${GRAY}• Restart:${NC} ${WHITE}systemctl restart python_proxy${NC}"
        echo -e "  ${GRAY}• Status:${NC}  ${WHITE}systemctl status python_proxy${NC}"
        
        return
    fi
    
    # Check if Python Proxy is installed
    if ! is_service_installed python_proxy; then
        echo_error "Python Proxy is not installed"
        echo_info "You can install it using option 10 from the main menu"
        return
    fi
    
    # Get service status and port information
    local status=$(systemctl is-active python_proxy)
    local proxy_port=$(grep -o 'PORT=[0-9]*' /etc/systemd/system/python_proxy.service | cut -d= -f2)
    local server_ip=$(get_public_ip)
    
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                ${GREEN}Python Proxy Configuration${BLUE}                  ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    echo -e "\n${YELLOW}🔹 Service Information:${NC}"
    if [[ "$status" == "active" ]]; then
        echo -e "  ${WHITE}Status:${NC}      ${GREEN}Active${NC}"
    else
        echo -e "  ${WHITE}Status:${NC}      ${RED}Inactive${NC} (run 'systemctl start python_proxy' to start)"
    fi
    echo -e "  ${WHITE}Port:${NC}        ${CYAN}$proxy_port${NC}"
    echo -e "  ${WHITE}Server IP:${NC}   ${CYAN}$server_ip${NC}"
    
    echo -e "\n${YELLOW}🔹 Features:${NC}"
    echo -e "  ${WHITE}•${NC} HTTP/HTTPS proxy"
    echo -e "  ${WHITE}•${NC} WebSocket tunneling with 101 Protocol support"
    echo -e "  ${WHITE}•${NC} HTTPS CONNECT method support"
    
    echo -e "\n${YELLOW}🔹 Client Configuration:${NC}"
    echo -e "  ${WHITE}Browser proxy:${NC}"
    echo -e "    ${GRAY}Set HTTP proxy to:${NC} ${CYAN}http://$server_ip:$proxy_port${NC}"
    
    echo -e "\n  ${WHITE}Environment Variables:${NC}"
    echo -e "    ${GRAY}HTTP_PROXY=http://$server_ip:$proxy_port${NC}"
    echo -e "    ${GRAY}HTTPS_PROXY=http://$server_ip:$proxy_port${NC}"
    
    echo -e "\n  ${WHITE}Command Line:${NC}"
    echo -e "    ${GRAY}curl -x http://$server_ip:$proxy_port https://example.com${NC}"
    
    echo -e "\n${YELLOW}🔹 WebSocket Applications:${NC}"
    echo -e "  ${GRAY}WebSocket connections will be automatically tunneled through the proxy"
    echo -e "  using the 101 Protocol. No special configuration required for the application.${NC}"
    
    echo -e "\n${YELLOW}🔹 Port Management:${NC}"
    echo -e "  ${WHITE}1)${NC} Change proxy port (current: $proxy_port)"
    echo -e "  ${WHITE}2)${NC} Continue without changes"
    echo -ne "${CYAN}Enter your choice [1-2]: ${NC}"
    read -r choice
    
    case $choice in
        1)  echo -ne "Enter new port (leave empty for random): "
            read -r new_port
            
            if [[ -z "$new_port" ]]; then
                new_port=$(find_available_port)
            elif ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1024 ] || [ "$new_port" -gt 65535 ]; then
                echo_error "Invalid port number. Using random port instead."
                new_port=$(find_available_port)
            elif ! is_port_available "$new_port"; then
                echo_error "Port $new_port is already in use. Using random port instead."
                new_port=$(find_available_port)
            fi
            
            echo_info "Updating Python Proxy port to $new_port..."
            sed -i "s/PORT=[0-9]*/PORT=$new_port/" /etc/systemd/system/python_proxy.service
            systemctl daemon-reload
            restart_service python_proxy
            echo_success "Python Proxy port updated to $new_port"
            
            # Update the port for display
            proxy_port=$new_port
            
            # Update the client configuration display
            echo -e "\n${YELLOW}🔹 Updated Client Configuration:${NC}"
            echo -e "  ${WHITE}Browser proxy:${NC}"
            echo -e "    ${GRAY}Set HTTP proxy to:${NC} ${CYAN}http://$server_ip:$proxy_port${NC}"
            
            echo -e "\n  ${WHITE}Environment Variables:${NC}"
            echo -e "    ${GRAY}HTTP_PROXY=http://$server_ip:$proxy_port${NC}"
            echo -e "    ${GRAY}HTTPS_PROXY=http://$server_ip:$proxy_port${NC}"
            
            echo -e "\n  ${WHITE}Command Line:${NC}"
            echo -e "    ${GRAY}curl -x http://$server_ip:$proxy_port https://example.com${NC}"
            ;;
        2)  echo_info "No changes made to port configuration"
            ;;
        *)  echo_error "Invalid option. No changes made."
            ;;
    esac
    
    echo -e "\n${YELLOW}🔹 Management Commands:${NC}"
    echo -e "  ${GRAY}• Start:${NC}   ${WHITE}systemctl start python_proxy${NC}"
    echo -e "  ${GRAY}• Stop:${NC}    ${WHITE}systemctl stop python_proxy${NC}"
    echo -e "  ${GRAY}• Restart:${NC} ${WHITE}systemctl restart python_proxy${NC}"
    echo -e "  ${GRAY}• Status:${NC}  ${WHITE}systemctl status python_proxy${NC}"
    
    echo -e "\n${YELLOW}🔹 Logs:${NC}"
    echo -e "  ${GRAY}View logs with:${NC} ${WHITE}journalctl -u python_proxy -f${NC}"
    
    # Port checker
    echo -e "\n${YELLOW}🔹 Connectivity Check:${NC}"
    if [[ "$status" == "active" ]]; then
        if lsof -i:"$proxy_port" -sTCP:LISTEN >/dev/null 2>&1; then
            echo -e "  ${WHITE}Port status:${NC} ${GREEN}LISTENING${NC}"
        else
            echo -e "  ${WHITE}Port status:${NC} ${RED}NOT LISTENING${NC} (Service is active but port is not open)"
        fi
        
        # Check if port is accessible from localhost
        if command_exists nc; then
            timeout 2 nc -z localhost "$proxy_port" >/dev/null 2>&1
            if [ $? -eq 0 ]; then
                echo -e "  ${WHITE}Local access:${NC} ${GREEN}ACCESSIBLE${NC}"
            else
                echo -e "  ${WHITE}Local access:${NC} ${RED}NOT ACCESSIBLE${NC}"
            fi
        fi
    else
        echo -e "  ${WHITE}Port status:${NC} ${YELLOW}UNKNOWN${NC} (Service is not active)"
    fi
}

# Uninstall Python Proxy
uninstall_python_proxy() {
    echo_info "Uninstalling Python Proxy..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating Python Proxy uninstallation..."
        
        echo -e "${YELLOW}╔══════════════════════════════════════════════╗${NC}"
        echo -e "${YELLOW}║              UNINSTALL WARNING               ║${NC}"
        echo -e "${YELLOW}╚══════════════════════════════════════════════╝${NC}"
        echo -e "\n${RED}This will completely remove Python Proxy from your system:${NC}"
        echo -e "  ${WHITE}•${NC} Stop and disable the Python Proxy service"
        echo -e "  ${WHITE}•${NC} Remove all configuration files"
        echo -e "  ${WHITE}•${NC} Remove the Python Proxy script"
        echo -e "  ${WHITE}•${NC} Ports will be closed and firewall rules removed"
        
        echo -e "\n${CYAN}Do you want to continue?${NC}"
        echo -e "  ${WHITE}1)${NC} Yes, uninstall Python Proxy"
        echo -e "  ${WHITE}2)${NC} No, keep Python Proxy installed"
        echo -ne "${CYAN}Enter your choice [1-2]: ${NC}"
        read -r choice
        
        case $choice in
            1)  echo_info "Simulating uninstallation..."
                sleep 2
                echo_success "Python Proxy has been uninstalled successfully (simulated)"
                ;;
            2)  echo_info "Uninstallation cancelled"
                return
                ;;
            *)  echo_error "Invalid option. Uninstallation cancelled."
                return
                ;;
        esac
        return
    fi
    
    # Check if Python Proxy is installed
    if ! is_service_installed python_proxy; then
        echo_error "Python Proxy is not installed"
        echo_info "There's nothing to uninstall"
        return
    fi
    
    # Get port information for backup message
    local proxy_port=$(grep -o 'PORT=[0-9]*' /etc/systemd/system/python_proxy.service | cut -d= -f2)
    local server_ip=$(get_public_ip)
    
    # Show warning and confirmation dialogue
    echo -e "${YELLOW}╔══════════════════════════════════════════════╗${NC}"
    echo -e "${YELLOW}║              UNINSTALL WARNING               ║${NC}"
    echo -e "${YELLOW}╚══════════════════════════════════════════════╝${NC}"
    echo -e "\n${RED}This will completely remove Python Proxy from your system:${NC}"
    echo -e "  ${WHITE}•${NC} Stop and disable the Python Proxy service"
    echo -e "  ${WHITE}•${NC} Remove all configuration files"
    echo -e "  ${WHITE}•${NC} Remove the Python Proxy script"
    echo -e "  ${WHITE}•${NC} Close port $proxy_port and remove firewall rules"
    
    echo -e "\n${GREEN}Current Configuration:${NC}"
    echo -e "  ${WHITE}Port:${NC} $proxy_port"
    echo -e "  ${WHITE}URL:${NC} http://$server_ip:$proxy_port"
    
    echo -e "\n${CYAN}Do you want to continue?${NC}"
    echo -e "  ${WHITE}1)${NC} Yes, uninstall Python Proxy"
    echo -e "  ${WHITE}2)${NC} No, keep Python Proxy installed"
    echo -e "  ${WHITE}3)${NC} Just stop the service (don't uninstall)"
    echo -ne "${CYAN}Enter your choice [1-3]: ${NC}"
    read -r choice
    
    case $choice in
        1)  echo_info "Uninstalling Python Proxy..."
            
            # First, backup configuration
            local backup_file="$SCRIPT_DIR/backup/python_proxy_config_$(date +%Y%m%d%H%M%S).txt"
            mkdir -p "$SCRIPT_DIR/backup"
            
            echo "Python Proxy Configuration Backup ($(date))" > "$backup_file"
            echo "Port: $proxy_port" >> "$backup_file"
            echo "URL: http://$server_ip:$proxy_port" >> "$backup_file"
            
            # Stop and disable Python Proxy service
            echo_info "Stopping and disabling service..."
            stop_service python_proxy
            systemctl disable python_proxy
            
            # Remove service file
            echo_info "Removing service files..."
            rm -f /etc/systemd/system/python_proxy.service
            
            # Remove Python Proxy script
            echo_info "Removing Python Proxy script..."
            rm -f /usr/local/bin/python_proxy.py
            
            # Remove configuration file
            echo_info "Removing configuration files..."
            rm -f "$SCRIPT_DIR/python_proxy_config.txt"
            
            # Reload systemd daemon
            systemctl daemon-reload
            
            echo_success "Python Proxy has been uninstalled successfully"
            echo_info "A backup of your configuration has been saved to: $backup_file"
            ;;
        2)  echo_info "Uninstallation cancelled"
            return
            ;;
        3)  echo_info "Stopping Python Proxy service..."
            stop_service python_proxy
            echo_success "Python Proxy service has been stopped"
            echo_info "The service is still installed and can be started with: systemctl start python_proxy"
            return
            ;;
        *)  echo_error "Invalid option. Uninstallation cancelled."
            return
            ;;
    esac
}
