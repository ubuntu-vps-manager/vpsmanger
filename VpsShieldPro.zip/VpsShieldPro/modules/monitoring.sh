#!/bin/bash

# Show system resources
show_system_resources() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                ${GREEN}System Resources${BLUE}                           ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    # Check if required tools are installed
    if ! command_exists top || ! command_exists free || ! command_exists df; then
        echo_info "Installing required tools..."
        apt update -y
        apt install -y procps coreutils
    fi
    
    # Show system uptime
    echo -e "${CYAN}System Uptime:${NC}"
    uptime
    echo
    
    # Show CPU info
    echo -e "${CYAN}CPU Information:${NC}"
    lscpu | grep -E 'Model name|^CPU\(s\)|Thread|Core|Socket' | sed 's/^/  /'
    echo
    
    # Show CPU usage
    echo -e "${CYAN}CPU Usage:${NC}"
    top -bn1 | grep "Cpu(s)" | awk '{print "  " $0}'
    echo
    
    # Show memory usage
    echo -e "${CYAN}Memory Usage:${NC}"
    free -h | awk 'NR==1 {print "  " $0} NR==2 {print "  " $0}'
    echo
    
    # Show disk usage
    echo -e "${CYAN}Disk Usage:${NC}"
    df -h / | awk 'NR==1 {print "  " $0} NR==2 {print "  " $0}'
    echo
    
    # Show running services
    echo -e "${CYAN}Service Status:${NC}"
    
    # V2Ray
    if is_service_installed v2ray; then
        local status=$(systemctl is-active v2ray)
        if [ "$status" == "active" ]; then
            echo -e "  ${GREEN}✓ V2Ray is running${NC}"
        else
            echo -e "  ${RED}✗ V2Ray is not running${NC}"
        fi
    else
        echo -e "  ${YELLOW}○ V2Ray is not installed${NC}"
    fi
    
    # SSH WebSocket
    if is_service_installed ssh_websocket; then
        local status=$(systemctl is-active ssh_websocket)
        if [ "$status" == "active" ]; then
            echo -e "  ${GREEN}✓ SSH WebSocket is running${NC}"
        else
            echo -e "  ${RED}✗ SSH WebSocket is not running${NC}"
        fi
    else
        echo -e "  ${YELLOW}○ SSH WebSocket is not installed${NC}"
    fi
    
    # Python Proxy
    if is_service_installed python_proxy; then
        local status=$(systemctl is-active python_proxy)
        if [ "$status" == "active" ]; then
            echo -e "  ${GREEN}✓ Python Proxy is running${NC}"
        else
            echo -e "  ${RED}✗ Python Proxy is not running${NC}"
        fi
    else
        echo -e "  ${YELLOW}○ Python Proxy is not installed${NC}"
    fi
    
    # SSE Proxy
    if is_service_installed sse_proxy; then
        local status=$(systemctl is-active sse_proxy)
        if [ "$status" == "active" ]; then
            echo -e "  ${GREEN}✓ SSE Proxy is running${NC}"
        else
            echo -e "  ${RED}✗ SSE Proxy is not running${NC}"
        fi
    else
        echo -e "  ${YELLOW}○ SSE Proxy is not installed${NC}"
    fi
    
    # Nginx
    if is_service_installed nginx; then
        local status=$(systemctl is-active nginx)
        if [ "$status" == "active" ]; then
            echo -e "  ${GREEN}✓ Nginx is running${NC}"
        else
            echo -e "  ${RED}✗ Nginx is not running${NC}"
        fi
    else
        echo -e "  ${YELLOW}○ Nginx is not installed${NC}"
    fi
    
    echo
    
    # Show network connections
    echo -e "${CYAN}Active Network Connections:${NC}"
    if command_exists netstat; then
        netstat -tuln | grep -E ':(22|80|443|8080|10000)' | awk '{print "  " $0}'
    elif command_exists ss; then
        ss -tuln | grep -E ':(22|80|443|8080|10000)' | awk '{print "  " $0}'
    else
        echo_info "Installing network tools..."
        apt update -y
        apt install -y net-tools
        netstat -tuln | grep -E ':(22|80|443|8080|10000)' | awk '{print "  " $0}'
    fi
    echo
    
    # Show recent logins
    echo -e "${CYAN}Recent Logins:${NC}"
    last -a | head -5 | awk '{print "  " $0}'
    echo
    
    # Show system logs
    echo -e "${CYAN}Recent System Logs:${NC}"
    journalctl -n 5 --no-pager | awk '{print "  " $0}'
    echo
}

# Show specific service logs
show_service_logs() {
    local service=$1
    
    # Check if service is installed
    if ! is_service_installed "$service"; then
        echo_error "$service is not installed"
        return
    fi
    
    # Show logs
    echo_info "Recent logs for $service:"
    journalctl -u "$service" -n 50 --no-pager
}

# Monitor system in real-time
monitor_system() {
    # Check if required tools are installed
    if ! command_exists top; then
        echo_info "Installing required tools..."
        apt update -y
        apt install -y procps
    fi
    
    # Run top
    top
}
