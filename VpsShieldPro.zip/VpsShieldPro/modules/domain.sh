#!/bin/bash

# Domain management
manage_domain() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                ${GREEN}Domain Management${BLUE}                          ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    echo -e "\n${CYAN}Select an option:${NC}"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "  ${WHITE}1)${NC} Configure domain"
    echo -e "  ${WHITE}2)${NC} Check domain configuration"
    echo -e "  ${WHITE}3)${NC} Verify domain DNS"
    echo -e "  ${WHITE}4)${NC} Update domain settings"
    echo -e "  ${WHITE}5)${NC} Obtain SSL certificate"
    echo -e "  ${WHITE}6)${NC} Renew SSL certificate"
    echo -e "  ${WHITE}0)${NC} Return to main menu"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    echo -ne "${CYAN}Enter your choice [0-6]: ${NC}"
    read -r choice
    
    case $choice in
        0)  return
            ;;
        1)  configure_domain
            ;;
        2)  check_domain_config
            ;;
        3)  verify_domain_dns_ui
            ;;
        4)  update_domain_settings
            ;;
        5)  obtain_ssl_cert_ui
            ;;
        6)  renew_ssl_cert
            ;;
        *)  echo_error "Invalid option. Please try again."
            sleep 2
            manage_domain
            ;;
    esac
    
    # Return to domain management menu after function execution
    read -p "Press Enter to continue..."
    manage_domain
}

# Configure domain
configure_domain() {
    echo_info "Domain Configuration"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating domain configuration..."
        
        # If domain already exists in test mode
        if [ -f "$SCRIPT_DIR/.domain" ]; then
            DOMAIN=$(cat "$SCRIPT_DIR/.domain")
            echo_info "Current domain: $DOMAIN"
            echo_info "Do you want to configure a new domain? (y/n)"
            read -r choice
            if [[ ! $choice =~ ^[Yy]$ ]]; then
                return
            fi
        fi
        
        # Prompt for domain in test mode
        echo_info "Enter your domain name (e.g., example.com):"
        read -r domain
        
        # Validate domain format
        if [[ ! $domain =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$ ]]; then
            echo_error "Invalid domain format"
            return
        fi
        
        # Save domain
        echo "$domain" > "$SCRIPT_DIR/.domain"
        DOMAIN="$domain"
        
        echo_success "Domain $domain has been configured successfully (simulated)"
        echo_success "In test mode, we assume the domain is correctly pointing to your server"
        return
    fi
    
    # Check if domain is already configured
    if [ -f "$SCRIPT_DIR/.domain" ]; then
        DOMAIN=$(cat "$SCRIPT_DIR/.domain")
        echo_info "Current domain: $DOMAIN"
        echo_info "Do you want to configure a new domain? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
    fi
    
    # Prompt for domain
    echo_info "Enter your domain name (e.g., example.com):"
    read -r domain
    
    # Validate domain format
    if [[ ! $domain =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$ ]]; then
        echo_error "Invalid domain format"
        return
    fi
    
    # Get server IP
    local server_ip=$(get_public_ip)
    
    # Show information
    echo_info "Domain: $domain"
    echo_info "Server IP: $server_ip"
    echo_info "Please ensure that your domain is pointed to this server's IP address"
    echo_info "You can do this by setting an A record for your domain to point to $server_ip"
    
    # Ask for confirmation
    echo_info "Do you want to proceed with this domain? (y/n)"
    read -r choice
    if [[ ! $choice =~ ^[Yy]$ ]]; then
        return
    fi
    
    # Save domain
    echo "$domain" > "$SCRIPT_DIR/.domain"
    DOMAIN="$domain"
    
    echo_success "Domain $domain has been configured successfully"
    
    # Verify domain DNS
    if check_domain_dns "$domain"; then
        echo_success "Domain $domain is correctly pointing to this server"
    else
        echo_warning "Domain $domain is not pointing to this server's IP ($server_ip)"
        echo_info "Please update your DNS records and try again later"
    fi
}

# Check domain configuration
check_domain_config() {
    echo_info "Checking domain configuration..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        # Check if domain is configured
        if [ ! -f "$SCRIPT_DIR/.domain" ]; then
            echo_error "No domain configured"
            return
        fi
        
        # Get domain
        DOMAIN=$(cat "$SCRIPT_DIR/.domain")
        
        # Show domain information
        echo_info "Domain: $DOMAIN"
        echo_info "Server IP: 198.51.100.1 (example IP for test mode)"
        
        # In test mode, always report success
        echo_success "Test mode: Domain $DOMAIN is simulated to point to this server"
        echo_success "Test mode: SSL certificate is simulated to be installed for $DOMAIN"
        echo_info "Certificate expires on: 2024-12-31 23:59:59 UTC (simulated)"
        return
    fi
    
    # Check if domain is configured
    if [ ! -f "$SCRIPT_DIR/.domain" ]; then
        echo_error "No domain configured"
        return
    fi
    
    # Get domain
    DOMAIN=$(cat "$SCRIPT_DIR/.domain")
    
    # Get server IP
    local server_ip=$(get_public_ip)
    
    # Show domain information
    echo_info "Domain: $DOMAIN"
    echo_info "Server IP: $server_ip"
    
    # Check DNS
    if check_domain_dns "$DOMAIN"; then
        echo_success "Domain $DOMAIN is correctly pointing to this server"
    else
        echo_warning "Domain $DOMAIN is not pointing to this server's IP ($server_ip)"
        echo_info "Please update your DNS records"
    fi
    
    # Check SSL certificate
    if [ -d "/etc/letsencrypt/live/$DOMAIN" ]; then
        echo_success "SSL certificate is installed for $DOMAIN"
        
        # Check expiration date
        if command_exists certbot; then
            local cert_info=$(certbot certificates -d "$DOMAIN" 2>/dev/null)
            local expiry=$(echo "$cert_info" | grep "Expiry Date" | awk '{print $3 " " $4 " " $5 " " $6}')
            if [ ! -z "$expiry" ]; then
                echo_info "Certificate expires on: $expiry"
            fi
        fi
    else
        echo_warning "SSL certificate is not installed for $DOMAIN"
    fi
}

# Verify domain DNS through UI
verify_domain_dns_ui() {
    echo_info "Verifying domain DNS..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        # Check if domain is configured
        if [ ! -f "$SCRIPT_DIR/.domain" ]; then
            echo_error "No domain configured. Please configure a domain first."
            return
        fi
        
        # Get domain
        DOMAIN=$(cat "$SCRIPT_DIR/.domain")
        
        # Show domain information
        echo_info "Domain: $DOMAIN"
        echo_info "Server IP: 198.51.100.1 (example IP for test mode)"
        
        # In test mode, always report success
        echo_info "Test mode: Checking DNS records... (simulated)"
        echo_info "Domain $DOMAIN resolves to: 198.51.100.1 (simulated)"
        echo_success "Test mode: Domain $DOMAIN is correctly pointing to this server (simulated)"
        return
    fi
    
    # Check if domain is configured
    if [ ! -f "$SCRIPT_DIR/.domain" ]; then
        echo_error "No domain configured. Please configure a domain first."
        return
    fi
    
    # Get domain
    DOMAIN=$(cat "$SCRIPT_DIR/.domain")
    
    # Get server IP
    local server_ip=$(get_public_ip)
    
    # Show domain information
    echo_info "Domain: $DOMAIN"
    echo_info "Server IP: $server_ip"
    
    # Check DNS
    echo_info "Checking DNS records..."
    local domain_ip=$(dig +short "$DOMAIN" | tail -n1)
    
    if [ -z "$domain_ip" ]; then
        echo_error "Could not resolve domain $DOMAIN"
        echo_info "Please check that you have created an A record for your domain"
        return
    fi
    
    echo_info "Domain $DOMAIN resolves to: $domain_ip"
    
    if [ "$domain_ip" = "$server_ip" ]; then
        echo_success "Domain $DOMAIN is correctly pointing to this server"
    else
        echo_warning "Domain $DOMAIN is not pointing to this server's IP ($server_ip)"
        echo_info "Please update your DNS records"
        echo_info "Current DNS record: $DOMAIN -> $domain_ip"
        echo_info "Required DNS record: $DOMAIN -> $server_ip"
    fi
}

# Obtain SSL certificate through UI
obtain_ssl_cert_ui() {
    echo_info "Obtaining SSL certificate..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        # Check if domain is configured
        if [ ! -f "$SCRIPT_DIR/.domain" ]; then
            echo_error "No domain configured. Please configure a domain first."
            return
        fi
        
        # Get domain
        DOMAIN=$(cat "$SCRIPT_DIR/.domain")
        
        # Ask for email address
        echo_info "Enter your email address for certificate notifications:"
        read -r email
        
        # Validate email format
        if [[ ! $email =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
            echo_error "Invalid email format"
            return
        fi
        
        echo_info "Test mode: Simulating SSL certificate acquisition for $DOMAIN..."
        sleep 2
        echo_success "Test mode: SSL certificate for $DOMAIN has been obtained successfully (simulated)"
        return
    fi
    
    # Check if domain is configured
    if [ ! -f "$SCRIPT_DIR/.domain" ]; then
        echo_error "No domain configured. Please configure a domain first."
        return
    fi
    
    # Get domain
    DOMAIN=$(cat "$SCRIPT_DIR/.domain")
    
    # Verify domain DNS
    if ! check_domain_dns "$DOMAIN"; then
        echo_error "Domain $DOMAIN is not pointing to this server"
        echo_info "Please update your DNS records and try again later"
        echo_info "Do you want to continue anyway? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
    fi
    
    # Ask for email address
    echo_info "Enter your email address for certificate notifications:"
    read -r email
    
    # Validate email format
    if [[ ! $email =~ ^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$ ]]; then
        echo_error "Invalid email format"
        return
    fi
    
    # Obtain certificate
    obtain_ssl_cert "$DOMAIN" "$email"
}

# Obtain SSL certificate
obtain_ssl_cert() {
    local domain=$1
    local email=${2:-""}
    
    echo_info "Obtaining SSL certificate for $domain..."
    
    # Check if certbot is installed
    if ! command_exists certbot; then
        echo_info "Installing certbot..."
        apt update -y
        apt install -y certbot python3-certbot-nginx
    fi
    
    # Stop nginx if it's running to free up port 80
    if systemctl is-active --quiet nginx; then
        systemctl stop nginx
    fi
    
    # Get certificate
    if [ -z "$email" ]; then
        certbot certonly --standalone --non-interactive --agree-tos --preferred-challenges http -d "$domain"
    else
        certbot certonly --standalone --non-interactive --agree-tos --preferred-challenges http -d "$domain" --email "$email"
    fi
    
    # Check if certificate was obtained
    if [ $? -eq 0 ]; then
        echo_success "SSL certificate for $domain has been obtained successfully"
        
        # Start nginx if it was running
        if systemctl is-enabled --quiet nginx; then
            systemctl start nginx
        fi
        
        return 0
    else
        echo_error "Failed to obtain SSL certificate for $domain"
        
        # Start nginx if it was running
        if systemctl is-enabled --quiet nginx; then
            systemctl start nginx
        fi
        
        return 1
    fi
}

# Update domain settings
update_domain_settings() {
    echo_info "Update Domain Settings"
    echo "─────────────────────────────────────"
    
    # Check if domain is configured
    if [ ! -f "$SCRIPT_DIR/.domain" ]; then
        echo_error "No domain configured. Please configure a domain first."
        return
    fi
    
    # Get current domain
    local current_domain=$(cat "$SCRIPT_DIR/.domain")
    echo_info "Current domain: $current_domain"
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Domain update simulation"
        
        # Ask for new domain
        echo_info "Enter new domain name (leave empty to keep current):"
        read -r new_domain
        
        if [ -z "$new_domain" ]; then
            echo_info "Keeping current domain: $current_domain"
            return
        fi
        
        # Validate domain format
        if [[ ! $new_domain =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$ ]]; then
            echo_error "Invalid domain format"
            return
        fi
        
        # Confirm update
        echo_info "Update domain from '$current_domain' to '$new_domain'?"
        echo_warning "This will require reconfiguring services that use this domain."
        read -p "Proceed? (y/n): " -r confirm
        
        if [[ ! $confirm =~ ^[Yy]$ ]]; then
            echo_info "Domain update cancelled"
            return
        fi
        
        # Update domain file
        echo "$new_domain" > "$SCRIPT_DIR/.domain"
        DOMAIN="$new_domain"
        
        echo_success "Domain updated to $new_domain (simulated)"
        echo_info "Test Mode: Services would be reconfigured in real mode"
        return
    fi
    
    # Real mode implementation
    # Ask for new domain
    echo_info "Enter new domain name (leave empty to keep current):"
    read -r new_domain
    
    if [ -z "$new_domain" ]; then
        echo_info "Keeping current domain: $current_domain"
        return
    fi
    
    # Validate domain format
    if [[ ! $new_domain =~ ^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$ ]]; then
        echo_error "Invalid domain format"
        return
    fi
    
    # Check DNS for new domain
    local server_ip=$(get_public_ip)
    echo_info "Checking DNS for $new_domain..."
    
    if ! check_domain_dns "$new_domain"; then
        echo_warning "Domain $new_domain is not pointing to this server's IP ($server_ip)"
        echo_info "It's recommended to update your DNS records before proceeding"
        read -p "Continue anyway? (y/n): " -r dns_confirm
        
        if [[ ! $dns_confirm =~ ^[Yy]$ ]]; then
            echo_info "Domain update cancelled"
            return
        fi
    fi
    
    # Confirm update
    echo_info "Update domain from '$current_domain' to '$new_domain'?"
    echo_warning "This will require reconfiguring services that use this domain."
    echo_warning "SSL certificates will need to be regenerated for the new domain."
    read -p "Proceed? (y/n): " -r confirm
    
    if [[ ! $confirm =~ ^[Yy]$ ]]; then
        echo_info "Domain update cancelled"
        return
    fi
    
    # Update domain file
    echo "$new_domain" > "$SCRIPT_DIR/.domain"
    DOMAIN="$new_domain"
    
    echo_success "Domain updated to $new_domain"
    
    # Check if v2ray TLS is installed
    if systemctl is-enabled --quiet v2ray 2>/dev/null; then
        echo_info "V2Ray service detected. You may need to reconfigure it with the new domain."
        echo_info "Please use option 3 from the main menu to reconfigure V2Ray TLS."
    fi
    
    # Check if nginx is configured
    if [ -f "/etc/nginx/conf.d/$current_domain.conf" ]; then
        echo_info "Updating Nginx configuration..."
        
        # Backup old config
        cp "/etc/nginx/conf.d/$current_domain.conf" "/etc/nginx/conf.d/$current_domain.conf.bak"
        
        # Create new config
        sed "s/$current_domain/$new_domain/g" "/etc/nginx/conf.d/$current_domain.conf.bak" > "/etc/nginx/conf.d/$new_domain.conf"
        
        # Remove old config
        rm -f "/etc/nginx/conf.d/$current_domain.conf"
        
        # Reload nginx
        if systemctl is-active --quiet nginx; then
            systemctl reload nginx
        fi
        
        echo_success "Nginx configuration updated"
    fi
    
    echo_info "Would you like to obtain SSL certificate for the new domain now? (y/n)"
    read -r ssl_confirm
    
    if [[ $ssl_confirm =~ ^[Yy]$ ]]; then
        obtain_ssl_cert_ui
    else
        echo_info "You can obtain SSL certificate later using option 5 from the domain menu."
    fi
}

# Renew SSL certificate
renew_ssl_cert() {
    echo_info "Renewing SSL certificate..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        # Check if domain is configured
        if [ ! -f "$SCRIPT_DIR/.domain" ]; then
            echo_error "No domain configured"
            return
        fi
        
        # Get domain
        DOMAIN=$(cat "$SCRIPT_DIR/.domain")
        
        echo_info "Test mode: Simulating SSL certificate renewal for $DOMAIN..."
        sleep 2
        echo_success "Test mode: SSL certificate for $DOMAIN has been renewed successfully (simulated)"
        return
    fi
    
    # Check if domain is configured
    if [ ! -f "$SCRIPT_DIR/.domain" ]; then
        echo_error "No domain configured"
        return
    fi
    
    # Get domain
    DOMAIN=$(cat "$SCRIPT_DIR/.domain")
    
    # Check if certificate exists
    if [ ! -d "/etc/letsencrypt/live/$DOMAIN" ]; then
        echo_error "SSL certificate is not installed for $DOMAIN"
        echo_info "Would you like to obtain a certificate? (y/n)"
        read -r choice
        if [[ $choice =~ ^[Yy]$ ]]; then
            obtain_ssl_cert_ui
        fi
        return
    fi
    
    # Check if certbot is installed
    if ! command_exists certbot; then
        echo_info "Installing certbot..."
        apt update -y
        apt install -y certbot python3-certbot-nginx
    fi
    
    # Stop nginx if it's running to free up port 80
    if systemctl is-active --quiet nginx; then
        systemctl stop nginx
    fi
    
    # Renew certificate
    certbot renew --force-renewal
    
    # Check if certificate was renewed
    if [ $? -eq 0 ]; then
        echo_success "SSL certificate for $DOMAIN has been renewed successfully"
        
        # Start nginx if it was running
        if systemctl is-enabled --quiet nginx; then
            systemctl start nginx
        fi
        
        # Restart services that use SSL
        if is_service_active v2ray; then
            restart_service v2ray
        fi
        
        if is_service_active nginx; then
            restart_service nginx
        fi
    else
        echo_error "Failed to renew SSL certificate for $DOMAIN"
        
        # Start nginx if it was running
        if systemctl is-enabled --quiet nginx; then
            systemctl start nginx
        fi
    fi
}

# SSL certificate management
manage_ssl() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                ${GREEN}SSL Certificate Management${BLUE}                 ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    echo -e "\n${CYAN}Select an option:${NC}"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "  ${WHITE}1)${NC} Obtain SSL certificate"
    echo -e "  ${WHITE}2)${NC} Renew SSL certificate"
    echo -e "  ${WHITE}3)${NC} View SSL certificate info"
    echo -e "  ${WHITE}0)${NC} Return to main menu"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    echo -ne "${CYAN}Enter your choice [0-3]: ${NC}"
    read -r choice
    
    case $choice in
        0)  return
            ;;
        1)  obtain_ssl_cert_ui
            ;;
        2)  renew_ssl_cert
            ;;
        3)  view_ssl_cert_info
            ;;
        *)  echo_error "Invalid option. Please try again."
            sleep 2
            manage_ssl
            ;;
    esac
    
    # Return to SSL management menu after function execution
    read -p "Press Enter to continue..."
    manage_ssl
}

# View SSL certificate info
view_ssl_cert_info() {
    echo_info "SSL Certificate Information:"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        # Check if domain is configured
        if [ ! -f "$SCRIPT_DIR/.domain" ]; then
            echo_error "No domain configured"
            return
        fi
        
        # Get domain
        DOMAIN=$(cat "$SCRIPT_DIR/.domain")
        
        # Show simulated certificate information
        echo_info "Test mode: Simulated SSL certificate information for $DOMAIN"
        echo
        echo "Saving debug log to /var/log/letsencrypt/letsencrypt.log (simulated)"
        echo
        echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
        echo "Found the following certs:"
        echo "  Certificate Name: $DOMAIN"
        echo "    Domains: $DOMAIN"
        echo "    Expiry Date: 2024-12-31 23:59:59+00:00 (VALID: 275 days) (simulated)"
        echo "    Certificate Path: /etc/letsencrypt/live/$DOMAIN/fullchain.pem (simulated)"
        echo "    Private Key Path: /etc/letsencrypt/live/$DOMAIN/privkey.pem (simulated)"
        echo "- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -"
        echo
        
        # Show simulated OpenSSL certificate details
        echo_info "Certificate details (simulated):"
        echo "Certificate:"
        echo "    Data:"
        echo "        Version: 3 (0x2)"
        echo "        Serial Number: 123456789 (0x12345678)"
        echo "        Signature Algorithm: sha256WithRSAEncryption"
        echo "        Issuer: C=US, O=Let's Encrypt, CN=R3"
        echo "        Validity"
        echo "            Not Before: May 1 00:00:00 2023 GMT"
        echo "            Not After : Dec 31 23:59:59 2024 GMT"
        echo "        Subject: CN=$DOMAIN"
        echo "        Subject Public Key Info:"
        echo "            Public Key Algorithm: rsaEncryption"
        echo "                RSA Public-Key: (2048 bit)"
        return
    fi
    
    # Check if domain is configured
    if [ ! -f "$SCRIPT_DIR/.domain" ]; then
        echo_error "No domain configured"
        return
    fi
    
    # Get domain
    DOMAIN=$(cat "$SCRIPT_DIR/.domain")
    
    # Check if certificate exists
    if [ ! -d "/etc/letsencrypt/live/$DOMAIN" ]; then
        echo_error "SSL certificate is not installed for $DOMAIN"
        return
    fi
    
    # Check if certbot is installed
    if ! command_exists certbot; then
        echo_info "Installing certbot..."
        apt update -y
        apt install -y certbot python3-certbot-nginx
    fi
    
    # Show certificate information
    certbot certificates -d "$DOMAIN"
    
    # Show OpenSSL certificate details
    echo_info "Certificate details:"
    openssl x509 -in "/etc/letsencrypt/live/$DOMAIN/cert.pem" -text -noout | head -20
}
