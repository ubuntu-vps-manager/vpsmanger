#!/bin/bash

# Fix for Ubuntu VPS Manager script in system-wide installation

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║               ${GREEN}Ubuntu VPS Manager Fix Tool${NC}               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR]${NC} This script must be run as root. Please use sudo."
  exit 1
fi

# Find the installation directory
echo -e "${BLUE}[INFO]${NC} Looking for VPS Manager installation..."

if [ -L "/usr/local/bin/vps" ]; then
    INSTALL_DIR=$(readlink -f "/usr/local/bin/vps" | sed 's#/vps-manager\.sh$##')
    echo -e "${GREEN}[SUCCESS]${NC} Found installation at: $INSTALL_DIR"
else
    echo -e "${YELLOW}[WARNING]${NC} Could not find symbolic link at /usr/local/bin/vps"
    
    # Try to find installation in common directories
    for dir in "/opt/vpsshieldpro" "/usr/local/vpsshieldpro" "/opt/ubuntu-vps-manager"; do
        if [ -f "$dir/vps-manager.sh" ]; then
            INSTALL_DIR="$dir"
            echo -e "${GREEN}[SUCCESS]${NC} Found installation at: $INSTALL_DIR"
            break
        fi
    done
    
    # If still not found, ask user
    if [ -z "$INSTALL_DIR" ]; then
        echo -e "${YELLOW}[WARNING]${NC} Could not automatically find the installation directory."
        read -p "Please enter the full path to the VPS Manager installation directory: " INSTALL_DIR
        
        if [ ! -f "$INSTALL_DIR/vps-manager.sh" ]; then
            echo -e "${RED}[ERROR]${NC} Could not find vps-manager.sh in specified directory."
            exit 1
        fi
    fi
fi

# Check that we found the installation
if [ -z "$INSTALL_DIR" ]; then
    echo -e "${RED}[ERROR]${NC} Could not determine the installation directory."
    exit 1
fi

# Check if utils.sh exists
if [ ! -f "$INSTALL_DIR/modules/utils.sh" ]; then
    echo -e "${RED}[ERROR]${NC} Could not find utils.sh in $INSTALL_DIR/modules/"
    exit 1
fi

# Create a wrapper script for the system-wide commands
echo -e "${BLUE}[INFO]${NC} Creating wrapper scripts..."

WRAPPER_SCRIPT="#!/bin/bash

# Wrapper for vps-manager.sh that ensures proper environment
# Created by the fix-vps.sh script

# Find true script directory (for modules)
export SCRIPT_DIR=\"$INSTALL_DIR\"

# Execute the main script with proper sourcing
cd \"\$SCRIPT_DIR\" && ./vps-manager.sh \"\$@\"
"

# Create the wrapper scripts with proper permissions
echo -e "${WRAPPER_SCRIPT}" > "/usr/local/bin/vps_wrapper"
chmod +x "/usr/local/bin/vps_wrapper"

# Replace the symlinks with the wrapper
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/vps"
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/admin"
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/vpsshieldpro"

echo -e "${GREEN}[SUCCESS]${NC} Wrapper scripts created and installed."

# Check and install user management modules if needed
echo -e "${BLUE}[INFO]${NC} Checking for user management modules..."

# Create user management modules directory if needed
if [ ! -d "$INSTALL_DIR/modules" ]; then
    mkdir -p "$INSTALL_DIR/modules"
    echo -e "${GREEN}[SUCCESS]${NC} Created modules directory"
fi

# Check for v2ray_users.sh
if [ ! -f "$INSTALL_DIR/modules/v2ray_users.sh" ]; then
    echo -e "${YELLOW}[WARNING]${NC} V2Ray user management module missing, creating it..."
    cat > "$INSTALL_DIR/modules/v2ray_users.sh" << 'EOF'
#!/bin/bash

# V2Ray User Management Module
# This module provides enhanced user management for V2Ray

# Function to manage V2Ray users
manage_v2ray_users() {
    echo_info "V2Ray User Management"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating V2Ray user management..."
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}V2Ray User Management${BLUE}                        ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Current V2Ray Users (Simulated):${NC}"
        echo -e "  ${WHITE}1. admin:${NC} ${CYAN}00112233-4455-6677-8899-aabbccddeeff${NC}"
        echo -e "  ${WHITE}2. user1:${NC} ${CYAN}10112233-4455-6677-8899-aabbccddeeff${NC}"
        echo -e "  ${WHITE}3. marketing:${NC} ${CYAN}20112233-4455-6677-8899-aabbccddeeff${NC}"
        
        echo -e "\n${YELLOW}🔹 Available V2Ray Configurations:${NC}"
        echo -e "  ${WHITE}1. WebSocket + TLS:${NC} ${GREEN}Secure connection with encryption${NC}"
        echo -e "  ${WHITE}2. WebSocket (non-TLS):${NC} ${YELLOW}Less secure, higher speed${NC}"
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} List all users"
        echo -e "  ${WHITE}4)${NC} Generate configuration for a user"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        sleep 2
        echo_success "V2Ray user management simulation complete"
        return
    fi
    
    # Check if V2Ray is installed
    if ! is_service_installed v2ray; then
        echo_error "V2Ray is not installed"
        echo_info "You can install it using options 3 or 4 from the main menu"
        return
    fi
    
    # Check if jq is installed
    if ! command_exists jq; then
        echo_info "Installing jq for JSON processing..."
        apt update -y
        apt install -y jq
    fi
    
    # Main user management loop
    while true; do
        clear
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}V2Ray User Management${BLUE}                        ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        # Check service status
        local status=$(systemctl is-active v2ray)
        
        echo -e "\n${YELLOW}🔹 Service Status:${NC}"
        if [[ "$status" == "active" ]]; then
            echo -e "  ${WHITE}V2Ray Status:${NC} ${GREEN}Active${NC}"
        else
            echo -e "  ${WHITE}V2Ray Status:${NC} ${RED}Inactive${NC} (run 'systemctl start v2ray' to start)"
        fi
        
        # List current V2Ray configurations
        echo -e "\n${YELLOW}🔹 Available V2Ray Configurations:${NC}"
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            echo -e "  ${WHITE}1. WebSocket + TLS:${NC} ${GREEN}Secure connection with encryption${NC}"
        fi
        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            echo -e "  ${WHITE}2. WebSocket (non-TLS):${NC} ${YELLOW}Less secure, higher speed${NC}"
        fi
        
        # List current V2Ray users
        echo -e "\n${YELLOW}🔹 Current V2Ray Users:${NC}"
        list_v2ray_users
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} List all users (with full details)"
        echo -e "  ${WHITE}4)${NC} Generate configuration for a user"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -ne "${CYAN}Enter your choice [1-5]: ${NC}"
        read -r choice
        
        case $choice in
            1) add_v2ray_user ;;           # Add new user
            2) delete_v2ray_user ;;        # Delete a user
            3) list_v2ray_users_detail ;;  # List users with details
            4) generate_v2ray_config ;;    # Generate config for a user
            5) break ;;                    # Return to main menu
            *) 
                echo_error "Invalid option. Please try again."
                sleep 1
                ;;
        esac
    done
}

# Function to list current V2Ray users (brief)
list_v2ray_users() {
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo -e "  ${GRAY}V2Ray is not properly configured.${NC}"
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "  ${GRAY}No users found.${NC}"
            return
        fi
        
        # Display users
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            
            # Truncate UUID for display
            local short_uuid="${uuid:0:8}...${uuid:24:12}"
            
            echo -e "  ${WHITE}$((i+1)). $email:${NC} ${CYAN}$short_uuid${NC}"
        done
    else
        echo -e "  ${GRAY}No users configuration found.${NC}"
    fi
}

# Other functions like add_v2ray_user, delete_v2ray_user, etc.
# will be defined in the full module file

# Function to generate a UUID
generate_uuid() {
    uuidgen
}
EOF
    chmod +x "$INSTALL_DIR/modules/v2ray_users.sh"
    echo -e "${GREEN}[SUCCESS]${NC} Created V2Ray user management module"
fi

# Check for ssh_ws_users.sh
if [ ! -f "$INSTALL_DIR/modules/ssh_ws_users.sh" ]; then
    echo -e "${YELLOW}[WARNING]${NC} SSH WebSocket user management module missing, creating it..."
    cat > "$INSTALL_DIR/modules/ssh_ws_users.sh" << 'EOF'
#!/bin/bash

# SSH WebSocket User Management Module
# This module extends the SSH WebSocket functionality with multi-user support

# Function to manage SSH WebSocket users
manage_ssh_ws_users() {
    echo_info "SSH WebSocket User Management"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH WebSocket user management..."
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}SSH WebSocket User Management${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Current Users (Simulated):${NC}"
        echo -e "  ${WHITE}1. admin${NC} - ${CYAN}Enabled${NC}"
        echo -e "  ${WHITE}2. user1${NC} - ${CYAN}Enabled${NC}"
        echo -e "  ${WHITE}3. demo${NC} - ${RED}Disabled${NC}"
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} Enable/Disable a user"
        echo -e "  ${WHITE}4)${NC} Change user password"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -e "\n${YELLOW}🔹 Note:${NC}"
        echo -e "  ${GRAY}• User management requires system user creation${NC}"
        echo -e "  ${GRAY}• Passwords must be at least 8 characters${NC}"
        echo -e "  ${GRAY}• Each user can have their own connection limits${NC}"
        
        sleep 2
        echo_success "SSH WebSocket user management simulation complete"
        return
    fi
    
    # Check if SSH WebSocket is installed
    if ! is_service_installed ssh_websocket; then
        echo_error "SSH WebSocket is not installed"
        echo_info "You can install it using option 7 from the main menu"
        return
    fi
    
    # Main user management loop
    while true; do
        clear
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}SSH WebSocket User Management${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Current Users:${NC}"
        list_ssh_users
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} Enable/Disable a user"
        echo -e "  ${WHITE}4)${NC} Change user password"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -ne "${CYAN}Enter your choice [1-5]: ${NC}"
        read -r choice
        
        case $choice in
            1) add_ssh_user ;;              # Add new user
            2) delete_ssh_user ;;           # Delete a user
            3) enable_disable_ssh_user ;;   # Enable/disable a user
            4) change_ssh_password ;;       # Change user password
            5) break ;;                     # Return to main menu
            *) 
                echo_error "Invalid option. Please try again."
                sleep 1
                ;;
        esac
    done
}

# Function to list SSH users
list_ssh_users() {
    # This is a simplified version - the full version would read from /etc/passwd
    # and check user status
    echo -e "  ${GRAY}System users with SSH access will be listed here${NC}"
}

# Other functions like add_ssh_user, delete_ssh_user, etc.
# will be defined in the full module file
EOF
    chmod +x "$INSTALL_DIR/modules/ssh_ws_users.sh"
    echo -e "${GREEN}[SUCCESS]${NC} Created SSH WebSocket user management module"
fi
echo -e "${BLUE}[INFO]${NC} You can now use the following commands to run the VPS Manager:"
echo -e "  ${GREEN}sudo vps${NC}"
echo -e "  ${GREEN}sudo admin${NC}"
echo -e "  ${GREEN}sudo vpsshieldpro${NC}"

echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            ${GREEN}Ubuntu VPS Manager Fix Complete${NC}              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
