#!/bin/bash

# Fix for Ubuntu VPS Manager script in system-wide installation

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║               ${GREEN}Ubuntu VPS Manager Fix Tool${NC}               ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR]${NC} This script must be run as root. Please use sudo."
  exit 1
fi

# Find the installation directory
echo -e "${BLUE}[INFO]${NC} Looking for VPS Manager installation..."

if [ -L "/usr/local/bin/vps" ]; then
    INSTALL_DIR=$(readlink -f "/usr/local/bin/vps" | sed 's#/vps-manager\.sh$##')
    echo -e "${GREEN}[SUCCESS]${NC} Found installation at: $INSTALL_DIR"
else
    echo -e "${YELLOW}[WARNING]${NC} Could not find symbolic link at /usr/local/bin/vps"
    
    # Try to find installation in common directories
    for dir in "/opt/vpsshieldpro" "/usr/local/vpsshieldpro" "/opt/ubuntu-vps-manager"; do
        if [ -f "$dir/vps-manager.sh" ]; then
            INSTALL_DIR="$dir"
            echo -e "${GREEN}[SUCCESS]${NC} Found installation at: $INSTALL_DIR"
            break
        fi
    done
    
    # If still not found, ask user
    if [ -z "$INSTALL_DIR" ]; then
        echo -e "${YELLOW}[WARNING]${NC} Could not automatically find the installation directory."
        read -p "Please enter the full path to the VPS Manager installation directory: " INSTALL_DIR
        
        if [ ! -f "$INSTALL_DIR/vps-manager.sh" ]; then
            echo -e "${RED}[ERROR]${NC} Could not find vps-manager.sh in specified directory."
            exit 1
        fi
    fi
fi

# Check that we found the installation
if [ -z "$INSTALL_DIR" ]; then
    echo -e "${RED}[ERROR]${NC} Could not determine the installation directory."
    exit 1
fi

# Check if utils.sh exists
if [ ! -f "$INSTALL_DIR/modules/utils.sh" ]; then
    echo -e "${RED}[ERROR]${NC} Could not find utils.sh in $INSTALL_DIR/modules/"
    exit 1
fi

# Create a wrapper script for the system-wide commands
echo -e "${BLUE}[INFO]${NC} Creating wrapper scripts..."

WRAPPER_SCRIPT="#!/bin/bash

# Wrapper for vps-manager.sh that ensures proper environment
# Created by the fix-vps.sh script

# Find true script directory (for modules)
export SCRIPT_DIR=\"$INSTALL_DIR\"

# Execute the main script with proper sourcing
cd \"\$SCRIPT_DIR\" && ./vps-manager.sh \"\$@\"
"

# Create the wrapper scripts with proper permissions
echo -e "${WRAPPER_SCRIPT}" > "/usr/local/bin/vps_wrapper"
chmod +x "/usr/local/bin/vps_wrapper"

# Replace the symlinks with the wrapper
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/vps"
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/admin"
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/vpsshieldpro"

echo -e "${GREEN}[SUCCESS]${NC} Wrapper scripts created and installed."
echo -e "${BLUE}[INFO]${NC} You can now use the following commands to run the VPS Manager:"
echo -e "  ${GREEN}sudo vps${NC}"
echo -e "  ${GREEN}sudo admin${NC}"
echo -e "  ${GREEN}sudo vpsshieldpro${NC}"

echo -e "\n${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║            ${GREEN}Ubuntu VPS Manager Fix Complete${NC}              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
