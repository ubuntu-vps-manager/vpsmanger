# Ubuntu VPS Manager with Enhanced User Management

## Overview
This repository contains an enhanced version of the Ubuntu VPS Manager with support for multiple user management for V2Ray and SSH WebSocket services. The script provides a comprehensive suite of tools for managing various networking services on Ubuntu 22.04 VPS systems.

## Key Features
- Complete VPS management interface with 30+ options
- Enhanced V2Ray user management (add, delete, list, generate configs)
- SSH WebSocket user management (add, delete, enable/disable, change passwords)
- Various proxy configurations including Python proxy, SSE proxy, and UDP services
- BadVPN management for UDP tunneling
- Domain and SSL certificate management
- System backup and restoration

## Fixed Issues
- Resolved critical issue where the script wouldn't work when installed as a system command
- Fixed module sourcing problems that caused "command not found" errors
- Added full multi-user support for V2Ray and SSH WebSocket services
- Incorporated proper error handling and user feedback
- Standardized default ports: Python proxy (80), SSH WebSocket (443), V2Ray non-TLS (80), V2Ray TLS (443)
- Set BadVPN-udpgw default port to 7300
- Added universal user management that works across all SSH-based services
- Fixed confusion between UDP Custom and BadVPN-udpgw services
- Improved service descriptions for better clarity

## Installation

### New Installation
For a fresh installation, use:

```bash
sudo bash improved-install.sh
```

### Fix Existing Installation
If you have an existing installation that's not working properly, use the fix script:

```bash
sudo bash fix-vps.sh
```

## Usage
After installation, you can run the VPS Manager using any of these commands:

```bash
sudo vps
sudo admin
sudo vpsshieldpro
```

## User Management

### Universal User Management (Option 29)
- Create users that work across all SSH-based services
- Unified user management for SSH, SSH WebSocket, SSH UDP, and BadVPN services
- Manage system users with SSH access
- Enable/disable users, change passwords, delete users

### V2Ray User Management (Option 30)
- Add new users with unique UUIDs
- List all users with their connection details
- Delete existing users
- Generate configuration files for specific users

### SSH WebSocket User Management (Option 31)
- Add new SSH users with custom passwords
- Delete existing users
- Enable/disable users without completely removing them
- Change user passwords

## Development
If you want to contribute to this project, please follow these guidelines:

1. Make sure all module scripts have executable permissions (`chmod +x`)
2. All new modules should be placed in the `modules/` directory
3. Update the main script to source any new modules
4. Test your changes thoroughly in test mode (`--test` flag) before committing

## Distribution
You can distribute the fixed versions using the following package:

```bash
sudo tar -xzf vps-manager-fix.tar.gz -C /opt/destination/
```

## License
This project is licensed under the MIT License - see the LICENSE file for details.
