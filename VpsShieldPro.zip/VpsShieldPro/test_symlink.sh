#!/bin/bash

# Create test directories to simulate installation
mkdir -p test_install_dir
mkdir -p test_bin_dir

# Copy the main script
cp vps-manager.sh test_install_dir/
cp -r modules test_install_dir/

# Make it executable
chmod +x test_install_dir/vps-manager.sh

# Create symbolic links
ln -sf "$(pwd)/test_install_dir/vps-manager.sh" test_bin_dir/vps
ln -sf "$(pwd)/test_install_dir/vps-manager.sh" test_bin_dir/admin
ln -sf "$(pwd)/test_install_dir/vps-manager.sh" test_bin_dir/vpsshieldpro

# Display the created structure
echo "Test installation created:"
ls -la test_install_dir
ls -la test_bin_dir

echo ""
echo "Testing symlink execution..."
echo "This demonstrates that the symlinks would work correctly in a real environment"
echo "The --help flag ensures the script exits quickly after showing help"
echo ""

# Test with --help to exit quickly
test_bin_dir/vps --help