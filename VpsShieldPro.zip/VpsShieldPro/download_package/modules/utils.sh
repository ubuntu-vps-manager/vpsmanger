#!/bin/bash

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
PURPLE='\033[0;35m'
CYAN='\033[0;36m'
WHITE='\033[0;37m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color

# Ensure logs directory exists
mkdir -p "$SCRIPT_DIR/logs"

# Log file
LOG_FILE="$SCRIPT_DIR/logs/vps-manager.log"

# Echo with colors and logging
echo_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
    echo "[INFO] $1" >> "$LOG_FILE"
}

echo_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
    echo "[SUCCESS] $1" >> "$LOG_FILE"
}

echo_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
    echo "[WARNING] $1" >> "$LOG_FILE"
}

echo_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    echo "[ERROR] $1" >> "$LOG_FILE"
}

# Generate random port
generate_random_port() {
    local min=10000
    local max=65535
    echo $(( $min + $RANDOM % ($max - $min + 1) ))
}

# Generate random UUID
generate_uuid() {
    uuidgen
}

# Check if a command exists
command_exists() {
    command -v "$1" >/dev/null 2>&1
}

# Check if a port is available
is_port_available() {
    local port=$1
    ! lsof -i:"$port" -sTCP:LISTEN >/dev/null 2>&1
}

# Find an available port
find_available_port() {
    local port
    while true; do
        port=$(generate_random_port)
        if is_port_available "$port"; then
            echo "$port"
            return 0
        fi
    done
}

# Check if a service is installed
is_service_installed() {
    systemctl list-unit-files | grep -q "$1.service"
}

# Check if a service is active
is_service_active() {
    systemctl is-active --quiet "$1"
}

# Restart a service
restart_service() {
    echo_info "Restarting $1 service..."
    systemctl restart "$1"
    if [ $? -eq 0 ]; then
        echo_success "$1 service restarted"
    else
        echo_error "Failed to restart $1 service"
    fi
}

# Stop a service
stop_service() {
    echo_info "Stopping $1 service..."
    systemctl stop "$1"
    if [ $? -eq 0 ]; then
        echo_success "$1 service stopped"
    else
        echo_error "Failed to stop $1 service"
    fi
}

# Enable a service
enable_service() {
    echo_info "Enabling $1 service to start on boot..."
    systemctl enable "$1"
    if [ $? -eq 0 ]; then
        echo_success "$1 service enabled"
    else
        echo_error "Failed to enable $1 service"
    fi
}

# Check if IPv6 is enabled
is_ipv6_enabled() {
    if [ -f /proc/sys/net/ipv6/conf/all/disable_ipv6 ]; then
        if [ "$(cat /proc/sys/net/ipv6/conf/all/disable_ipv6)" -eq 0 ]; then
            return 0
        fi
    fi
    return 1
}

# Get public IP address
get_public_ip() {
    curl -s https://api.ipify.org || echo "Unable to get IP address"
}

# Check if domain resolves to server IP
check_domain_dns() {
    local domain=$1
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        # In test mode, always report successful DNS verification
        return 0
    fi
    
    local server_ip=$(get_public_ip)
    local domain_ip=$(dig +short "$domain" | tail -n1)
    
    if [ "$domain_ip" = "$server_ip" ]; then
        return 0
    else
        return 1
    fi
}

# Create a backup of a file
backup_file() {
    local file=$1
    if [ -f "$file" ]; then
        local backup_file="${file}.bak.$(date +%Y%m%d%H%M%S)"
        cp "$file" "$backup_file"
        echo_info "Backup of $file created: $backup_file"
    fi
}

# Configure firewall
configure_firewall() {
    echo_info "Configuring firewall..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating firewall configuration..."
        echo_info "Would open ports: 22/tcp, 80/tcp, 443/tcp"
        echo_info "Would open ports for installed services if any"
        sleep 1
        echo_success "Firewall simulated configuration complete"
        return
    fi
    
    # Check if ufw is installed
    if ! command_exists ufw; then
        echo_info "Installing ufw..."
        apt update -y
        apt install -y ufw
    fi
    
    # Reset UFW to default
    echo_info "Resetting UFW to default..."
    ufw --force reset
    
    # Set default policies
    ufw default deny incoming
    ufw default allow outgoing
    
    # Allow SSH
    echo_info "Allowing SSH port..."
    ufw allow 22/tcp
    
    # Allow HTTP/HTTPS
    echo_info "Allowing HTTP/HTTPS ports..."
    ufw allow 80/tcp
    ufw allow 443/tcp
    
    # Get list of configured services
    echo_info "Configuring ports for installed services..."
    
    # V2Ray
    if is_service_installed v2ray; then
        local v2ray_port=$(grep -o '"port": [0-9]*' /usr/local/etc/v2ray/config.json | grep -o '[0-9]*')
        if [ ! -z "$v2ray_port" ]; then
            echo_info "Adding V2Ray port $v2ray_port to firewall..."
            ufw allow "$v2ray_port"/tcp
        fi
    fi
    
    # SSH WebSocket
    if is_service_installed ssh_websocket; then
        local ssh_ws_port=$(grep -o 'PORT=[0-9]*' /etc/systemd/system/ssh_websocket.service | grep -o '[0-9]*')
        if [ ! -z "$ssh_ws_port" ]; then
            echo_info "Adding SSH WebSocket port $ssh_ws_port to firewall..."
            ufw allow "$ssh_ws_port"/tcp
        fi
    fi
    
    # Python proxy
    if is_service_installed python_proxy; then
        local python_proxy_port=$(grep -o 'PORT=[0-9]*' /etc/systemd/system/python_proxy.service | grep -o '[0-9]*')
        if [ ! -z "$python_proxy_port" ]; then
            echo_info "Adding Python proxy port $python_proxy_port to firewall..."
            ufw allow "$python_proxy_port"/tcp
        fi
    fi
    
    # SSE proxy
    if is_service_installed sse_proxy; then
        local sse_proxy_port=$(grep -o 'PORT=[0-9]*' /etc/systemd/system/sse_proxy.service | grep -o '[0-9]*')
        if [ ! -z "$sse_proxy_port" ]; then
            echo_info "Adding SSE proxy port $sse_proxy_port to firewall..."
            ufw allow "$sse_proxy_port"/tcp
        fi
    fi
    
    # Enable UFW
    echo_info "Enabling UFW..."
    ufw --force enable
    
    echo_success "Firewall configured and enabled"
    ufw status verbose
}

# Update this script
update_script() {
    echo_info "Checking for script updates..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating script update..."
        sleep 1
        echo_success "Script update simulated successfully!"
        return
    fi
    
    # Define the GitHub repository URL
    REPO_URL="https://github.com/kurogai/ubuntu-vps-manager"
    
    # Create a temporary directory
    TMP_DIR=$(mktemp -d)
    
    # Clone the repository
    if git clone "$REPO_URL" "$TMP_DIR"; then
        # Copy new files to the script directory
        cp -r "$TMP_DIR"/* "$SCRIPT_DIR"
        
        # Make the main script executable
        chmod +x "$SCRIPT_DIR/vps-manager.sh"
        
        # Clean up
        rm -rf "$TMP_DIR"
        
        echo_success "Script updated successfully!"
    else
        echo_error "Failed to update script. Please check your internet connection or the repository URL."
    fi
}

# Function to show script info
show_script_info() {
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                ${GREEN}Ubuntu VPS Manager v$VERSION${BLUE}                  ║${NC}"
    echo -e "${BLUE}║     A comprehensive VPS management tool for Ubuntu 22.04   ║${NC}"
    echo -e "${BLUE}║                                                            ║${NC}"
    echo -e "${BLUE}║  Features:                                                 ║${NC}"
    echo -e "${BLUE}║  • V2Ray WebSocket (TLS & non-TLS)                         ║${NC}"
    echo -e "${BLUE}║  • SSH WebSocket Tunneling                                 ║${NC}"
    echo -e "${BLUE}║  • Python Proxy (101 Protocol)                             ║${NC}"
    echo -e "${BLUE}║  • SSE (Server-Sent Events) Proxy                          ║${NC}"
    echo -e "${BLUE}║  • Domain Management                                       ║${NC}"
    echo -e "${BLUE}║  • SSL Certificate Management                              ║${NC}"
    echo -e "${BLUE}║  • System Monitoring                                       ║${NC}"
    echo -e "${BLUE}║  • Backup & Restore                                        ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
}
