#!/bin/bash

# Install SSE (Server-Sent Events) Proxy
install_sse_proxy() {
    echo_info "Installing SSE (Server-Sent Events) Proxy..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSE Proxy installation..."
        local port=$(generate_random_port)
        echo_info "Generated configuration:"
        echo_info "SSE Proxy Port: $port"
        
        sleep 2
        echo_success "SSE Proxy simulated installation complete"
        return
    fi
    
    # Check if SSE Proxy is already installed
    if is_service_installed sse_proxy; then
        echo_warning "SSE Proxy is already installed"
        echo_info "Do you want to reinstall it? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
        
        # Stop and disable SSE Proxy service
        stop_service sse_proxy
        systemctl disable sse_proxy
    fi
    
    # Install required packages
    echo_info "Installing required packages..."
    apt update -y
    apt install -y python3 python3-pip
    
    # Install required Python packages
    pip3 install aiohttp
    
    # Generate random port for SSE Proxy
    local sse_port=$(find_available_port)
    
    # Create the SSE Proxy script directory
    mkdir -p /usr/local/bin
    
    # Create the SSE Proxy script
    echo_info "Creating SSE Proxy script..."
    cat > /usr/local/bin/sse_proxy.py << 'EOF'
#!/usr/bin/env python3

import asyncio
import aiohttp
from aiohttp import web
import logging
import argparse
import sys
import signal
import json
import uuid
import ssl
import time
import socket
from urllib.parse import urlparse

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('sse-proxy')

# Global variables
clients = {}
running = True

# Class to handle SSE connections
class SSEHandler:
    def __init__(self, app):
        self.app = app
        self.clients = {}
        
    async def handle_sse_client(self, request):
        """Handle incoming SSE client connections"""
        client_id = str(uuid.uuid4())
        response = web.Response(
            content_type='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'Access-Control-Allow-Origin': '*',
            }
        )
        
        # Create response and get a channel for sending data
        response.enable_chunked_encoding()
        writer = response.write
        
        # Store client information
        self.clients[client_id] = {
            'writer': writer,
            'created_at': time.time(),
            'last_active': time.time()
        }
        
        logger.info(f"New SSE client connected: {client_id}")
        
        # Send initial connection message
        await writer(f"id: {client_id}\ndata: connected\n\n".encode('utf-8'))
        
        try:
            # Keep the connection alive by sending a comment every 30 seconds
            while running:
                await asyncio.sleep(30)
                self.clients[client_id]['last_active'] = time.time()
                await writer(f": keepalive {time.time()}\n\n".encode('utf-8'))
        except Exception as e:
            logger.error(f"Error in SSE connection: {e}")
        finally:
            # Remove client on disconnect
            if client_id in self.clients:
                del self.clients[client_id]
            logger.info(f"SSE client disconnected: {client_id}")
        
        return response
    
    async def handle_sse_publish(self, request):
        """Handle requests to publish events to SSE clients"""
        try:
            data = await request.json()
            
            event_type = data.get('event', 'message')
            event_data = data.get('data', '')
            event_id = data.get('id', str(uuid.uuid4()))
            target_clients = data.get('clients', [])
            
            # Validate input
            if not event_data:
                return web.json_response({'error': 'No data provided'}, status=400)
            
            # Format the event
            event_text = f"id: {event_id}\nevent: {event_type}\ndata: {json.dumps(event_data)}\n\n"
            event_bytes = event_text.encode('utf-8')
            
            # Send to specific clients or all clients
            sent_count = 0
            for client_id, client in list(self.clients.items()):
                if not target_clients or client_id in target_clients:
                    try:
                        await client['writer'](event_bytes)
                        client['last_active'] = time.time()
                        sent_count += 1
                    except Exception as e:
                        logger.error(f"Error sending to client {client_id}: {e}")
                        # Remove dead client
                        del self.clients[client_id]
            
            return web.json_response({
                'success': True,
                'sent_to': sent_count,
                'total_clients': len(self.clients)
            })
            
        except Exception as e:
            logger.error(f"Error processing publish request: {e}")
            return web.json_response({'error': str(e)}, status=500)
    
    async def handle_sse_proxy(self, request):
        """Proxy SSE connections to another SSE server"""
        try:
            target_url = request.query.get('target')
            if not target_url:
                return web.Response(text="Missing target parameter", status=400)
            
            # Validate URL
            parsed_url = urlparse(target_url)
            if not parsed_url.scheme or not parsed_url.netloc:
                return web.Response(text="Invalid target URL", status=400)
            
            # Set up SSE response
            response = web.Response(
                content_type='text/event-stream',
                headers={
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'Access-Control-Allow-Origin': '*',
                }
            )
            response.enable_chunked_encoding()
            writer = response.write
            
            # Create a unique ID for this proxy connection
            proxy_id = str(uuid.uuid4())
            
            # Forward headers from the client to the target
            headers = {
                k: v for k, v in request.headers.items()
                if k.lower() not in ('host', 'connection')
            }
            
            # Connect to the target SSE server
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get(target_url, headers=headers) as resp:
                        if resp.status != 200:
                            return web.Response(
                                text=f"Target server returned status {resp.status}",
                                status=502
                            )
                        
                        # Ensure it's an SSE endpoint
                        content_type = resp.headers.get('Content-Type', '')
                        if 'text/event-stream' not in content_type.lower():
                            return web.Response(
                                text=f"Target is not an SSE endpoint (got {content_type})",
                                status=502
                            )
                        
                        logger.info(f"Proxying SSE connection to {target_url} ({proxy_id})")
                        
                        # Stream data from target to client
                        async for line in resp.content:
                            if not running:
                                break
                            await writer(line)
                
                except asyncio.CancelledError:
                    logger.info(f"SSE proxy connection cancelled: {proxy_id}")
                except Exception as e:
                    logger.error(f"Error proxying SSE: {e}")
                    await writer(f"event: error\ndata: {json.dumps({'error': str(e)})}\n\n".encode('utf-8'))
            
            return response
            
        except Exception as e:
            logger.error(f"Error in SSE proxy handler: {e}")
            return web.Response(text=f"Error: {str(e)}", status=500)
    
    async def handle_sse_info(self, request):
        """Return information about connected clients"""
        client_info = []
        for client_id, client in self.clients.items():
            client_info.append({
                'id': client_id,
                'connected_since': client['created_at'],
                'last_active': client['last_active'],
                'age_seconds': time.time() - client['created_at']
            })
        
        return web.json_response({
            'client_count': len(self.clients),
            'clients': client_info
        })
    
    async def cleanup_stale_clients(self):
        """Cleanup stale client connections"""
        while running:
            try:
                # Check every 60 seconds
                await asyncio.sleep(60)
                
                now = time.time()
                stale_threshold = 300  # 5 minutes without activity
                
                for client_id, client in list(self.clients.items()):
                    if now - client['last_active'] > stale_threshold:
                        logger.info(f"Removing stale client: {client_id}")
                        try:
                            # Send a close message
                            await client['writer'](f"event: close\ndata: Connection timed out\n\n".encode('utf-8'))
                        except:
                            pass
                        
                        # Remove from clients list
                        if client_id in self.clients:
                            del self.clients[client_id]
                
            except Exception as e:
                logger.error(f"Error in cleanup task: {e}")

def signal_handler(sig, frame):
    """Handle SIGINT and SIGTERM signals"""
    global running
    logger.info("Shutting down...")
    running = False

async def start_server(host, port):
    """Start the SSE proxy server"""
    app = web.Application()
    
    # Create SSE handler
    sse_handler = SSEHandler(app)
    
    # Set up routes
    app.router.add_get('/sse', sse_handler.handle_sse_client)
    app.router.add_post('/publish', sse_handler.handle_sse_publish)
    app.router.add_get('/proxy', sse_handler.handle_sse_proxy)
    app.router.add_get('/info', sse_handler.handle_sse_info)
    
    # Start cleanup task
    cleanup_task = asyncio.create_task(sse_handler.cleanup_stale_clients())
    
    # Start the server
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    await site.start()
    
    logger.info(f"SSE Proxy server started on {host}:{port}")
    
    try:
        # Keep the server running until stopped
        while running:
            await asyncio.sleep(1)
    finally:
        cleanup_task.cancel()
        await runner.cleanup()
        logger.info("Server shut down")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='SSE (Server-Sent Events) Proxy')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, required=True, help='Port to bind')
    
    args = parser.parse_args()
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Start the server
    asyncio.run(start_server(args.host, args.port))

if __name__ == "__main__":
    main()
EOF

    # Make script executable
    chmod +x /usr/local/bin/sse_proxy.py
    
    # Create systemd service for SSE Proxy
    echo_info "Creating systemd service for SSE Proxy..."
    
    cat > /etc/systemd/system/sse_proxy.service << EOF
[Unit]
Description=SSE (Server-Sent Events) Proxy Service
After=network.target

[Service]
Type=simple
User=root
Environment=PORT=$sse_port
ExecStart=/usr/bin/python3 /usr/local/bin/sse_proxy.py --port \${PORT}
Restart=on-failure
RestartSec=5s

[Install]
WantedBy=multi-user.target
EOF

    # Reload systemd daemon
    systemctl daemon-reload
    
    # Start and enable SSE Proxy service
    systemctl start sse_proxy
    systemctl enable sse_proxy
    
    # Verify that SSE Proxy is running
    if ! is_service_active sse_proxy; then
        echo_error "SSE Proxy failed to start. Please check the logs with 'journalctl -u sse_proxy'"
        return
    fi
    
    # Configure firewall
    configure_firewall
    
    # Generate client configuration information
    local server_ip=$(get_public_ip)
    echo_success "SSE Proxy has been installed successfully!"
    echo_info "You can use the following URLs for SSE operations:"
    echo -e "${GREEN}------------------------------------------------${NC}"
    echo -e "${CYAN}SSE Client URL:${NC} http://$server_ip:$sse_port/sse"
    echo -e "${CYAN}SSE Publish URL:${NC} http://$server_ip:$sse_port/publish"
    echo -e "${CYAN}SSE Proxy URL:${NC} http://$server_ip:$sse_port/proxy?target=<target-sse-url>"
    echo -e "${CYAN}SSE Info URL:${NC} http://$server_ip:$sse_port/info"
    echo -e "${GREEN}------------------------------------------------${NC}"
    
    # Save configuration to file
    local config_info="SSE Client URL: http://$server_ip:$sse_port/sse\nSSE Publish URL: http://$server_ip:$sse_port/publish\nSSE Proxy URL: http://$server_ip:$sse_port/proxy?target=<target-sse-url>\nSSE Info URL: http://$server_ip:$sse_port/info"
    echo -e "$config_info" > "$SCRIPT_DIR/sse_proxy_config.txt"
    echo_info "Configuration saved to $SCRIPT_DIR/sse_proxy_config.txt"
    
    # Provide client usage information
    echo_info "To test the SSE server, you can use curl:"
    echo_info "curl -N http://$server_ip:$sse_port/sse"
    echo_info "To publish an event:"
    echo_info "curl -X POST -H \"Content-Type: application/json\" -d '{\"event\":\"test\",\"data\":\"Hello World\"}' http://$server_ip:$sse_port/publish"
}

# Show SSE Proxy configuration
show_sse_proxy_config() {
    echo_info "SSE Proxy Configuration"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSE Proxy configuration display..."
        local port=$(generate_random_port)
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║                ${GREEN}SSE Proxy Configuration${BLUE}                     ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Service Status:${NC}"
        echo -e "  ${WHITE}Status:${NC}      ${YELLOW}[SIMULATED] Active${NC}"
        
        echo -e "\n${YELLOW}🔹 Endpoints:${NC}"
        echo -e "  ${WHITE}SSE Client URL:${NC}   ${CYAN}http://198.51.100.1:$port/sse${NC}"
        echo -e "  ${WHITE}SSE Publish URL:${NC}  ${CYAN}http://198.51.100.1:$port/publish${NC}"
        echo -e "  ${WHITE}SSE Proxy URL:${NC}    ${CYAN}http://198.51.100.1:$port/proxy?target=<target-sse-url>${NC}"
        echo -e "  ${WHITE}SSE Info URL:${NC}     ${CYAN}http://198.51.100.1:$port/info${NC}"
        
        echo -e "\n${YELLOW}🔹 Port Management (Simulated):${NC}"
        echo -e "  ${WHITE}1)${NC} Change SSE Proxy port (current: $port)"
        echo -e "  ${WHITE}2)${NC} Continue without changes"
        
        echo -e "\n${YELLOW}🔹 Example Usage:${NC}"
        echo -e "  ${GRAY}• Connect to SSE events:${NC}"
        echo -e "    ${WHITE}curl -N http://198.51.100.1:$port/sse${NC}"
        echo -e "  ${GRAY}• Publish an event:${NC}"
        echo -e "    ${WHITE}curl -X POST -H \"Content-Type: application/json\" \\${NC}"
        echo -e "    ${WHITE}-d '{\"event\":\"test\",\"data\":\"Hello World\"}' \\${NC}"
        echo -e "    ${WHITE}http://198.51.100.1:$port/publish${NC}"
        
        return
    fi
    
    # Check if SSE Proxy is installed
    if ! is_service_installed sse_proxy; then
        echo_error "SSE Proxy is not installed"
        echo_info "You can install it using option 13 from the main menu"
        return
    fi
    
    # Get service status and configuration
    local status=$(systemctl is-active sse_proxy)
    local sse_port=$(grep -o 'PORT=[0-9]*' /etc/systemd/system/sse_proxy.service | cut -d= -f2)
    local server_ip=$(get_public_ip)
    
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                ${GREEN}SSE Proxy Configuration${BLUE}                     ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    echo -e "\n${YELLOW}🔹 Service Status:${NC}"
    if [[ "$status" == "active" ]]; then
        echo -e "  ${WHITE}Status:${NC}      ${GREEN}Active${NC}"
    else
        echo -e "  ${WHITE}Status:${NC}      ${RED}Inactive${NC} (run 'systemctl start sse_proxy' to start)"
    fi
    
    echo -e "\n${YELLOW}🔹 Endpoints:${NC}"
    echo -e "  ${WHITE}SSE Client URL:${NC}   ${CYAN}http://$server_ip:$sse_port/sse${NC}"
    echo -e "  ${WHITE}SSE Publish URL:${NC}  ${CYAN}http://$server_ip:$sse_port/publish${NC}"
    echo -e "  ${WHITE}SSE Proxy URL:${NC}    ${CYAN}http://$server_ip:$sse_port/proxy?target=<target-sse-url>${NC}"
    echo -e "  ${WHITE}SSE Info URL:${NC}     ${CYAN}http://$server_ip:$sse_port/info${NC}"
    
    echo -e "\n${YELLOW}🔹 Port Management:${NC}"
    echo -e "  ${WHITE}1)${NC} Change SSE Proxy port (current: $sse_port)"
    echo -e "  ${WHITE}2)${NC} Continue without changes"
    echo -ne "${CYAN}Enter your choice [1-2]: ${NC}"
    read -r choice
    
    case $choice in
        1)  echo -ne "Enter new port (leave empty for random): "
            read -r new_port
            
            if [[ -z "$new_port" ]]; then
                new_port=$(find_available_port)
            elif ! [[ "$new_port" =~ ^[0-9]+$ ]] || [ "$new_port" -lt 1024 ] || [ "$new_port" -gt 65535 ]; then
                echo_error "Invalid port number. Using random port instead."
                new_port=$(find_available_port)
            elif ! is_port_available "$new_port"; then
                echo_error "Port $new_port is already in use. Using random port instead."
                new_port=$(find_available_port)
            fi
            
            echo_info "Updating SSE Proxy port to $new_port..."
            sed -i "s/PORT=[0-9]*/PORT=$new_port/" /etc/systemd/system/sse_proxy.service
            systemctl daemon-reload
            restart_service sse_proxy
            echo_success "SSE Proxy port updated to $new_port"
            
            # Update the port for display
            sse_port=$new_port
            
            # Update the configuration information
            echo -e "\n${YELLOW}🔹 Updated Endpoints:${NC}"
            echo -e "  ${WHITE}SSE Client URL:${NC}   ${CYAN}http://$server_ip:$sse_port/sse${NC}"
            echo -e "  ${WHITE}SSE Publish URL:${NC}  ${CYAN}http://$server_ip:$sse_port/publish${NC}"
            echo -e "  ${WHITE}SSE Proxy URL:${NC}    ${CYAN}http://$server_ip:$sse_port/proxy?target=<target-sse-url>${NC}"
            echo -e "  ${WHITE}SSE Info URL:${NC}     ${CYAN}http://$server_ip:$sse_port/info${NC}"
            
            # Save updated configuration
            local config_info="SSE Client URL: http://$server_ip:$sse_port/sse\nSSE Publish URL: http://$server_ip:$sse_port/publish\nSSE Proxy URL: http://$server_ip:$sse_port/proxy?target=<target-sse-url>\nSSE Info URL: http://$server_ip:$sse_port/info"
            echo -e "$config_info" > "$SCRIPT_DIR/sse_proxy_config.txt"
            ;;
        2)  echo_info "No changes made to port configuration"
            ;;
        *)  echo_error "Invalid option. No changes made."
            ;;
    esac
    
    echo -e "\n${YELLOW}🔹 Management Commands:${NC}"
    echo -e "  ${GRAY}• Start:${NC}   ${WHITE}systemctl start sse_proxy${NC}"
    echo -e "  ${GRAY}• Stop:${NC}    ${WHITE}systemctl stop sse_proxy${NC}"
    echo -e "  ${GRAY}• Restart:${NC} ${WHITE}systemctl restart sse_proxy${NC}"
    echo -e "  ${GRAY}• Status:${NC}  ${WHITE}systemctl status sse_proxy${NC}"
    
    echo -e "\n${YELLOW}🔹 Example Usage:${NC}"
    echo -e "  ${GRAY}• Connect to SSE events:${NC}"
    echo -e "    ${WHITE}curl -N http://$server_ip:$sse_port/sse${NC}"
    echo -e "  ${GRAY}• Publish an event:${NC}"
    echo -e "    ${WHITE}curl -X POST -H \"Content-Type: application/json\" \\${NC}"
    echo -e "    ${WHITE}-d '{\"event\":\"test\",\"data\":\"Hello World\"}' \\${NC}"
    echo -e "    ${WHITE}http://$server_ip:$sse_port/publish${NC}"
    
    # Port checker
    if [[ "$status" == "active" ]]; then
        echo -e "\n${YELLOW}🔹 Connectivity Check:${NC}"
        if lsof -i:"$sse_port" -sTCP:LISTEN >/dev/null 2>&1; then
            echo -e "  ${WHITE}Port status:${NC} ${GREEN}LISTENING${NC} on port $sse_port"
        else
            echo -e "  ${WHITE}Port status:${NC} ${RED}NOT LISTENING${NC} (Service is active but port $sse_port is not open)"
        fi
    fi
    
    # Show saved configuration if it exists
    if [ -f "$SCRIPT_DIR/sse_proxy_config.txt" ]; then
        echo -e "\n${YELLOW}🔹 Saved Configuration File:${NC}"
        echo -e "  ${GRAY}Configuration saved to:${NC} ${WHITE}$SCRIPT_DIR/sse_proxy_config.txt${NC}"
    fi
}

# Uninstall SSE Proxy
uninstall_sse_proxy() {
    echo_info "Uninstalling SSE Proxy..."
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSE Proxy uninstallation..."
        
        # Confirm uninstallation (simulate user interaction)
        echo_warning "This will completely remove SSE Proxy from your system"
        echo_info "Do you want to continue? (y/n)"
        read -r choice
        if [[ ! $choice =~ ^[Yy]$ ]]; then
            return
        fi
        
        sleep 2
        echo_success "SSE Proxy has been uninstalled successfully (simulated)"
        return
    fi
    
    # Check if SSE Proxy is installed
    if ! is_service_installed sse_proxy; then
        echo_error "SSE Proxy is not installed"
        return
    fi
    
    # Confirm uninstallation
    echo_warning "This will completely remove SSE Proxy from your system"
    echo_info "Do you want to continue? (y/n)"
    read -r choice
    if [[ ! $choice =~ ^[Yy]$ ]]; then
        return
    fi
    
    # Stop and disable SSE Proxy service
    stop_service sse_proxy
    systemctl disable sse_proxy
    
    # Remove service file
    rm -f /etc/systemd/system/sse_proxy.service
    
    # Remove SSE Proxy script
    rm -f /usr/local/bin/sse_proxy.py
    
    # Remove configuration file
    rm -f "$SCRIPT_DIR/sse_proxy_config.txt"
    
    # Reload systemd daemon
    systemctl daemon-reload
    
    echo_success "SSE Proxy has been uninstalled successfully"
}
