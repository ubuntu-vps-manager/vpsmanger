#!/bin/bash

# Backup configurations
backup_configs() {
    echo_info "Backing up configurations..."
    
    # Create backup directory if it doesn't exist
    local backup_dir="$SCRIPT_DIR/backup"
    mkdir -p "$backup_dir"
    
    # Create timestamp for backup file
    local timestamp=$(date +"%Y%m%d_%H%M%S")
    local backup_file="$backup_dir/backup_$timestamp.tar.gz"
    
    # Create temporary directory
    local temp_dir=$(mktemp -d)
    
    # Backup V2Ray configuration
    if is_service_installed v2ray; then
        echo_info "Backing up V2Ray configuration..."
        mkdir -p "$temp_dir/v2ray"
        if [ -f "/usr/local/etc/v2ray/config.json" ]; then
            cp "/usr/local/etc/v2ray/config.json" "$temp_dir/v2ray/"
        fi
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            cp "$SCRIPT_DIR/v2ray_tls_config.txt" "$temp_dir/v2ray/"
        fi
        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            cp "$SCRIPT_DIR/v2ray_nontls_config.txt" "$temp_dir/v2ray/"
        fi
    fi
    
    # Backup SSH WebSocket configuration
    if is_service_installed ssh_websocket; then
        echo_info "Backing up SSH WebSocket configuration..."
        mkdir -p "$temp_dir/ssh_ws"
        if [ -f "/usr/local/bin/ssh_websocket.py" ]; then
            cp "/usr/local/bin/ssh_websocket.py" "$temp_dir/ssh_ws/"
        fi
        if [ -f "/etc/systemd/system/ssh_websocket.service" ]; then
            cp "/etc/systemd/system/ssh_websocket.service" "$temp_dir/ssh_ws/"
        fi
        if [ -f "$SCRIPT_DIR/ssh_ws_config.txt" ]; then
            cp "$SCRIPT_DIR/ssh_ws_config.txt" "$temp_dir/ssh_ws/"
        fi
    fi
    
    # Backup Python Proxy configuration
    if is_service_installed python_proxy; then
        echo_info "Backing up Python Proxy configuration..."
        mkdir -p "$temp_dir/python_proxy"
        if [ -f "/usr/local/bin/python_proxy.py" ]; then
            cp "/usr/local/bin/python_proxy.py" "$temp_dir/python_proxy/"
        fi
        if [ -f "/etc/systemd/system/python_proxy.service" ]; then
            cp "/etc/systemd/system/python_proxy.service" "$temp_dir/python_proxy/"
        fi
        if [ -f "$SCRIPT_DIR/python_proxy_config.txt" ]; then
            cp "$SCRIPT_DIR/python_proxy_config.txt" "$temp_dir/python_proxy/"
        fi
    fi
    
    # Backup SSE Proxy configuration
    if is_service_installed sse_proxy; then
        echo_info "Backing up SSE Proxy configuration..."
        mkdir -p "$temp_dir/sse_proxy"
        if [ -f "/usr/local/bin/sse_proxy.py" ]; then
            cp "/usr/local/bin/sse_proxy.py" "$temp_dir/sse_proxy/"
        fi
        if [ -f "/etc/systemd/system/sse_proxy.service" ]; then
            cp "/etc/systemd/system/sse_proxy.service" "$temp_dir/sse_proxy/"
        fi
        if [ -f "$SCRIPT_DIR/sse_proxy_config.txt" ]; then
            cp "$SCRIPT_DIR/sse_proxy_config.txt" "$temp_dir/sse_proxy/"
        fi
    fi
    
    # Backup domain configuration
    if [ -f "$SCRIPT_DIR/.domain" ]; then
        echo_info "Backing up domain configuration..."
        cp "$SCRIPT_DIR/.domain" "$temp_dir/"
    fi
    
    # Backup Nginx configuration if it's installed
    if is_service_installed nginx; then
        echo_info "Backing up Nginx configuration..."
        mkdir -p "$temp_dir/nginx"
        cp -r /etc/nginx/sites-available/ "$temp_dir/nginx/"
        cp -r /etc/nginx/sites-enabled/ "$temp_dir/nginx/"
    fi
    
    # Create backup archive
    echo_info "Creating backup archive..."
    tar -czf "$backup_file" -C "$temp_dir" .
    
    # Clean up
    rm -rf "$temp_dir"
    
    echo_success "Backup created: $backup_file"
    
    # List available backups
    echo_info "Available backups:"
    ls -la "$backup_dir"
}

# Restore configurations
restore_configs() {
    echo_info "Restoring configurations..."
    
    # Check if backup directory exists
    local backup_dir="$SCRIPT_DIR/backup"
    if [ ! -d "$backup_dir" ]; then
        echo_error "Backup directory does not exist"
        return
    fi
    
    # List available backups
    echo_info "Available backups:"
    local backups=($(ls -1 "$backup_dir" | grep -E "^backup_[0-9]+_[0-9]+\.tar\.gz$"))
    
    if [ ${#backups[@]} -eq 0 ]; then
        echo_error "No backups found"
        return
    fi
    
    # Display backups with numbers
    local i=1
    for backup in "${backups[@]}"; do
        local backup_date=$(echo "$backup" | sed -E 's/backup_([0-9]{8})_([0-9]{6})\.tar\.gz/\1 \2/' | sed -E 's/([0-9]{4})([0-9]{2})([0-9]{2}) ([0-9]{2})([0-9]{2})([0-9]{2})/\1-\2-\3 \4:\5:\6/')
        echo -e "  ${WHITE}$i)${NC} $backup ($backup_date)"
        ((i++))
    done
    
    # Prompt for selection
    echo -ne "${CYAN}Enter backup number to restore [1-${#backups[@]}] or 0 to cancel: ${NC}"
    read -r choice
    
    # Validate choice
    if [[ "$choice" =~ ^[0-9]+$ ]]; then
        if [ "$choice" -eq 0 ]; then
            echo_info "Restoration cancelled"
            return
        elif [ "$choice" -ge 1 ] && [ "$choice" -le ${#backups[@]} ]; then
            local selected_backup="${backups[$((choice-1))]}"
            local backup_file="$backup_dir/$selected_backup"
            
            # Confirm restoration
            echo_warning "This will overwrite your current configurations with the backup"
            echo_info "Do you want to continue? (y/n)"
            read -r confirm
            if [[ ! $confirm =~ ^[Yy]$ ]]; then
                echo_info "Restoration cancelled"
                return
            fi
            
            # Create temporary directory
            local temp_dir=$(mktemp -d)
            
            # Extract backup
            echo_info "Extracting backup..."
            tar -xzf "$backup_file" -C "$temp_dir"
            
            # Restore V2Ray configuration
            if [ -d "$temp_dir/v2ray" ]; then
                echo_info "Restoring V2Ray configuration..."
                if [ -f "$temp_dir/v2ray/config.json" ]; then
                    # Ensure directory exists
                    mkdir -p /usr/local/etc/v2ray/
                    cp "$temp_dir/v2ray/config.json" "/usr/local/etc/v2ray/"
                fi
                if [ -f "$temp_dir/v2ray/v2ray_tls_config.txt" ]; then
                    cp "$temp_dir/v2ray/v2ray_tls_config.txt" "$SCRIPT_DIR/"
                fi
                if [ -f "$temp_dir/v2ray/v2ray_nontls_config.txt" ]; then
                    cp "$temp_dir/v2ray/v2ray_nontls_config.txt" "$SCRIPT_DIR/"
                fi
                
                # Restart V2Ray if it's installed
                if is_service_installed v2ray; then
                    restart_service v2ray
                fi
            fi
            
            # Restore SSH WebSocket configuration
            if [ -d "$temp_dir/ssh_ws" ]; then
                echo_info "Restoring SSH WebSocket configuration..."
                if [ -f "$temp_dir/ssh_ws/ssh_websocket.py" ]; then
                    # Ensure directory exists
                    mkdir -p /usr/local/bin/
                    cp "$temp_dir/ssh_ws/ssh_websocket.py" "/usr/local/bin/"
                    chmod +x "/usr/local/bin/ssh_websocket.py"
                fi
                if [ -f "$temp_dir/ssh_ws/ssh_websocket.service" ]; then
                    cp "$temp_dir/ssh_ws/ssh_websocket.service" "/etc/systemd/system/"
                    systemctl daemon-reload
                fi
                if [ -f "$temp_dir/ssh_ws/ssh_ws_config.txt" ]; then
                    cp "$temp_dir/ssh_ws/ssh_ws_config.txt" "$SCRIPT_DIR/"
                fi
                
                # Restart SSH WebSocket if it's installed
                if is_service_installed ssh_websocket; then
                    restart_service ssh_websocket
                fi
            fi
            
            # Restore Python Proxy configuration
            if [ -d "$temp_dir/python_proxy" ]; then
                echo_info "Restoring Python Proxy configuration..."
                if [ -f "$temp_dir/python_proxy/python_proxy.py" ]; then
                    # Ensure directory exists
                    mkdir -p /usr/local/bin/
                    cp "$temp_dir/python_proxy/python_proxy.py" "/usr/local/bin/"
                    chmod +x "/usr/local/bin/python_proxy.py"
                fi
                if [ -f "$temp_dir/python_proxy/python_proxy.service" ]; then
                    cp "$temp_dir/python_proxy/python_proxy.service" "/etc/systemd/system/"
                    systemctl daemon-reload
                fi
                if [ -f "$temp_dir/python_proxy/python_proxy_config.txt" ]; then
                    cp "$temp_dir/python_proxy/python_proxy_config.txt" "$SCRIPT_DIR/"
                fi
                
                # Restart Python Proxy if it's installed
                if is_service_installed python_proxy; then
                    restart_service python_proxy
                fi
            fi
            
            # Restore SSE Proxy configuration
            if [ -d "$temp_dir/sse_proxy" ]; then
                echo_info "Restoring SSE Proxy configuration..."
                if [ -f "$temp_dir/sse_proxy/sse_proxy.py" ]; then
                    # Ensure directory exists
                    mkdir -p /usr/local/bin/
                    cp "$temp_dir/sse_proxy/sse_proxy.py" "/usr/local/bin/"
                    chmod +x "/usr/local/bin/sse_proxy.py"
                fi
                if [ -f "$temp_dir/sse_proxy/sse_proxy.service" ]; then
                    cp "$temp_dir/sse_proxy/sse_proxy.service" "/etc/systemd/system/"
                    systemctl daemon-reload
                fi
                if [ -f "$temp_dir/sse_proxy/sse_proxy_config.txt" ]; then
                    cp "$temp_dir/sse_proxy/sse_proxy_config.txt" "$SCRIPT_DIR/"
                fi
                
                # Restart SSE Proxy if it's installed
                if is_service_installed sse_proxy; then
                    restart_service sse_proxy
                fi
            fi
            
            # Restore domain configuration
            if [ -f "$temp_dir/.domain" ]; then
                echo_info "Restoring domain configuration..."
                cp "$temp_dir/.domain" "$SCRIPT_DIR/"
                DOMAIN=$(cat "$SCRIPT_DIR/.domain")
            fi
            
            # Restore Nginx configuration
            if [ -d "$temp_dir/nginx" ]; then
                echo_info "Restoring Nginx configuration..."
                if [ -d "$temp_dir/nginx/sites-available" ]; then
                    cp -r "$temp_dir/nginx/sites-available/"* /etc/nginx/sites-available/
                fi
                if [ -d "$temp_dir/nginx/sites-enabled" ]; then
                    # Remove existing symlinks
                    rm -f /etc/nginx/sites-enabled/*
                    # Create new symlinks
                    for site in "$temp_dir/nginx/sites-enabled"/*; do
                        if [ -f "$site" ]; then
                            local site_name=$(basename "$site")
                            ln -sf "/etc/nginx/sites-available/$site_name" "/etc/nginx/sites-enabled/$site_name"
                        fi
                    done
                fi
                
                # Restart Nginx if it's installed
                if is_service_installed nginx; then
                    nginx -t && restart_service nginx
                fi
            fi
            
            # Clean up
            rm -rf "$temp_dir"
            
            echo_success "Configuration restored from $selected_backup"
        else
            echo_error "Invalid selection"
        fi
    else
        echo_error "Invalid selection"
    fi
}
