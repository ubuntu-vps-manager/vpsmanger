#!/usr/bin/env python3

import asyncio
import aiohttp
from aiohttp import web
import logging
import argparse
import sys
import signal
import json
import uuid
import ssl
import time
import socket
from urllib.parse import urlparse

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('sse-proxy')

# Global variables
clients = {}
running = True

# Class to handle SSE connections
class SSEHandler:
    def __init__(self, app):
        self.app = app
        self.clients = {}
        
    async def handle_sse_client(self, request):
        """Handle incoming SSE client connections"""
        client_id = str(uuid.uuid4())
        response = web.Response(
            content_type='text/event-stream',
            headers={
                'Cache-Control': 'no-cache',
                'Connection': 'keep-alive',
                'Access-Control-Allow-Origin': '*',
            }
        )
        
        # Create response and get a channel for sending data
        response.enable_chunked_encoding()
        writer = response.write
        
        # Store client information
        self.clients[client_id] = {
            'writer': writer,
            'created_at': time.time(),
            'last_active': time.time()
        }
        
        logger.info(f"New SSE client connected: {client_id}")
        
        # Send initial connection message
        await writer(f"id: {client_id}\ndata: connected\n\n".encode('utf-8'))
        
        try:
            # Keep the connection alive by sending a comment every 30 seconds
            while running:
                await asyncio.sleep(30)
                self.clients[client_id]['last_active'] = time.time()
                await writer(f": keepalive {time.time()}\n\n".encode('utf-8'))
        except Exception as e:
            logger.error(f"Error in SSE connection: {e}")
        finally:
            # Remove client on disconnect
            if client_id in self.clients:
                del self.clients[client_id]
            logger.info(f"SSE client disconnected: {client_id}")
        
        return response
    
    async def handle_sse_publish(self, request):
        """Handle requests to publish events to SSE clients"""
        try:
            data = await request.json()
            
            event_type = data.get('event', 'message')
            event_data = data.get('data', '')
            event_id = data.get('id', str(uuid.uuid4()))
            target_clients = data.get('clients', [])
            
            # Validate input
            if not event_data:
                return web.json_response({'error': 'No data provided'}, status=400)
            
            # Format the event
            event_text = f"id: {event_id}\nevent: {event_type}\ndata: {json.dumps(event_data)}\n\n"
            event_bytes = event_text.encode('utf-8')
            
            # Send to specific clients or all clients
            sent_count = 0
            for client_id, client in list(self.clients.items()):
                if not target_clients or client_id in target_clients:
                    try:
                        await client['writer'](event_bytes)
                        client['last_active'] = time.time()
                        sent_count += 1
                    except Exception as e:
                        logger.error(f"Error sending to client {client_id}: {e}")
                        # Remove dead client
                        del self.clients[client_id]
            
            return web.json_response({
                'success': True,
                'sent_to': sent_count,
                'total_clients': len(self.clients)
            })
            
        except Exception as e:
            logger.error(f"Error processing publish request: {e}")
            return web.json_response({'error': str(e)}, status=500)
    
    async def handle_sse_proxy(self, request):
        """Proxy SSE connections to another SSE server"""
        try:
            target_url = request.query.get('target')
            if not target_url:
                return web.Response(text="Missing target parameter", status=400)
            
            # Validate URL
            parsed_url = urlparse(target_url)
            if not parsed_url.scheme or not parsed_url.netloc:
                return web.Response(text="Invalid target URL", status=400)
            
            # Set up SSE response
            response = web.Response(
                content_type='text/event-stream',
                headers={
                    'Cache-Control': 'no-cache',
                    'Connection': 'keep-alive',
                    'Access-Control-Allow-Origin': '*',
                }
            )
            response.enable_chunked_encoding()
            writer = response.write
            
            # Create a unique ID for this proxy connection
            proxy_id = str(uuid.uuid4())
            
            # Forward headers from the client to the target
            headers = {
                k: v for k, v in request.headers.items()
                if k.lower() not in ('host', 'connection')
            }
            
            # Connect to the target SSE server
            async with aiohttp.ClientSession() as session:
                try:
                    async with session.get(target_url, headers=headers) as resp:
                        if resp.status != 200:
                            return web.Response(
                                text=f"Target server returned status {resp.status}",
                                status=502
                            )
                        
                        # Ensure it's an SSE endpoint
                        content_type = resp.headers.get('Content-Type', '')
                        if 'text/event-stream' not in content_type.lower():
                            return web.Response(
                                text=f"Target is not an SSE endpoint (got {content_type})",
                                status=502
                            )
                        
                        logger.info(f"Proxying SSE connection to {target_url} ({proxy_id})")
                        
                        # Stream data from target to client
                        async for line in resp.content:
                            if not running:
                                break
                            await writer(line)
                
                except asyncio.CancelledError:
                    logger.info(f"SSE proxy connection cancelled: {proxy_id}")
                except Exception as e:
                    logger.error(f"Error proxying SSE: {e}")
                    await writer(f"event: error\ndata: {json.dumps({'error': str(e)})}\n\n".encode('utf-8'))
            
            return response
            
        except Exception as e:
            logger.error(f"Error in SSE proxy handler: {e}")
            return web.Response(text=f"Error: {str(e)}", status=500)
    
    async def handle_sse_info(self, request):
        """Return information about connected clients"""
        client_info = []
        for client_id, client in self.clients.items():
            client_info.append({
                'id': client_id,
                'connected_since': client['created_at'],
                'last_active': client['last_active'],
                'age_seconds': time.time() - client['created_at']
            })
        
        return web.json_response({
            'client_count': len(self.clients),
            'clients': client_info
        })
    
    async def cleanup_stale_clients(self):
        """Cleanup stale client connections"""
        while running:
            try:
                # Check every 60 seconds
                await asyncio.sleep(60)
                
                now = time.time()
                stale_threshold = 300  # 5 minutes without activity
                
                for client_id, client in list(self.clients.items()):
                    if now - client['last_active'] > stale_threshold:
                        logger.info(f"Removing stale client: {client_id}")
                        try:
                            # Send a close message
                            await client['writer'](f"event: close\ndata: Connection timed out\n\n".encode('utf-8'))
                        except:
                            pass
                        
                        # Remove from clients list
                        if client_id in self.clients:
                            del self.clients[client_id]
                
            except Exception as e:
                logger.error(f"Error in cleanup task: {e}")

def signal_handler(sig, frame):
    """Handle SIGINT and SIGTERM signals"""
    global running
    logger.info("Shutting down...")
    running = False

async def start_server(host, port):
    """Start the SSE proxy server"""
    app = web.Application()
    
    # Create SSE handler
    sse_handler = SSEHandler(app)
    
    # Set up routes
    app.router.add_get('/sse', sse_handler.handle_sse_client)
    app.router.add_post('/publish', sse_handler.handle_sse_publish)
    app.router.add_get('/proxy', sse_handler.handle_sse_proxy)
    app.router.add_get('/info', sse_handler.handle_sse_info)
    
    # Start cleanup task
    cleanup_task = asyncio.create_task(sse_handler.cleanup_stale_clients())
    
    # Start the server
    runner = web.AppRunner(app)
    await runner.setup()
    site = web.TCPSite(runner, host, port)
    await site.start()
    
    logger.info(f"SSE Proxy server started on {host}:{port}")
    
    try:
        # Keep the server running until stopped
        while running:
            await asyncio.sleep(1)
    finally:
        cleanup_task.cancel()
        await runner.cleanup()
        logger.info("Server shut down")

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='SSE (Server-Sent Events) Proxy')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, required=True, help='Port to bind')
    
    args = parser.parse_args()
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Start the server
    asyncio.run(start_server(args.host, args.port))

if __name__ == "__main__":
    main()
