#!/usr/bin/env python3

import socket
import threading
import argparse
import logging
import ssl
import sys
import base64
import time
import os
import signal
from http.client import HTTPResponse
from io import BytesIO

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger('python-proxy')

# Global variables
connections = set()
running = True

class FakeSocket():
    """A fake socket for HTTPResponse to use"""
    def __init__(self, response_bytes):
        self._file = BytesIO(response_bytes)
    
    def makefile(self, *args, **kwargs):
        return self._file

def parse_http_request(data):
    """Parse HTTP request data to extract method, path, headers"""
    try:
        # Split headers from body
        headers_end = data.find(b'\r\n\r\n')
        if headers_end == -1:
            return None
        
        headers_data = data[:headers_end]
        request_line, headers_lines = headers_data.split(b'\r\n', 1)
        
        # Parse request line
        method, path, version = request_line.decode('utf-8').split(' ')
        
        # Parse headers
        headers = {}
        for line in headers_lines.split(b'\r\n'):
            if not line:
                continue
            key, value = line.decode('utf-8').split(': ', 1)
            headers[key.lower()] = value
        
        return {
            'method': method,
            'path': path,
            'version': version,
            'headers': headers
        }
    except Exception as e:
        logger.error(f"Error parsing HTTP request: {e}")
        return None

def handle_connection(client_socket, client_address):
    """Handle client connection"""
    logger.info(f"New connection from {client_address}")
    connections.add(client_socket)
    
    try:
        # Receive initial data from client
        data = client_socket.recv(4096)
        if not data:
            logger.warning(f"No data received from {client_address}")
            return
        
        # Parse HTTP request
        request = parse_http_request(data)
        if not request:
            logger.warning(f"Invalid HTTP request from {client_address}")
            return
        
        # Check if this is a WebSocket upgrade request
        if (request['method'] == 'GET' and
            'upgrade' in request['headers'] and
            request['headers']['upgrade'].lower() == 'websocket'):
            handle_websocket_upgrade(client_socket, request)
        # Check if this is a CONNECT request (for HTTPS tunneling)
        elif request['method'] == 'CONNECT':
            handle_https_connect(client_socket, request)
        # Regular HTTP proxy
        elif request['method'] in ['GET', 'POST', 'PUT', 'DELETE', 'HEAD']:
            handle_http_proxy(client_socket, request, data)
        else:
            logger.warning(f"Unsupported method: {request['method']}")
            client_socket.sendall(b'HTTP/1.1 405 Method Not Allowed\r\n\r\n')
    
    except Exception as e:
        logger.error(f"Error handling connection: {e}")
    finally:
        client_socket.close()
        connections.remove(client_socket)
        logger.info(f"Connection closed from {client_address}")

def handle_websocket_upgrade(client_socket, request):
    """Handle WebSocket upgrade request with 101 protocol"""
    try:
        # Extract the target from the Host header
        host_header = request['headers'].get('host', '')
        if ':' in host_header:
            target_host, target_port = host_header.split(':', 1)
            target_port = int(target_port)
        else:
            target_host = host_header
            target_port = 80
        
        # Create a socket to the target server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.connect((target_host, target_port))
        
        # Forward the upgrade request to the target server
        server_socket.sendall(build_websocket_request(request))
        
        # Receive the response from the target server
        response = server_socket.recv(4096)
        
        # Parse the response to check if it's a 101 Switching Protocols
        if b'101 Switching Protocols' in response:
            # Forward the response back to the client
            client_socket.sendall(response)
            
            # Start bidirectional data exchange
            threading.Thread(target=forward_data, args=(client_socket, server_socket), daemon=True).start()
            threading.Thread(target=forward_data, args=(server_socket, client_socket), daemon=True).start()
            
            # Keep the connection open
            while True:
                time.sleep(1)
                if not running:
                    break
        else:
            # Forward the error response to the client
            client_socket.sendall(response)
            
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        try:
            client_socket.sendall(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
        except:
            pass

def build_websocket_request(request):
    """Build WebSocket upgrade request to send to the target server"""
    request_lines = [f"GET {request['path']} HTTP/1.1"]
    
    # Add headers
    for key, value in request['headers'].items():
        request_lines.append(f"{key}: {value}")
    
    # Build the full request
    return ('\r\n'.join(request_lines) + '\r\n\r\n').encode('utf-8')

def handle_https_connect(client_socket, request):
    """Handle HTTPS CONNECT tunneling"""
    try:
        # Parse the target address from the request path
        target = request['path']
        if ':' in target:
            target_host, target_port = target.split(':', 1)
            target_port = int(target_port)
        else:
            target_host = target
            target_port = 443
        
        # Create a socket to the target server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.connect((target_host, target_port))
        
        # Send 200 Connection established to the client
        client_socket.sendall(b'HTTP/1.1 200 Connection established\r\n\r\n')
        
        # Start bidirectional data exchange
        threading.Thread(target=forward_data, args=(client_socket, server_socket), daemon=True).start()
        threading.Thread(target=forward_data, args=(server_socket, client_socket), daemon=True).start()
        
        # Keep the connection open
        while True:
            time.sleep(1)
            if not running:
                break
            
    except Exception as e:
        logger.error(f"HTTPS tunneling error: {e}")
        try:
            client_socket.sendall(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
        except:
            pass

def handle_http_proxy(client_socket, request, original_data):
    """Handle regular HTTP proxy requests"""
    try:
        # Extract the target from the Host header or from the full URL
        if '://' in request['path']:
            # Full URL in path (e.g., http://example.com/path)
            import urllib.parse
            url = urllib.parse.urlparse(request['path'])
            target_host = url.netloc
            if ':' in target_host:
                target_host, target_port = target_host.split(':', 1)
                target_port = int(target_port)
            else:
                target_port = 80 if url.scheme == 'http' else 443
            path = url.path
            if url.query:
                path += '?' + url.query
        else:
            # Host header contains the target
            host_header = request['headers'].get('host', '')
            if ':' in host_header:
                target_host, target_port = host_header.split(':', 1)
                target_port = int(target_port)
            else:
                target_host = host_header
                target_port = 80
            path = request['path']
        
        # Create modified request with relative path and updated headers
        request_lines = [f"{request['method']} {path} HTTP/1.1"]
        for key, value in request['headers'].items():
            # Skip proxy-specific headers
            if key.lower() not in ['proxy-connection', 'connection']:
                request_lines.append(f"{key}: {value}")
        
        # Add Host header if not present
        if 'host' not in request['headers']:
            request_lines.append(f"Host: {target_host}")
        
        # Add Connection: close header
        request_lines.append("Connection: close")
        
        # Create a socket to the target server
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        # For HTTPS
        if target_port == 443:
            server_socket = ssl.wrap_socket(server_socket)
        
        server_socket.connect((target_host, target_port))
        
        # Send the modified request to the target server
        request_data = '\r\n'.join(request_lines) + '\r\n\r\n'
        server_socket.sendall(request_data.encode('utf-8'))
        
        # Receive and forward the response from the target server
        response = b''
        while True:
            data = server_socket.recv(4096)
            if not data:
                break
            response += data
            client_socket.sendall(data)
        
        server_socket.close()
        
    except Exception as e:
        logger.error(f"HTTP proxy error: {e}")
        try:
            client_socket.sendall(b'HTTP/1.1 502 Bad Gateway\r\n\r\n')
        except:
            pass

def forward_data(source, destination):
    """Forward data between two sockets"""
    try:
        while running:
            data = source.recv(4096)
            if not data:
                break
            destination.sendall(data)
    except:
        pass
    finally:
        try:
            source.close()
        except:
            pass
        try:
            destination.close()
        except:
            pass

def signal_handler(sig, frame):
    """Handle SIGINT and SIGTERM signals"""
    global running
    logger.info("Shutting down...")
    running = False
    
    # Close all connections
    for conn in list(connections):
        try:
            conn.close()
        except:
            pass
    
    sys.exit(0)

def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(description='Python Proxy with 101 Protocol support')
    parser.add_argument('--host', default='0.0.0.0', help='Host to bind (default: 0.0.0.0)')
    parser.add_argument('--port', type=int, required=True, help='Port to bind')
    
    args = parser.parse_args()
    
    # Register signal handlers
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Create server socket
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    
    try:
        server.bind((args.host, args.port))
        server.listen(100)
        
        logger.info(f"Python Proxy server started on {args.host}:{args.port}")
        
        while running:
            try:
                client, address = server.accept()
                threading.Thread(target=handle_connection, args=(client, address), daemon=True).start()
            except Exception as e:
                if running:
                    logger.error(f"Error accepting connection: {e}")
    
    except Exception as e:
        logger.error(f"Server error: {e}")
    
    finally:
        server.close()
        logger.info("Server shut down")

if __name__ == "__main__":
    main()
