#!/bin/bash

# This script tests the BadVPN management feature

# Run vps-manager with option 22 (BadVPN Management)
echo "Testing BadVPN Management..."
echo -e "22\n1\n5\n" | sudo ./vps-manager.sh

echo "Test completed."