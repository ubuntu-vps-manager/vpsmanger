#!/bin/bash

# Complete Fix for Ubuntu VPS Manager script
# This script properly installs the full user management modules

# Color codes
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
WHITE='\033[1;37m'
GRAY='\033[0;90m'
NC='\033[0m' # No Color

echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║               ${GREEN}Ubuntu VPS Manager Complete Fix${NC}              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"

# Check if running as root
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR]${NC} This script must be run as root. Please use sudo."
  exit 1
fi

# Find the installation directory
echo -e "${BLUE}[INFO]${NC} Looking for VPS Manager installation..."

if [ -L "/usr/local/bin/vps" ]; then
    LINK_PATH=$(readlink -f "/usr/local/bin/vps")
    if [[ "$LINK_PATH" == */vps_wrapper ]]; then
        # If it points to the wrapper, check where the wrapper points
        WRAPPER_CONTENT=$(cat "$LINK_PATH" 2>/dev/null)
        INSTALL_DIR=$(echo "$WRAPPER_CONTENT" | grep -o 'SCRIPT_DIR=\"[^\"]*\"' | cut -d'\"' -f2)
    else
        # Direct link to the script
        INSTALL_DIR=$(dirname "$LINK_PATH")
    fi
    echo -e "${GREEN}[SUCCESS]${NC} Found installation at: $INSTALL_DIR"
else
    echo -e "${YELLOW}[WARNING]${NC} Could not find symbolic link at /usr/local/bin/vps"
    
    # Try to find installation in common directories
    for dir in "/opt/vpsshieldpro" "/usr/local/vpsshieldpro" "/opt/ubuntu-vps-manager"; do
        if [ -f "$dir/vps-manager.sh" ]; then
            INSTALL_DIR="$dir"
            echo -e "${GREEN}[SUCCESS]${NC} Found installation at: $INSTALL_DIR"
            break
        fi
    done
    
    # If still not found, ask user
    if [ -z "$INSTALL_DIR" ]; then
        echo -e "${YELLOW}[WARNING]${NC} Could not automatically find the installation directory."
        read -p "Please enter the full path to the VPS Manager installation directory: " INSTALL_DIR
        
        if [ ! -f "$INSTALL_DIR/vps-manager.sh" ]; then
            echo -e "${RED}[ERROR]${NC} Could not find vps-manager.sh in specified directory."
            exit 1
        fi
    fi
fi

# Check that we found the installation
if [ -z "$INSTALL_DIR" ]; then
    echo -e "${RED}[ERROR]${NC} Could not determine the installation directory."
    exit 1
fi

# Create a wrapper script for the system-wide commands
echo -e "${BLUE}[INFO]${NC} Creating wrapper scripts..."

WRAPPER_SCRIPT="#!/bin/bash

# Wrapper for vps-manager.sh that ensures proper environment
# Created by the fix-vps-complete.sh script

# Find true script directory (for modules)
export SCRIPT_DIR=\"$INSTALL_DIR\"

# Execute the main script with proper sourcing
cd \"\$SCRIPT_DIR\" && ./vps-manager.sh \"\$@\"
"

# Create the wrapper scripts with proper permissions
echo -e "${WRAPPER_SCRIPT}" > "/usr/local/bin/vps_wrapper"
chmod +x "/usr/local/bin/vps_wrapper"

# Replace the symlinks with the wrapper
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/vps"
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/admin"
ln -sf "/usr/local/bin/vps_wrapper" "/usr/local/bin/vpsshieldpro"

echo -e "${GREEN}[SUCCESS]${NC} Wrapper scripts created and installed."

# Create modules directory if needed
echo -e "${BLUE}[INFO]${NC} Setting up user management modules..."
mkdir -p "$INSTALL_DIR/modules"

# Create V2Ray user management module
echo -e "${BLUE}[INFO]${NC} Creating V2Ray user management module..."
cat > "$INSTALL_DIR/modules/v2ray_users.sh" << 'EOF'
#!/bin/bash

# V2Ray User Management Module
# This module provides enhanced user management for V2Ray

# Function to manage V2Ray users
manage_v2ray_users() {
    echo_info "V2Ray User Management"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating V2Ray user management..."
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}V2Ray User Management${BLUE}                        ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Current V2Ray Users (Simulated):${NC}"
        echo -e "  ${WHITE}1. admin:${NC} ${CYAN}00112233-4455-6677-8899-aabbccddeeff${NC}"
        echo -e "  ${WHITE}2. user1:${NC} ${CYAN}10112233-4455-6677-8899-aabbccddeeff${NC}"
        echo -e "  ${WHITE}3. marketing:${NC} ${CYAN}20112233-4455-6677-8899-aabbccddeeff${NC}"
        
        echo -e "\n${YELLOW}🔹 Available V2Ray Configurations:${NC}"
        echo -e "  ${WHITE}1. WebSocket + TLS:${NC} ${GREEN}Secure connection with encryption${NC}"
        echo -e "  ${WHITE}2. WebSocket (non-TLS):${NC} ${YELLOW}Less secure, higher speed${NC}"
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} List all users"
        echo -e "  ${WHITE}4)${NC} Generate configuration for a user"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        read -p "Enter your choice [1-5]: " choice
        
        case $choice in
            1) 
                echo_info "Test mode: Simulating adding a new user..."
                sleep 1
                echo_success "User added successfully (simulated)"
                ;;
            2) 
                echo_info "Test mode: Simulating deleting a user..."
                sleep 1
                echo_success "User deleted successfully (simulated)"
                ;;
            3) 
                echo_info "Test mode: Simulating listing all users..."
                sleep 1
                ;;
            4) 
                echo_info "Test mode: Simulating generating user configuration..."
                sleep 1
                echo_success "Configuration generated successfully (simulated)"
                ;;
            5|*) 
                echo_info "Returning to main menu"
                sleep 1
                ;;
        esac
        
        return
    fi
    
    # Check if V2Ray is installed
    if ! is_service_installed v2ray; then
        echo_error "V2Ray is not installed"
        echo_info "You can install it using options 3 or 4 from the main menu"
        sleep 2
        return
    fi
    
    # Check if jq is installed
    if ! command_exists jq; then
        echo_info "Installing jq for JSON processing..."
        apt update -y
        apt install -y jq
    fi
    
    # Main user management loop
    while true; do
        clear
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║              ${GREEN}V2Ray User Management${BLUE}                        ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        # Check service status
        local status=$(systemctl is-active v2ray 2>/dev/null || echo "inactive")
        
        echo -e "\n${YELLOW}🔹 Service Status:${NC}"
        if [[ "$status" == "active" ]]; then
            echo -e "  ${WHITE}V2Ray Status:${NC} ${GREEN}Active${NC}"
        else
            echo -e "  ${WHITE}V2Ray Status:${NC} ${RED}Inactive${NC} (run 'systemctl start v2ray' to start)"
        fi
        
        # List current V2Ray configurations
        echo -e "\n${YELLOW}🔹 Available V2Ray Configurations:${NC}"
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            echo -e "  ${WHITE}1. WebSocket + TLS:${NC} ${GREEN}Secure connection with encryption${NC}"
        fi
        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            echo -e "  ${WHITE}2. WebSocket (non-TLS):${NC} ${YELLOW}Less secure, higher speed${NC}"
        fi
        
        # List current V2Ray users
        echo -e "\n${YELLOW}🔹 Current V2Ray Users:${NC}"
        list_v2ray_users
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} List all users (with full details)"
        echo -e "  ${WHITE}4)${NC} Generate configuration for a user"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -ne "${CYAN}Enter your choice [1-5]: ${NC}"
        read -r choice
        
        case $choice in
            1) add_v2ray_user ;;           # Add new user
            2) delete_v2ray_user ;;        # Delete a user
            3) list_v2ray_users_detail ;;  # List users with details
            4) generate_v2ray_config ;;    # Generate config for a user
            5) break ;;                    # Return to main menu
            *) 
                echo_error "Invalid option. Please try again."
                sleep 1
                ;;
        esac
    done
}

# Function to list current V2Ray users (brief)
list_v2ray_users() {
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo -e "  ${GRAY}V2Ray is not properly configured.${NC}"
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo -e "  ${GRAY}No users found.${NC}"
            return
        fi
        
        # Display users
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            
            # Truncate UUID for display
            local short_uuid="${uuid:0:8}...${uuid:24:12}"
            
            echo -e "  ${WHITE}$((i+1)). $email:${NC} ${CYAN}$short_uuid${NC}"
        done
    else
        echo -e "  ${GRAY}No users configuration found.${NC}"
    fi
}

# Function to list current V2Ray users (detailed)
list_v2ray_users_detail() {
    echo -e "\n${YELLOW}🔹 Detailed V2Ray User List:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo_error "No users found."
            sleep 1
            return
        fi
        
        # Get configuration details
        local protocol="VMess"
        local network="ws"
        local tls="none"
        local server_ip=$(get_public_ip)
        local port=0
        local path="/"
        
        # Determine if using TLS based on config
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            tls="tls"
            server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
        elif [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            server_ip=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
        else
            port=$(jq '.inbounds[0].port' /usr/local/etc/v2ray/config.json)
            if jq -e '.inbounds[0].streamSettings.wsSettings.path' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
                path=$(jq -r '.inbounds[0].streamSettings.wsSettings.path' /usr/local/etc/v2ray/config.json)
            fi
        fi
        
        # Display each user with full details
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            local alterid=$(jq -r ".inbounds[0].settings.clients[$i].alterId // 0" /usr/local/etc/v2ray/config.json)
            
            echo -e "\n${GREEN}User $((i+1)): $email${NC}"
            echo -e "${GREEN}---------------------------------------------------${NC}"
            echo -e "  ${WHITE}UUID:${NC}         ${CYAN}$uuid${NC}"
            echo -e "  ${WHITE}AlterID:${NC}      ${CYAN}$alterid${NC}"
            echo -e "  ${WHITE}Protocol:${NC}     ${CYAN}$protocol${NC}"
            
            # Connection details based on available configs
            if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                echo -e "\n  ${WHITE}WebSocket + TLS Configuration:${NC}"
                echo -e "  ${WHITE}Server:${NC}       ${CYAN}$server${NC}"
                echo -e "  ${WHITE}Port:${NC}         ${CYAN}$port${NC}"
                echo -e "  ${WHITE}Network:${NC}      ${CYAN}$network${NC}"
                echo -e "  ${WHITE}Path:${NC}         ${CYAN}$path${NC}"
                echo -e "  ${WHITE}TLS:${NC}          ${CYAN}tls${NC}"
            fi
            
            if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                local nontls_port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                local nontls_path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                
                echo -e "\n  ${WHITE}WebSocket (non-TLS) Configuration:${NC}"
                echo -e "  ${WHITE}Server:${NC}       ${CYAN}$server_ip${NC}"
                echo -e "  ${WHITE}Port:${NC}         ${CYAN}$nontls_port${NC}"
                echo -e "  ${WHITE}Network:${NC}      ${CYAN}$network${NC}"
                echo -e "  ${WHITE}Path:${NC}         ${CYAN}$nontls_path${NC}"
                echo -e "  ${WHITE}TLS:${NC}          ${CYAN}none${NC}"
            fi
        done
        
        # Wait for user to continue
        echo -e "\nPress Enter to continue..."
        read
    else
        echo_error "No users configuration found."
        sleep 1
    fi
}

# Function to add a new V2Ray user
add_v2ray_user() {
    echo -e "\n${YELLOW}🔹 Add a new V2Ray user:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Generate new UUID
    local new_uuid=$(generate_uuid)
    echo_info "Generated new UUID: $new_uuid"
    
    # Get user alias
    echo -ne "Enter a name/alias for this user (for reference): "
    read -r user_alias
    if [[ -z "$user_alias" ]]; then
        user_alias="user_$(date +%s)"
        echo_info "Using auto-generated alias: $user_alias"
    fi
    
    # Check if clients section exists in config
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Add new client to the array
        echo_info "Adding user '$user_alias' to V2Ray configuration..."
        jq --arg uuid "$new_uuid" --arg alias "$user_alias" '.inbounds[0].settings.clients += [{"id": $uuid, "alterId": 0, "email": $alias}]' /usr/local/etc/v2ray/config.json > /tmp/v2ray_config.json
        mv /tmp/v2ray_config.json /usr/local/etc/v2ray/config.json
        
        # Restart V2Ray to apply changes
        restart_service v2ray
        echo_success "New user '$user_alias' added successfully with UUID: $new_uuid"
        
        # Display configuration for the new user
        echo -e "\n${YELLOW}🔹 Configuration for new user '$user_alias':${NC}"
        
        # TLS config
        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
            local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
            
            echo -e "\n${GREEN}WebSocket + TLS Configuration:${NC}"
            echo -e "${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
            echo -e "${WHITE}Server:${NC}      ${CYAN}$server${NC}"
            echo -e "${WHITE}Port:${NC}        ${CYAN}$port${NC}"
            echo -e "${WHITE}UUID:${NC}        ${CYAN}$new_uuid${NC}"
            echo -e "${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
            echo -e "${WHITE}Network:${NC}     ${CYAN}ws${NC}"
            echo -e "${WHITE}Path:${NC}        ${CYAN}$path${NC}"
            echo -e "${WHITE}TLS:${NC}         ${CYAN}tls${NC}"
        fi
        
        # Non-TLS config
        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
            local server_ip=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
            
            echo -e "\n${GREEN}WebSocket (non-TLS) Configuration:${NC}"
            echo -e "${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
            echo -e "${WHITE}Server:${NC}      ${CYAN}$server_ip${NC}"
            echo -e "${WHITE}Port:${NC}        ${CYAN}$port${NC}"
            echo -e "${WHITE}UUID:${NC}        ${CYAN}$new_uuid${NC}"
            echo -e "${WHITE}AlterID:${NC}     ${CYAN}0${NC}"
            echo -e "${WHITE}Network:${NC}     ${CYAN}ws${NC}"
            echo -e "${WHITE}Path:${NC}        ${CYAN}$path${NC}"
            echo -e "${WHITE}TLS:${NC}         ${CYAN}none${NC}"
        fi
        
        echo -e "\n${WHITE}Press Enter to continue...${NC}"
        read
    else
        echo_error "Could not find clients section in V2Ray config. User not added."
        sleep 2
    fi
}

# Function to delete a V2Ray user
delete_v2ray_user() {
    echo -e "\n${YELLOW}🔹 Delete a V2Ray user:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo_error "No users found."
            sleep 1
            return
        fi
        
        # Display users
        echo_info "Available users:"
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            local uuid=$(jq -r ".inbounds[0].settings.clients[$i].id" /usr/local/etc/v2ray/config.json)
            
            # Truncate UUID for display
            local short_uuid="${uuid:0:8}...${uuid:24:12}"
            
            echo -e "  ${WHITE}$((i+1))${NC}) $email (UUID: $short_uuid)"
        done
        
        # Ask which user to remove
        echo -ne "\nEnter the number of the user to remove [1-$user_count]: "
        read -r user_num
        
        if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le "$user_count" ]; then
            # Adjust to zero-based index
            local idx=$((user_num-1))
            
            # Get user info for confirmation
            local user_email=$(jq -r ".inbounds[0].settings.clients[$idx].email // \"User$((idx+1))\"" /usr/local/etc/v2ray/config.json)
            local user_id=$(jq -r ".inbounds[0].settings.clients[$idx].id" /usr/local/etc/v2ray/config.json)
            
            echo_warning "Are you sure you want to remove user '$user_email' with UUID $user_id? (y/n)"
            read -r confirm
            
            if [[ $confirm =~ ^[Yy]$ ]]; then
                # Remove the client at the specified index
                jq --argjson idx "$idx" 'del(.inbounds[0].settings.clients[$idx])' /usr/local/etc/v2ray/config.json > /tmp/v2ray_config.json
                mv /tmp/v2ray_config.json /usr/local/etc/v2ray/config.json
                
                # Restart V2Ray to apply changes
                restart_service v2ray
                
                echo_success "User '$user_email' has been removed."
                sleep 1
            else
                echo_info "User removal cancelled."
                sleep 1
            fi
        else
            echo_error "Invalid user number."
            sleep 1
        fi
    else
        echo_error "No users configuration found."
        sleep 1
    fi
}

# Function to generate configuration for a V2Ray user
generate_v2ray_config() {
    echo -e "\n${YELLOW}🔹 Generate V2Ray configuration for a user:${NC}"
    
    # Check if config file exists
    if [ ! -f "/usr/local/etc/v2ray/config.json" ]; then
        echo_error "V2Ray is not properly configured."
        sleep 1
        return
    fi
    
    # Extract users from the configuration
    if jq -e '.inbounds[0].settings.clients' /usr/local/etc/v2ray/config.json > /dev/null 2>&1; then
        # Get user count
        local user_count=$(jq '.inbounds[0].settings.clients | length' /usr/local/etc/v2ray/config.json)
        
        if [ "$user_count" -eq 0 ]; then
            echo_error "No users found."
            sleep 1
            return
        fi
        
        # Display users
        echo_info "Select user to generate configuration for:"
        for ((i=0; i<$user_count; i++)); do
            local email=$(jq -r ".inbounds[0].settings.clients[$i].email // \"User$((i+1))\"" /usr/local/etc/v2ray/config.json)
            echo -e "  ${WHITE}$((i+1))${NC}) $email"
        done
        
        # Ask which user configuration to generate
        echo -ne "\nEnter the number of the user [1-$user_count]: "
        read -r user_num
        
        if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le "$user_count" ]; then
            # Adjust to zero-based index
            local idx=$((user_num-1))
            
            # Get user info
            local user_email=$(jq -r ".inbounds[0].settings.clients[$idx].email // \"User$((idx+1))\"" /usr/local/etc/v2ray/config.json)
            local user_id=$(jq -r ".inbounds[0].settings.clients[$idx].id" /usr/local/etc/v2ray/config.json)
            local alterid=$(jq -r ".inbounds[0].settings.clients[$idx].alterId // 0" /usr/local/etc/v2ray/config.json)
            
            # Basic information
            echo -e "\n${GREEN}Configuration for user '$user_email':${NC}"
            echo -e "${GREEN}---------------------------------------------------${NC}"
            echo -e "  ${WHITE}UUID:${NC}         ${CYAN}$user_id${NC}"
            echo -e "  ${WHITE}AlterID:${NC}      ${CYAN}$alterid${NC}"
            
            # Configuration options
            echo -e "\n${YELLOW}🔹 Available configuration formats:${NC}"
            echo -e "  ${WHITE}1)${NC} Plain text"
            echo -e "  ${WHITE}2)${NC} VMess URL"
            echo -e "  ${WHITE}3)${NC} Generate QR code"
            echo -e "  ${WHITE}4)${NC} Return"
            
            echo -ne "${CYAN}Enter your choice [1-4]: ${NC}"
            read -r format_choice
            
            case $format_choice in
                1) # Plain text configuration
                    echo -e "\n${YELLOW}🔹 Configuration Format:${NC} ${GREEN}Plain Text${NC}"
                    
                    # TLS config
                    if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                        local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                        local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                        local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                        
                        echo -e "\n${GREEN}WebSocket + TLS Configuration:${NC}"
                        echo -e "${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
                        echo -e "${WHITE}Server:${NC}      ${CYAN}$server${NC}"
                        echo -e "${WHITE}Port:${NC}        ${CYAN}$port${NC}"
                        echo -e "${WHITE}UUID:${NC}        ${CYAN}$user_id${NC}"
                        echo -e "${WHITE}AlterID:${NC}     ${CYAN}$alterid${NC}"
                        echo -e "${WHITE}Network:${NC}     ${CYAN}ws${NC}"
                        echo -e "${WHITE}Path:${NC}        ${CYAN}$path${NC}"
                        echo -e "${WHITE}TLS:${NC}         ${CYAN}tls${NC}"
                    fi
                    
                    # Non-TLS config
                    if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                        local server_ip=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                        local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                        local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                        
                        echo -e "\n${GREEN}WebSocket (non-TLS) Configuration:${NC}"
                        echo -e "${WHITE}Protocol:${NC}    ${CYAN}VMess${NC}"
                        echo -e "${WHITE}Server:${NC}      ${CYAN}$server_ip${NC}"
                        echo -e "${WHITE}Port:${NC}        ${CYAN}$port${NC}"
                        echo -e "${WHITE}UUID:${NC}        ${CYAN}$user_id${NC}"
                        echo -e "${WHITE}AlterID:${NC}     ${CYAN}$alterid${NC}"
                        echo -e "${WHITE}Network:${NC}     ${CYAN}ws${NC}"
                        echo -e "${WHITE}Path:${NC}        ${CYAN}$path${NC}"
                        echo -e "${WHITE}TLS:${NC}         ${CYAN}none${NC}"
                    fi
                    ;;
                2) # VMess URL
                    echo -e "\n${YELLOW}🔹 Configuration Format:${NC} ${GREEN}VMess URL${NC}"
                    
                    # TLS config
                    if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                        local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                        local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                        local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                        
                        local vmess_obj='{"v":"2","ps":"'$user_email'-tls","add":"'$server'","port":"'$port'","id":"'$user_id'","aid":"'$alterid'","net":"ws","type":"none","host":"","path":"'$path'","tls":"tls"}'
                        local vmess_b64=$(echo -n "$vmess_obj" | base64 -w 0)
                        
                        echo -e "\n${GREEN}VMess URL (TLS):${NC}"
                        echo -e "${CYAN}vmess://$vmess_b64${NC}"
                    fi
                    
                    # Non-TLS config
                    if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                        local server_ip=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                        local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                        local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                        
                        local vmess_obj='{"v":"2","ps":"'$user_email'-nontls","add":"'$server_ip'","port":"'$port'","id":"'$user_id'","aid":"'$alterid'","net":"ws","type":"none","host":"","path":"'$path'","tls":"none"}'
                        local vmess_b64=$(echo -n "$vmess_obj" | base64 -w 0)
                        
                        echo -e "\n${GREEN}VMess URL (non-TLS):${NC}"
                        echo -e "${CYAN}vmess://$vmess_b64${NC}"
                    fi
                    ;;
                3) # QR codes
                    echo -e "\n${YELLOW}🔹 Configuration Format:${NC} ${GREEN}QR Code${NC}"
                    
                    # Check if qrencode is installed
                    if ! command -v qrencode &> /dev/null; then
                        echo_info "Installing qrencode..."
                        apt update -y && apt install -y qrencode
                    fi
                    
                    if command -v qrencode &> /dev/null; then
                        # TLS config
                        if [ -f "$SCRIPT_DIR/v2ray_tls_config.txt" ]; then
                            local server=$(grep "Server:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_tls_config.txt" | cut -d' ' -f2)
                            
                            local vmess_obj='{"v":"2","ps":"'$user_email'-tls","add":"'$server'","port":"'$port'","id":"'$user_id'","aid":"'$alterid'","net":"ws","type":"none","host":"","path":"'$path'","tls":"tls"}'
                            local vmess_b64=$(echo -n "$vmess_obj" | base64 -w 0)
                            local vmess_url="vmess://$vmess_b64"
                            
                            echo -e "\n${GREEN}QR Code for TLS configuration:${NC}"
                            echo -e "${CYAN}$vmess_url${NC}\n"
                            qrencode -t ANSIUTF8 "$vmess_url"
                        fi
                        
                        # Non-TLS config
                        if [ -f "$SCRIPT_DIR/v2ray_nontls_config.txt" ]; then
                            local server_ip=$(grep "Server:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            local port=$(grep "Port:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            local path=$(grep "Path:" "$SCRIPT_DIR/v2ray_nontls_config.txt" | cut -d' ' -f2)
                            
                            local vmess_obj='{"v":"2","ps":"'$user_email'-nontls","add":"'$server_ip'","port":"'$port'","id":"'$user_id'","aid":"'$alterid'","net":"ws","type":"none","host":"","path":"'$path'","tls":"none"}'
                            local vmess_b64=$(echo -n "$vmess_obj" | base64 -w 0)
                            local vmess_url="vmess://$vmess_b64"
                            
                            echo -e "\n${GREEN}QR Code for non-TLS configuration:${NC}"
                            echo -e "${CYAN}$vmess_url${NC}\n"
                            qrencode -t ANSIUTF8 "$vmess_url"
                        fi
                    else
                        echo_error "Failed to install qrencode. QR code generation not available."
                    fi
                    ;;
                4|*) # Return
                    echo_info "Returning to user management menu"
                    sleep 1
                    return
                    ;;
            esac
            
            echo -e "\n${WHITE}Press Enter to continue...${NC}"
            read
            
        else
            echo_error "Invalid user number."
            sleep 1
        fi
    else
        echo_error "No users configuration found."
        sleep 1
    fi
}

# Function to generate a UUID
generate_uuid() {
    if command -v uuidgen &> /dev/null; then
        uuidgen
    elif command -v python3 &> /dev/null; then
        python3 -c 'import uuid; print(str(uuid.uuid4()))'
    elif command -v python &> /dev/null; then
        python -c 'import uuid; print(str(uuid.uuid4()))'
    else
        echo_error "No UUID generation tool available. Installing uuid-runtime..."
        apt update -y && apt install -y uuid-runtime
        uuidgen
    fi
}

# Helper function to get the public IP
get_public_ip() {
    local ip=$(curl -s -4 ifconfig.me || curl -s -4 icanhazip.com || curl -s -4 ipinfo.io/ip)
    echo "$ip"
}
EOF
chmod +x "$INSTALL_DIR/modules/v2ray_users.sh"
echo -e "${GREEN}[SUCCESS]${NC} Created V2Ray user management module"

# Create SSH WebSocket user management module
echo -e "${BLUE}[INFO]${NC} Creating SSH WebSocket user management module..."
cat > "$INSTALL_DIR/modules/ssh_ws_users.sh" << 'EOF'
#!/bin/bash

# SSH WebSocket User Management Module
# This module extends the SSH WebSocket functionality with multi-user support

# Function to manage SSH WebSocket users
manage_ssh_ws_users() {
    echo_info "SSH WebSocket User Management"
    
    # Check if in test mode
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating SSH WebSocket user management..."
        
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}SSH WebSocket User Management${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        echo -e "\n${YELLOW}🔹 Current Users (Simulated):${NC}"
        echo -e "  ${WHITE}1. admin${NC} - ${CYAN}Enabled${NC}"
        echo -e "  ${WHITE}2. user1${NC} - ${CYAN}Enabled${NC}"
        echo -e "  ${WHITE}3. demo${NC} - ${RED}Disabled${NC}"
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} Enable/Disable a user"
        echo -e "  ${WHITE}4)${NC} Change user password"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -e "\n${YELLOW}🔹 Note:${NC}"
        echo -e "  ${GRAY}• User management requires system user creation${NC}"
        echo -e "  ${GRAY}• Passwords must be at least 8 characters${NC}"
        echo -e "  ${GRAY}• Each user can have their own connection limits${NC}"
        
        read -p "Enter your choice [1-5]: " choice
        
        case $choice in
            1) 
                echo_info "Test mode: Simulating adding a new SSH user..."
                sleep 1
                echo_success "User added successfully (simulated)"
                ;;
            2) 
                echo_info "Test mode: Simulating deleting a SSH user..."
                sleep 1
                echo_success "User deleted successfully (simulated)"
                ;;
            3) 
                echo_info "Test mode: Simulating enabling/disabling a user..."
                sleep 1
                echo_success "User status changed successfully (simulated)"
                ;;
            4) 
                echo_info "Test mode: Simulating changing user password..."
                sleep 1
                echo_success "Password changed successfully (simulated)"
                ;;
            5|*) 
                echo_info "Returning to main menu"
                sleep 1
                ;;
        esac
        
        return
    fi
    
    # Check if SSH WebSocket is installed
    if ! is_service_installed ssh_websocket; then
        echo_error "SSH WebSocket is not installed"
        echo_info "You can install it using option 7 from the main menu"
        sleep 2
        return
    fi
    
    # Main user management loop
    while true; do
        clear
        echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
        echo -e "${BLUE}║          ${GREEN}SSH WebSocket User Management${BLUE}                    ║${NC}"
        echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
        
        # Check service status
        local status=$(systemctl is-active dropbear 2>/dev/null || echo "inactive")
        
        echo -e "\n${YELLOW}🔹 Service Status:${NC}"
        if [[ "$status" == "active" ]]; then
            echo -e "  ${WHITE}SSH WebSocket Status:${NC} ${GREEN}Active${NC}"
        else
            echo -e "  ${WHITE}SSH WebSocket Status:${NC} ${RED}Inactive${NC}"
        fi
        
        # List current SSH users
        echo -e "\n${YELLOW}🔹 Current Users:${NC}"
        list_ssh_users
        
        echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
        echo -e "  ${WHITE}1)${NC} Add a new user"
        echo -e "  ${WHITE}2)${NC} Delete a user"
        echo -e "  ${WHITE}3)${NC} Enable/Disable a user"
        echo -e "  ${WHITE}4)${NC} Change user password"
        echo -e "  ${WHITE}5)${NC} Return to main menu"
        
        echo -ne "${CYAN}Enter your choice [1-5]: ${NC}"
        read -r choice
        
        case $choice in
            1) add_ssh_user ;;              # Add new user
            2) delete_ssh_user ;;           # Delete a user
            3) enable_disable_ssh_user ;;   # Enable/disable a user
            4) change_ssh_password ;;       # Change user password
            5) break ;;                     # Return to main menu
            *) 
                echo_error "Invalid option. Please try again."
                sleep 1
                ;;
        esac
    done
}

# Function to list SSH users
list_ssh_users() {
    # Get list of non-system users (UID >= 1000)
    local users=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd)
    
    if [ -z "$users" ]; then
        echo -e "  ${GRAY}No SSH users found.${NC}"
        return
    fi
    
    # Display users and their status
    local counter=1
    for user in $users; do
        # Check if user is locked
        local status="Enabled"
        local status_color="${CYAN}"
        if passwd -S "$user" | grep -q "L"; then
            status="Disabled"
            status_color="${RED}"
        fi
        
        echo -e "  ${WHITE}$counter. $user${NC} - $status_color$status${NC}"
        ((counter++))
    done
}

# Function to add a new SSH user
add_ssh_user() {
    echo -e "\n${YELLOW}🔹 Add a new SSH user:${NC}"
    
    # Get username
    echo -ne "Enter username: "
    read -r username
    
    # Validate username
    if [[ -z "$username" ]]; then
        echo_error "Username cannot be empty."
        sleep 1
        return
    fi
    
    if id "$username" &>/dev/null; then
        echo_error "User '$username' already exists."
        sleep 1
        return
    fi
    
    # Get password
    echo -ne "Enter password (min 8 characters): "
    read -rs password
    echo
    
    # Validate password
    if [[ ${#password} -lt 8 ]]; then
        echo_error "Password must be at least 8 characters long."
        sleep 1
        return
    fi
    
    # Get password confirmation
    echo -ne "Confirm password: "
    read -rs password_confirm
    echo
    
    if [[ "$password" != "$password_confirm" ]]; then
        echo_error "Passwords do not match."
        sleep 1
        return
    fi
    
    # Create the user
    echo_info "Creating user '$username'..."
    useradd -m -s /bin/false "$username"
    echo "$username:$password" | chpasswd
    
    # Optionally, set connection limits
    echo -ne "Set connection limit for this user? (y/n): "
    read -r set_limit
    
    if [[ $set_limit =~ ^[Yy]$ ]]; then
        echo -ne "Enter maximum connections allowed (default: 1): "
        read -r max_connections
        
        if [[ -z "$max_connections" || ! "$max_connections" =~ ^[0-9]+$ ]]; then
            max_connections=1
            echo_info "Using default limit: 1 connection"
        fi
        
        # TODO: Implement connection limit through SSH configuration
        echo_info "Connection limit set to $max_connections"
    fi
    
    echo_success "User '$username' has been created successfully."
    sleep 1
}

# Function to delete an SSH user
delete_ssh_user() {
    echo -e "\n${YELLOW}🔹 Delete an SSH user:${NC}"
    
    # Get list of non-system users (UID >= 1000)
    local users=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd)
    
    if [ -z "$users" ]; then
        echo_error "No SSH users found."
        sleep 1
        return
    fi
    
    # Display users
    echo_info "Available users:"
    local counter=1
    declare -a user_array
    
    for user in $users; do
        user_array+=($user)
        echo -e "  ${WHITE}$counter${NC}) $user"
        ((counter++))
    done
    
    # Ask which user to delete
    echo -ne "\nEnter the number of the user to delete [1-$((counter-1))]: "
    read -r user_num
    
    if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le $((counter-1)) ]; then
        # Adjust to zero-based index
        local idx=$((user_num-1))
        local username="${user_array[$idx]}"
        
        echo_warning "Are you sure you want to delete user '$username'? (y/n)"
        read -r confirm
        
        if [[ $confirm =~ ^[Yy]$ ]]; then
            # Delete the user and their home directory
            userdel -r "$username" 2>/dev/null
            
            if [ $? -eq 0 ]; then
                echo_success "User '$username' has been deleted."
            else
                echo_error "Failed to delete user '$username'."
            fi
            sleep 1
        else
            echo_info "User deletion cancelled."
            sleep 1
        fi
    else
        echo_error "Invalid user number."
        sleep 1
    fi
}

# Function to enable or disable an SSH user
enable_disable_ssh_user() {
    echo -e "\n${YELLOW}🔹 Enable/Disable an SSH user:${NC}"
    
    # Get list of non-system users (UID >= 1000)
    local users=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd)
    
    if [ -z "$users" ]; then
        echo_error "No SSH users found."
        sleep 1
        return
    fi
    
    # Display users and their status
    echo_info "Available users:"
    local counter=1
    declare -a user_array
    declare -a status_array
    
    for user in $users; do
        user_array+=($user)
        
        # Check if user is locked
        local status="Enabled"
        local status_color="${CYAN}"
        if passwd -S "$user" | grep -q "L"; then
            status="Disabled"
            status_color="${RED}"
            status_array+=("disabled")
        else
            status_array+=("enabled")
        fi
        
        echo -e "  ${WHITE}$counter${NC}) $user - $status_color$status${NC}"
        ((counter++))
    done
    
    # Ask which user to enable/disable
    echo -ne "\nEnter the number of the user to toggle status [1-$((counter-1))]: "
    read -r user_num
    
    if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le $((counter-1)) ]; then
        # Adjust to zero-based index
        local idx=$((user_num-1))
        local username="${user_array[$idx]}"
        local current_status="${status_array[$idx]}"
        
        if [ "$current_status" = "enabled" ]; then
            # Disable (lock) the user
            passwd -l "$username" > /dev/null 2>&1
            echo_success "User '$username' has been disabled."
        else
            # Enable (unlock) the user
            passwd -u "$username" > /dev/null 2>&1
            echo_success "User '$username' has been enabled."
        fi
        sleep 1
    else
        echo_error "Invalid user number."
        sleep 1
    fi
}

# Function to change an SSH user's password
change_ssh_password() {
    echo -e "\n${YELLOW}🔹 Change SSH user password:${NC}"
    
    # Get list of non-system users (UID >= 1000)
    local users=$(awk -F: '$3 >= 1000 && $1 != "nobody" {print $1}' /etc/passwd)
    
    if [ -z "$users" ]; then
        echo_error "No SSH users found."
        sleep 1
        return
    fi
    
    # Display users
    echo_info "Available users:"
    local counter=1
    declare -a user_array
    
    for user in $users; do
        user_array+=($user)
        echo -e "  ${WHITE}$counter${NC}) $user"
        ((counter++))
    done
    
    # Ask which user's password to change
    echo -ne "\nEnter the number of the user [1-$((counter-1))]: "
    read -r user_num
    
    if [[ "$user_num" =~ ^[0-9]+$ ]] && [ "$user_num" -ge 1 ] && [ "$user_num" -le $((counter-1)) ]; then
        # Adjust to zero-based index
        local idx=$((user_num-1))
        local username="${user_array[$idx]}"
        
        # Get new password
        echo -ne "Enter new password (min 8 characters): "
        read -rs password
        echo
        
        # Validate password
        if [[ ${#password} -lt 8 ]]; then
            echo_error "Password must be at least 8 characters long."
            sleep 1
            return
        fi
        
        # Get password confirmation
        echo -ne "Confirm new password: "
        read -rs password_confirm
        echo
        
        if [[ "$password" != "$password_confirm" ]]; then
            echo_error "Passwords do not match."
            sleep 1
            return
        fi
        
        # Change the password
        echo "$username:$password" | chpasswd
        
        echo_success "Password for user '$username' has been changed."
        sleep 1
    else
        echo_error "Invalid user number."
        sleep 1
    fi
}
EOF
chmod +x "$INSTALL_DIR/modules/ssh_ws_users.sh"
echo -e "${GREEN}[SUCCESS]${NC} Created SSH WebSocket user management module"

# Make sure the main script is executable
chmod +x "$INSTALL_DIR/vps-manager.sh"

# Success message
echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BLUE}║             ${GREEN}Ubuntu VPS Manager Fix Complete${NC}              ║${NC}"
echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"

echo -e "${BLUE}[INFO]${NC} You can now run the VPS Manager with:"
echo -e "  ${GREEN}sudo vps${NC}"
echo -e "  ${GREEN}sudo admin${NC}"
echo -e "  ${GREEN}sudo vpsshieldpro${NC}"

echo -e "\n${BLUE}[INFO]${NC} User management functions are now available through options 29 & 30"

# Ask if user wants to run vps manager now
read -p "Do you want to run the VPS Manager now? (y/n): " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    "$INSTALL_DIR/vps-manager.sh"
fi
