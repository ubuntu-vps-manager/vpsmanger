#!/bin/bash

# Automated test for V2Ray user management
test_v2ray_users() {
    echo -e "\n\n===== Testing V2Ray User Management =====\n"
    echo 29 | ./vps-manager.sh --test
}

# Automated test for SSH WebSocket user management
test_ssh_ws_users() {
    echo -e "\n\n===== Testing SSH WebSocket User Management =====\n"
    echo 30 | ./vps-manager.sh --test
}

# Run the tests
echo "Starting automated tests..."
test_v2ray_users
test_ssh_ws_users
echo -e "\n\nTests completed."
