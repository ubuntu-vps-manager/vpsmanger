#!/bin/bash

# VPS Manager - Ubuntu 22.04
# A comprehensive management script for V2Ray, SSH WebSocket, Python proxy, and SSE proxy
# GitHub: https://github.com/kurogai/ubuntu-vps-manager

# Version
VERSION="1.0.0"

# Script directory - handle both direct execution and symlinks
SOURCE="${BASH_SOURCE[0]}"
while [ -h "$SOURCE" ]; do # resolve $SOURCE until the file is no longer a symlink
  DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"
  SOURCE="$(readlink "$SOURCE")"
  [[ $SOURCE != /* ]] && SOURCE="$DIR/$SOURCE" # if $SOURCE was a relative symlink, we need to resolve it relative to the path where the symlink file was located
done
SCRIPT_DIR="$( cd -P "$( dirname "$SOURCE" )" && pwd )"

# Initialize variables
IS_TEST_MODE=false
SHOW_HELP=false
SHOW_VERSION=false

# Help function
show_help() {
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║              ${GREEN}Ubuntu VPS Manager v$VERSION${BLUE}                   ║${NC}"
    echo -e "${BLUE}║         ${CYAN}Created by MasterMind ${YELLOW}@bitcockiii${BLUE}            ║${NC}"
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    echo -e "\n${YELLOW}🔹 Usage:${NC}"
    echo -e "  $0 [OPTIONS]"
    
    echo -e "\n${YELLOW}🔹 Command Line Options:${NC}"
    echo -e "  ${WHITE}-h, --help${NC}            Show this help message and exit"
    echo -e "  ${WHITE}-v, --version${NC}         Show version information and exit"
    echo -e "  ${WHITE}-t, --test${NC}            Run in test mode (simulates actions without making system changes)"
    echo -e "  ${WHITE}-q, --quiet${NC}           Run in quiet mode (less verbose output)"
    
    echo -e "\n${YELLOW}🔹 Features:${NC}"
    echo -e "  ${WHITE}•${NC} V2Ray WebSocket (TLS & non-TLS)"
    echo -e "  ${WHITE}•${NC} SSH WebSocket Tunneling"
    echo -e "  ${WHITE}•${NC} Python Proxy with 101 Protocol"
    echo -e "  ${WHITE}•${NC} SSE (Server-Sent Events) Proxy"
    echo -e "  ${WHITE}•${NC} UDP Custom for gaming and VoIP"
    echo -e "  ${WHITE}•${NC} SSH over UDP Tunneling"
    echo -e "  ${WHITE}•${NC} Port adjustment after installation"
    echo -e "  ${WHITE}•${NC} Multi-user support for V2Ray"
    echo -e "  ${WHITE}•${NC} Domain management with SSL"
    echo -e "  ${WHITE}•${NC} Domain update capability"
    echo -e "  ${WHITE}•${NC} Firewall configuration"
    echo -e "  ${WHITE}•${NC} System monitoring"
    echo -e "  ${WHITE}•${NC} Backup and restore"
    
    echo -e "\n${YELLOW}🔹 Examples:${NC}"
    echo -e "  ${WHITE}sudo $0${NC}               Run in normal mode"
    echo -e "  ${WHITE}sudo $0 --test${NC}        Run in test mode (for development/demo)"
    
    echo -e "\n${YELLOW}🔹 Repository:${NC}"
    echo -e "  ${CYAN}https://github.com/kurogai/ubuntu-vps-manager${NC}"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case "$1" in
        -h|--help)
            SHOW_HELP=true
            shift
            ;;
        -v|--version)
            SHOW_VERSION=true
            shift
            ;;
        -t|--test)
            IS_TEST_MODE=true
            shift
            ;;
        -q|--quiet)
            QUIET_MODE=true
            shift
            ;;
        *)
            echo_error "Unknown option: $1"
            echo "Use --help to see available options."
            exit 1
            ;;
    esac
done

# Source utility functions
source "$SCRIPT_DIR/modules/utils.sh"

# Show help if requested
if [[ "$SHOW_HELP" == true ]]; then
    show_help
    exit 0
fi

# Show version if requested
if [[ "$SHOW_VERSION" == true ]]; then
    echo "Ubuntu VPS Manager v$VERSION"
    exit 0
fi

# Check if we're running in Replit
if [[ -n "$REPL_ID" ]]; then
    echo_info "Running in Replit environment - test mode enabled automatically"
    IS_TEST_MODE=true
elif [[ "$IS_TEST_MODE" != true ]]; then
    # Check if running as root
    if [[ $EUID -ne 0 ]]; then
        echo_error "This script must be run as root"
        echo_info "Try: sudo $0"
        exit 1
    fi
    
    # Check Ubuntu version
    if [[ $(lsb_release -rs) != "22.04" ]]; then
        echo_warning "This script is designed for Ubuntu 22.04 LTS"
        echo_warning "Your system is running: $(lsb_release -ds)"
        echo_warning "Some features may not work correctly on your system."
        read -p "Continue anyway? (y/n): " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi
fi

if [[ "$IS_TEST_MODE" == true ]]; then
    echo_info "Test mode enabled - actions will be simulated without making system changes"
fi

# Create necessary directories
mkdir -p "$SCRIPT_DIR/logs"
mkdir -p "$SCRIPT_DIR/backup"

# Source modules
source "$SCRIPT_DIR/modules/v2ray.sh"
source "$SCRIPT_DIR/modules/ssh_ws.sh"
source "$SCRIPT_DIR/modules/python_proxy.sh"
source "$SCRIPT_DIR/modules/sse_proxy.sh"
source "$SCRIPT_DIR/modules/domain.sh"
source "$SCRIPT_DIR/modules/monitoring.sh"
source "$SCRIPT_DIR/modules/backup.sh"
source "$SCRIPT_DIR/modules/udp_custom.sh"
source "$SCRIPT_DIR/modules/ssh_udp.sh"
source "$SCRIPT_DIR/modules/user_management.sh"

# Source user management modules
if [ -f "$SCRIPT_DIR/modules/v2ray_users.sh" ]; then
    source "$SCRIPT_DIR/modules/v2ray_users.sh"
else
    # Define minimal in-script version of V2Ray user management if module not found
    manage_v2ray_users() {
        echo_info "V2Ray User Management"
        echo_warning "Using limited built-in function - full module not available"
        echo_info "Please run the fix-vps.sh script to restore all modules"
        
        # Check if V2Ray is installed
        if ! is_service_installed v2ray; then
            echo_error "V2Ray is not installed"
            echo_info "You can install it using options 3 or 4 from the main menu"
            sleep 2
            return
        fi
        
        # Main user management loop
        while true; do
            clear
            echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
            echo -e "${BLUE}║              ${GREEN}V2Ray User Management${BLUE}                        ║${NC}"
            echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
            
            # Check service status
            local status=$(systemctl is-active v2ray 2>/dev/null || echo "inactive")
            
            echo -e "\n${YELLOW}🔹 Service Status:${NC}"
            if [[ "$status" == "active" ]]; then
                echo -e "  ${WHITE}V2Ray Status:${NC} ${GREEN}Active${NC}"
            else
                echo -e "  ${WHITE}V2Ray Status:${NC} ${RED}Inactive${NC} (run 'systemctl start v2ray' to start)"
            fi
            
            echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
            echo -e "  ${WHITE}1)${NC} Return to main menu"
            
            echo -ne "${CYAN}Enter your choice [1]: ${NC}"
            read -r choice
            
            case $choice in
                1|"")
                    break ;;
                *) 
                    echo_error "Invalid option. Please try again."
                    sleep 1
                    ;;
            esac
        done
    }
fi

if [ -f "$SCRIPT_DIR/modules/ssh_ws_users.sh" ]; then
    source "$SCRIPT_DIR/modules/ssh_ws_users.sh"
else
    # Define minimal in-script version of SSH WS user management if module not found
    manage_ssh_ws_users() {
        echo_info "SSH WebSocket User Management"
        echo_warning "Using limited built-in function - full module not available"
        echo_info "Please run the fix-vps.sh script to restore all modules"
        
        # Check if SSH WebSocket is installed
        if ! is_service_installed ssh_websocket; then
            echo_error "SSH WebSocket is not installed"
            echo_info "You can install it using option 7 from the main menu"
            sleep 2
            return
        fi
        
        # Main user management loop
        while true; do
            clear
            echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
            echo -e "${BLUE}║          ${GREEN}SSH WebSocket User Management${BLUE}                    ║${NC}"
            echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
            
            # Check service status
            local status=$(systemctl is-active dropbear 2>/dev/null || echo "inactive")
            
            echo -e "\n${YELLOW}🔹 Service Status:${NC}"
            if [[ "$status" == "active" ]]; then
                echo -e "  ${WHITE}SSH WebSocket Status:${NC} ${GREEN}Active${NC}"
            else
                echo -e "  ${WHITE}SSH WebSocket Status:${NC} ${RED}Inactive${NC}"
            fi
            
            echo -e "\n${YELLOW}🔹 User Management Options:${NC}"
            echo -e "  ${WHITE}1)${NC} Return to main menu"
            
            echo -ne "${CYAN}Enter your choice [1]: ${NC}"
            read -r choice
            
            case $choice in
                1|"")
                    break ;;
                *) 
                    echo_error "Invalid option. Please try again."
                    sleep 1
                    ;;
            esac
        done
    }
fi

# Update system packages function
update_system() {
    echo_info "Updating system packages..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating system update"
        sleep 1
    else
        apt update -y
        apt upgrade -y
    fi
    
    echo_success "System packages updated"
}

# Install basic dependencies
install_dependencies() {
    echo_info "Installing dependencies..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating dependency installation"
        sleep 1
    else
        apt install -y curl wget nano ufw socat unzip lsof python3 python3-pip net-tools certbot uuid-runtime nginx
    fi
    
    echo_success "Dependencies installed"
}

# Check services status
check_services_status() {
    # If in test mode, show simulated status
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Services Status (Test Mode - Status Simulated):"
        echo_warning " ✗ V2Ray is not running"
        echo_warning " ✗ SSH is not running"
        echo_warning " ✗ Python Proxy is not running"
        echo_warning " ✗ SSE Proxy is not running"
        echo_warning " ✗ UDP Custom is not running"
        echo_warning " ✗ SSH UDP is not running"
        echo_warning " ✗ Nginx is not running"
        return
    fi
    
    # Real service checks for production environment
    local status_v2ray=$(systemctl is-active v2ray 2>/dev/null || echo "inactive")
    local status_ssh=$(systemctl is-active ssh 2>/dev/null || echo "inactive")
    local status_python_proxy=$(systemctl is-active python_proxy 2>/dev/null || echo "inactive")
    local status_sse_proxy=$(systemctl is-active sse_proxy 2>/dev/null || echo "inactive")
    local status_udp_custom=$(systemctl is-active udp-custom 2>/dev/null || echo "inactive")
    local status_ssh_udp=$(systemctl is-active ssh-udp 2>/dev/null || echo "inactive")
    local status_nginx=$(systemctl is-active nginx 2>/dev/null || echo "inactive")
    
    echo_info "Services Status:"
    if [[ "$status_v2ray" == "active" ]]; then
        echo_success " ✓ V2Ray is running"
    else
        echo_warning " ✗ V2Ray is not running"
    fi
    
    if [[ "$status_ssh" == "active" ]]; then
        echo_success " ✓ SSH is running"
    else
        echo_warning " ✗ SSH is not running"
    fi
    
    if [[ "$status_python_proxy" == "active" ]]; then
        echo_success " ✓ Python Proxy is running"
    else
        echo_warning " ✗ Python Proxy is not running"
    fi
    
    if [[ "$status_sse_proxy" == "active" ]]; then
        echo_success " ✓ SSE Proxy is running"
    else
        echo_warning " ✗ SSE Proxy is not running"
    fi
    
    if [[ "$status_udp_custom" == "active" ]]; then
        echo_success " ✓ UDP Custom is running"
    else
        echo_warning " ✗ UDP Custom is not running"
    fi
    
    if [[ "$status_ssh_udp" == "active" ]]; then
        echo_success " ✓ SSH UDP is running"
    else
        echo_warning " ✗ SSH UDP is not running"
    fi
    
    if [[ "$status_nginx" == "active" ]]; then
        echo_success " ✓ Nginx is running"
    else
        echo_warning " ✗ Nginx is not running"
    fi
}

# Display the main menu
show_main_menu() {
    clear
    echo -e "${BLUE}╔════════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BLUE}║                ${GREEN}Ubuntu VPS Manager v$VERSION${BLUE}                  ║${NC}"
    echo -e "${BLUE}║         ${CYAN}Created by MasterMind ${YELLOW}@bitcockiii${BLUE}            ║${NC}" 
    echo -e "${BLUE}╚════════════════════════════════════════════════════════════╝${NC}"
    
    # Show test mode indicator if enabled
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo -e "${YELLOW}[TEST MODE ENABLED - No actual system changes will be made]${NC}\n"
    fi
    
    check_services_status
    
    echo -e "\n${CYAN}Select an option:${NC}"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${GREEN}Domain Management${NC}"
    echo -e "  ${WHITE}1)${NC} Configure domain              ${GRAY}# Set up your domain for TLS services${NC}"
    echo -e "  ${WHITE}2)${NC} Manage SSL certificates       ${GRAY}# Handle SSL certificates for your domain${NC}"
    
    echo -e "${GREEN}V2Ray Management${NC}"
    echo -e "  ${WHITE}3)${NC} Install V2Ray WebSocket (TLS)      ${GRAY}# Secure WebSocket with TLS${NC}"
    echo -e "  ${WHITE}4)${NC} Install V2Ray WebSocket (non-TLS)  ${GRAY}# Without TLS encryption${NC}"
    echo -e "  ${WHITE}5)${NC} Show V2Ray configuration           ${GRAY}# View current settings${NC}"
    echo -e "  ${WHITE}6)${NC} Uninstall V2Ray                    ${GRAY}# Remove V2Ray service${NC}"
    
    echo -e "${GREEN}SSH WebSocket Management${NC}"
    echo -e "  ${WHITE}7)${NC} Install SSH WebSocket         ${GRAY}# SSH access over WebSocket${NC}"
    echo -e "  ${WHITE}8)${NC} Show SSH WebSocket config     ${GRAY}# View connection details${NC}"
    echo -e "  ${WHITE}9)${NC} Uninstall SSH WebSocket       ${GRAY}# Remove SSH WebSocket service${NC}"
    
    echo -e "${GREEN}Python Proxy Management${NC}"
    echo -e "  ${WHITE}10)${NC} Install Python Proxy         ${GRAY}# HTTP/HTTPS & WebSocket 101 Protocol${NC}"
    echo -e "  ${WHITE}11)${NC} Show Python Proxy config     ${GRAY}# View proxy settings${NC}"
    echo -e "  ${WHITE}12)${NC} Uninstall Python Proxy       ${GRAY}# Remove Python Proxy service${NC}"
    
    echo -e "${GREEN}SSE Proxy Management${NC}"
    echo -e "  ${WHITE}13)${NC} Install SSE Proxy            ${GRAY}# Server-Sent Events proxy${NC}"
    echo -e "  ${WHITE}14)${NC} Show SSE Proxy config        ${GRAY}# View SSE proxy settings${NC}"
    echo -e "  ${WHITE}15)${NC} Uninstall SSE Proxy          ${GRAY}# Remove SSE Proxy service${NC}"
    
    echo -e "${GREEN}UDP Custom Management${NC}"
    echo -e "  ${WHITE}16)${NC} Install UDP Custom           ${GRAY}# UDP forwarding for gaming/VoIP${NC}"
    echo -e "  ${WHITE}17)${NC} Show UDP Custom config       ${GRAY}# View UDP Custom settings${NC}"
    echo -e "  ${WHITE}18)${NC} Uninstall UDP Custom         ${GRAY}# Remove UDP Custom service${NC}"
    
    echo -e "${GREEN}SSH UDP Management${NC}"
    echo -e "  ${WHITE}19)${NC} Install SSH UDP              ${GRAY}# SSH over UDP protocol${NC}"
    echo -e "  ${WHITE}20)${NC} Show SSH UDP config          ${GRAY}# View SSH UDP settings${NC}"
    echo -e "  ${WHITE}21)${NC} Uninstall SSH UDP            ${GRAY}# Remove SSH UDP service${NC}"
    
    echo -e "${GREEN}BadVPN Management${NC}"
    echo -e "  ${WHITE}22)${NC} Manage BadVPN                ${GRAY}# UDP forwarding for WhatsApp/VoIP calls${NC}"
    
    echo -e "${GREEN}System Management${NC}"
    echo -e "  ${WHITE}23)${NC} Backup configurations        ${GRAY}# Save your current settings${NC}"
    echo -e "  ${WHITE}24)${NC} Restore configurations       ${GRAY}# Restore from backup${NC}"
    echo -e "  ${WHITE}25)${NC} View system resources        ${GRAY}# Check CPU, memory & disk usage${NC}"
    echo -e "  ${WHITE}26)${NC} Update system                ${GRAY}# Update OS packages${NC}"
    echo -e "  ${WHITE}27)${NC} Update this script           ${GRAY}# Get the latest version${NC}"
    
    echo -e "${GREEN}User Management${NC}"
    echo -e "  ${WHITE}29)${NC} Universal User Management     ${GRAY}# Manage users across all SSH services${NC}"
    echo -e "  ${WHITE}30)${NC} Manage V2Ray users           ${GRAY}# Add/remove/list multiple V2Ray users${NC}"
    echo -e "  ${WHITE}31)${NC} Manage SSH WebSocket users    ${GRAY}# User management for SSH WebSocket${NC}"
    
    echo -e "${GREEN}Firewall Management${NC}"
    echo -e "  ${WHITE}28)${NC} Configure firewall           ${GRAY}# Set up UFW firewall rules${NC}"
    
    echo -e "${RED}Other Options${NC}"
    echo -e "  ${WHITE}h)${NC} Help information              ${GRAY}# Show additional help${NC}"
    echo -e "  ${WHITE}0)${NC} Exit                          ${GRAY}# Exit the program${NC}"
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    
    echo -e "${BLUE}⚠  TIP:${NC} For best security, set up a domain with SSL certificates first (options 1-2)${NC}"
    echo -ne "${CYAN}Enter your choice [0-31 or h for help]: ${NC}"
    read -r choice
    
    case $choice in
        0)  clear
            echo_info "Thank you for using Ubuntu VPS Manager!"
            echo_info "Exiting..."
            exit 0
            ;;
        h|H|help|HELP)
            clear
            show_help
            echo
            echo_info "Press Enter to return to the main menu..."
            read
            show_main_menu
            ;;
        1)  manage_domain
            ;;
        2)  manage_ssl
            ;;
        3)  install_v2ray_tls
            ;;
        4)  install_v2ray_nontls
            ;;
        5)  show_v2ray_config
            ;;
        6)  uninstall_v2ray
            ;;
        7)  install_ssh_websocket
            ;;
        8)  show_ssh_ws_config
            ;;
        9)  uninstall_ssh_websocket
            ;;
        10) install_python_proxy
            ;;
        11) show_python_proxy_config
            ;;
        12) uninstall_python_proxy
            ;;
        13) install_sse_proxy
            ;;
        14) show_sse_proxy_config
            ;;
        15) uninstall_sse_proxy
            ;;
        16) install_udp_custom
            ;;
        17) show_udp_custom_config
            ;;
        18) uninstall_udp_custom
            ;;
        19) install_ssh_udp
            ;;
        20) show_ssh_udp_config
            ;;
        21) uninstall_ssh_udp
            ;;
        22) manage_badvpn
            ;;
        23) backup_configs
            ;;
        24) restore_configs
            ;;
        25) show_system_resources
            ;;
        26) update_system
            ;;
        27) update_script
            ;;
        28) configure_firewall
            ;;
        29) 
            if command -v manage_universal_users &>/dev/null; then
                manage_universal_users
            else
                echo_error "Universal user management module not found or not properly sourced"
                echo_info "Please ensure modules/user_management.sh exists and has execute permissions"
                sleep 2
            fi
            ;;
        30) 
            if command -v manage_v2ray_users &>/dev/null; then
                manage_v2ray_users
            else
                echo_error "V2Ray user management module not found or not properly sourced"
                echo_info "Please ensure modules/v2ray_users.sh exists and has execute permissions"
                sleep 2
            fi
            ;;
        31) 
            if command -v manage_ssh_ws_users &>/dev/null; then
                manage_ssh_ws_users
            else
                echo_error "SSH WebSocket user management module not found or not properly sourced"
                echo_info "Please ensure modules/ssh_ws_users.sh exists and has execute permissions"
                sleep 2
            fi
            ;;
        *)  echo_error "Invalid option: '$choice'. Please try again."
            echo_info "Enter a number between 0-31 or 'h' for help."
            sleep 2
            ;;
    esac
    
    # Return to main menu after function execution
    echo
    echo -e "${YELLOW}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
    echo -e "${CYAN}Operation completed.${NC}"
    read -p "Press Enter to return to the main menu..."
    show_main_menu
}

# Manage BadVPN installation and service
manage_badvpn() {
    clear
    echo_info "BadVPN Management"
    echo "─────────────────────────────────────"
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: BadVPN Management (Simulated)"
        echo
        echo_info "BadVPN Options:"
        echo "1) Install BadVPN binary"
        echo "2) Configure BadVPN service"
        echo "3) Start BadVPN service"
        echo "4) Stop BadVPN service" 
        echo "5) Return to main menu"
        read -p "Enter option [1-5]: " option
        echo
        
        case $option in
            1) 
                echo_info "Test mode: Simulating BadVPN binary installation"
                sleep 1
                echo_success "BadVPN binary installation simulated"
                ;;
            2)
                echo_info "Test mode: Simulating BadVPN service configuration"
                sleep 1
                echo_success "BadVPN service configuration simulated"
                ;;
            3)
                echo_info "Test mode: Simulating BadVPN service start"
                sleep 1
                echo_success "BadVPN service start simulated"
                ;;
            4)
                echo_info "Test mode: Simulating BadVPN service stop"
                sleep 1
                echo_success "BadVPN service stop simulated"
                ;;
            5|*)
                return
                ;;
        esac
        
        return
    fi
    
    local badvpn_installed=false
    local service_configured=false
    local service_running=false
    
    # Check if BadVPN is installed
    if [ -f "/usr/local/bin/badvpn-udpgw" ]; then
        badvpn_installed=true
        echo_success "BadVPN binary is installed"
    else
        echo_warning "BadVPN binary is not installed"
    fi
    
    # Check if service is configured
    if [ -f "/etc/systemd/system/udp-custom.service" ]; then
        service_configured=true
        echo_success "BadVPN service is configured"
    else
        echo_warning "BadVPN service is not configured"
    fi
    
    # Check if service is running
    if systemctl is-active --quiet udp-custom; then
        service_running=true
        
        # Get current port
        local port=$(grep -oP 'listen-addr\s+0.0.0.0:\K\d+' /etc/systemd/system/udp-custom.service || echo $UDP_CUSTOM_PORT)
        
        echo_success "BadVPN service is running on port $port"
        echo_info "Connection details:"
        echo "Usage with SSH client: badvpn-udpgw --client-mode --remote-host YOUR_SERVER_IP:$port"
    else
        echo_warning "BadVPN service is not running"
    fi
    
    echo
    echo_info "BadVPN Options:"
    
    local options=()
    local counter=1
    
    if [ "$badvpn_installed" = false ]; then
        options+=("Install BadVPN binary")
    fi
    
    if [ "$badvpn_installed" = true ] && [ "$service_configured" = false ]; then
        options+=("Configure BadVPN service")
    fi
    
    if [ "$service_configured" = true ] && [ "$service_running" = false ]; then
        options+=("Start BadVPN service")
    fi
    
    if [ "$service_running" = true ]; then
        options+=("Stop BadVPN service")
        options+=("Change BadVPN port")
    fi
    
    options+=("Return to main menu")
    
    for option in "${options[@]}"; do
        echo "$counter) $option"
        ((counter++))
    done
    
    read -p "Enter option [1-$((counter-1))]: " choice
    echo
    
    if [[ ! "$choice" =~ ^[0-9]+$ ]] || [ "$choice" -lt 1 ] || [ "$choice" -gt $((counter-1)) ]; then
        echo_error "Invalid option. Please try again."
        sleep 1
        manage_badvpn
        return
    fi
    
    selected_option="${options[$((choice-1))]}"
    
    case "$selected_option" in
        "Install BadVPN binary")
            install_badvpn
            ;;
        "Configure BadVPN service")
            # Create service
            mkdir -p /etc/udp-custom
            
            # Configure service
            cat > /etc/systemd/system/udp-custom.service << EOF
[Unit]
Description=UDP Custom by MasterMind (@bitcockiii)
After=network.target

[Service]
ExecStart=/usr/local/bin/badvpn-udpgw --listen-addr 0.0.0.0:${UDP_CUSTOM_PORT} --max-clients 1000 --max-connections-for-client 10 --client-socket-sndbuf 10000
Restart=always
RestartSec=3
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=udp-custom

[Install]
WantedBy=multi-user.target
EOF
            
            # Create configuration file
            cat > /etc/udp-custom/config.json << EOF
{
    "listen_addr": "0.0.0.0:${UDP_CUSTOM_PORT}",
    "max_clients": 1000,
    "max_connections_per_client": 10,
    "buffer_size": 10000,
    "creator": "MasterMind (@bitcockiii)"
}
EOF
            
            # Enable service
            systemctl daemon-reload
            systemctl enable udp-custom
            
            # Open port in firewall
            if command -v ufw &>/dev/null && ufw status | grep -q "active"; then
                ufw allow $UDP_CUSTOM_PORT/udp
            fi
            
            echo_success "BadVPN service has been configured"
            ;;
        "Start BadVPN service")
            enable_udp_custom
            ;;
        "Stop BadVPN service")
            disable_udp_custom
            ;;
        "Change BadVPN port")
            echo_info "Enter new port for BadVPN (current: $port, recommended: 7300)"
            read -p "Enter new port, press Enter to keep current, or type 'default' for port 7300: " new_port
            if [[ -n "$new_port" ]]; then
                if [[ "$new_port" == "default" ]]; then
                    change_udp_custom_port "7300"
                else
                    change_udp_custom_port "$new_port"
                fi
            fi
            ;;
        "Return to main menu"|*)
            return
            ;;
    esac
    
    # Return to BadVPN menu after operation
    echo
    read -p "Press Enter to return to BadVPN Management menu..."
    manage_badvpn
}

# Initialize script
initial_setup() {
    echo_info "Performing initial setup..."
    
    if [[ "$IS_TEST_MODE" == true ]]; then
        echo_info "Test mode: Simulating dependency installation"
        sleep 1
    else
        install_dependencies
    fi
    
    echo_success "Initial setup completed"
}

# Check for initial setup
if [ ! -f "$SCRIPT_DIR/.initialized" ]; then
    initial_setup
    touch "$SCRIPT_DIR/.initialized"
fi

# Start the script
show_main_menu
